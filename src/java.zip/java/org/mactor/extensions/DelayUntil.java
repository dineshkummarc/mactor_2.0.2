/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.ActionCommand;

/**
 * Suspend execution until the time specifed by the first parameter (on the
 * format yyyy-MM-dd'T'HH:mm:ss.SSSZ, i.e: 2008-07-04T12:08:56.235+0100)
 * 
 * @author Lars Ivar Almli
 */
public class DelayUntil implements ActionCommand {
	public void perform(TestContext context, List<String> params) throws MactorException {
		if (params.size() != 1)
			throw new ConfigException("Invalid testspec. One parameter expected: [<the data-time on the form yyyy-MM-dd'T'HH:mm:ss.SSSZ the action should delay until>]>");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		Date d = null;
		try {
			d = sdf.parse(params.get(0));
		} catch (ParseException pe) {
			throw new ConfigException("The parameter must be on the format yyyy-MM-dd'T'HH:mm:ss.SSSZ (i.e. 2008-07-04T12:08:56.235+0100) -  '" + params.get(0) + "' is  not");
		}
		long time2sleep = d.getTime() - System.currentTimeMillis();
		if (time2sleep > 0) {
			try {
				Thread.sleep(time2sleep);
			} catch (InterruptedException ie) {
				throw new MactorException("The sleep was interrupted");
			}
		}
	}
}
