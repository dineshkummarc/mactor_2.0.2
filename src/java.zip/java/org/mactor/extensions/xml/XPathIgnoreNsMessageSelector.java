/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions.xml;

import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.dom4j.Document;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.mactor.brokers.Message;
import org.mactor.framework.MactorException;
import org.mactor.framework.extensioninterface.MessageSelectorCommand;

/**
 * Selects all messages matching the XPath/value expressions specified in the
 * parameters. <br/> The syntax of a parameters are:<br>
 * [XPath expression that selects the single attribute or element ]==[value that
 * the selected field must be equal to] <br/> I.e. the following setup matches
 * alle messages containing an Orderid field with the value 5
 * 
 * <pre>
 *  &lt;message_selector command=&quot;java:org.mactor.extensions.xml.XPathIgnoreNsMessageSelector&quot;&gt; 
 *     &lt;param&gt;//OrderId==5&lt;/param&gt; 
 *  &lt;/message_selector&gt; 
 * </pre>
 * 
 * Namespace information in the evaluated messages is ignored, so the XPath
 * expressions must not include namespace prefixes
 * 
 * @author Lars Ivar Almli
 */
public class XPathIgnoreNsMessageSelector implements MessageSelectorCommand {
	private HashMap<XPath, String> map = new HashMap<XPath, String>();
	public void setParams(List<String> params) throws MactorException {
		this.map = ParamUtil.parseXPathParams(params);
	}
	public boolean isAcceptableMessage(Message message) {
		try {
			Document doc = message.getContentDocumentNoNs();
			if (map.size() == 0) {
				return true;
			}
			for (Entry<XPath, String> e : map.entrySet()) {
				Node n = e.getKey().selectSingleNode(doc);
				if (n == null || !ParamUtil.isEqual(n.getText(), e.getValue()))
					return false;
			}
			return true;
		} catch (MactorException ce) {
			ce.printStackTrace();
			return false;
		}
	}
}
