/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions.xml;

import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.dom4j.Document;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.mactor.brokers.Message;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.ActionCommand;

/**
 * Validates that a selected field from the last received message matches a
 * specifed value. <br/> The field to select and the value it must be equal to
 * is specified as a single parameter on the form:<br/> [XPath expression that
 * selects the single attribute or element ]==[value that the selected field
 * must be equal to] <br>
 * Namespace information in the evaluated messages is ignored, so the XPath
 * expressions must not include namespace prefixes
 * 
 * @author Lars Ivar Almli
 */
public class XPathIgnoreNsValidator implements ActionCommand {
	public void perform(TestContext context, List<String> params) throws MactorException {
		StringBuffer sb = new StringBuffer();
		Message m = context.getLastIncomingMessage();
		if (m == null)
			throw new MactorException("There is no incoming message to validate!");
		Document doc = m.getContentDocumentNoNs();
		HashMap<XPath, String> map = ParamUtil.parseXPathParams(params);
		for (Entry<XPath, String> e : map.entrySet()) {
			Node n = e.getKey().selectSingleNode(doc);
			String v = n == null ? null : n.getText();
			if (!ParamUtil.isMatch(v, e.getValue()))
				sb.append("Validation of '" + e.getKey().getText() + "' failed. Expected '" + e.getValue() + "', but got '" + v + "'");
		}
		if (sb.length() != 0)
			throw new MactorException(sb.toString());
	}
}
