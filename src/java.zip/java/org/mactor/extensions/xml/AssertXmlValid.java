package org.mactor.extensions.xml;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.log4j.Logger;
import org.mactor.brokers.Message;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.ActionCommand;
import org.mactor.framework.spec.ProjectContext;
import org.xml.sax.SAXException;

public class AssertXmlValid implements ActionCommand {
	private static Logger log = Logger.getLogger(AssertXmlValid.class);
	public void perform(TestContext context, List<String> params) throws MactorException {
		if (params.size() != 1)
			throw new ConfigException("Invalid testspec. One parameter expected: [<the relative path to the XML schema that should be used to validate the last received message>]>");
		Message last = context.getLastIncomingMessage();
		if (last == null)
			throw new MactorException("There is no incoming message to validate");
		log.debug("AssertXmlValid:'" + params.get(0) + "'");
		validateMessage(last, params.get(0));
	}
	public void validateMessage(Message message, String schemaPath) throws MactorException {
		Validator v = getSchema(schemaPath).newValidator();
		try {
			v.validate(new StreamSource(new StringReader(message.getContent())));
		} catch (IOException ioe) {
			throw new RuntimeException("Unable to read the last received message. Error:" + ioe.getMessage(), ioe);
		} catch (SAXException se) {
			throw new MactorException("The message is not valid according to the '" + schemaPath + "' schema. Details:" + se.getMessage(), se);
		}
	}
	private Schema getSchema(String schemaPath) throws MactorException {
		File absoluteShemaPath = ProjectContext.getGlobalInstance().getAbsolutePath(schemaPath);
		if (!absoluteShemaPath.exists())
			throw new ConfigException("The specifed XML schema '" + absoluteShemaPath.getAbsolutePath() + "' does not exist");
		final String sl = XMLConstants.W3C_XML_SCHEMA_NS_URI;
		SchemaFactory factory = SchemaFactory.newInstance(sl);
		try {
			return factory.newSchema(absoluteShemaPath);
		} catch (SAXException se) {
			throw new ConfigException("The specifed XML schema '" + absoluteShemaPath.getAbsolutePath() + "' could not be loaded. Problem:" + se.getMessage(), se);
		}
	}
}
