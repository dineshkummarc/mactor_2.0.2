/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions.xml;

import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.dom4j.DocumentHelper;
import org.dom4j.InvalidXPathException;
import org.dom4j.XPath;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;

public class ParamUtil {
	public static HashMap<String, String> parseParams(List<String> params) throws MactorException {
		HashMap<String, String> map = new HashMap<String, String>();
		for (String string : params) {
			int firstIndex = string.indexOf("==");
			if (firstIndex > 0 && firstIndex + 2 < string.length()) {
				map.put(string.substring(0, firstIndex), string.substring(firstIndex + 2));
			} else {
				throw new MactorException("Unparseable param:  " + string);
			}
		}
		return map;
	}
	public static HashMap<XPath, String> parseXPathParams(List<String> params) throws MactorException {
		HashMap<String, String> m = parseParams(params);
		HashMap<XPath, String> xpMap = new HashMap<XPath, String>();
		for (Entry<String, String> e : m.entrySet()) {
			try {
				xpMap.put(DocumentHelper.createXPath(e.getKey()), e.getValue());
			} catch (InvalidXPathException ie) {
				throw new ConfigException("Invalid xpath expression '" + e.getKey() + "'. Error: " + ie.getMessage(), ie);
			}
		}
		return xpMap;
	}
	public static boolean isEqual(String s1, String s2) {
		if (s1 == null && s2 == null)
			return true;
		if (s1 == null)
			return false;
		return s1.equals(s2);
	}
	public static boolean isMatch(String s1, String s2) {
		if (s1 == null && s2 == null)
			return true;
		if (s1 == null)
			return false;
		return s1.matches(s2);
	}
}
