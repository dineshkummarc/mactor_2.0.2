/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions.xml;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.dom4j.io.SAXReader;
import org.mactor.brokers.Message;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.MessageBuilderCommand;

/**
 * Builds a message based on a XML file (the template), substituting the vales
 * in the file with the values specied in the paramaters.<br/>
 * 
 * The syntax of a parameters are:<br>
 * [XPath expression that selects the single attribute or element ]==[value that
 * should be assigned to the field] <br/> If the namespace prefixes are used in
 * the template file, the same prefixes must be used in the XPath expression.<br/>
 * If the a default namespace is used in the template file, 'def' must by used a
 * namespace prefix in the XPath expression<br/>
 * 
 * @author Lars Ivar Almli
 */
public class XPathTemplateMessageBuilder implements MessageBuilderCommand {
	public Message buildMessage(TestContext context, String templatePath, List<String> params) throws MactorException {
		// long start = System.currentTimeMillis();
		File template = new File(templatePath);
		if (!template.exists())
			throw new MactorException("The specified template '" + template.getAbsolutePath() + "' does not exist");
		Document doc = null;
		try {
			doc = new SAXReader().read(template);
		} catch (DocumentException de) {
			throw new MactorException("Failed to parse template '" + template.getAbsolutePath() + "' as xml");
		}
		HashMap<XPath, String> map = ParamUtil.parseXPathParams(params);
		Map nsMap = new HashMap();
		findNameSpaces(nsMap, doc.getRootElement());
		for (Entry<XPath, String> e : map.entrySet()) {
			e.getKey().setNamespaceURIs(nsMap);
		}
		for (Entry<XPath, String> e : map.entrySet()) {
			Node n = e.getKey().selectSingleNode(doc);
			if (n == null)
				throw new ConfigException("The template '" + templatePath + "' does not contain the xpath '" + e.getKey() + "'");
			n.setText(e.getValue());
		}
		return Message.createMessage(doc);
	}
	private void addNsPrefix(Map m, String prefix, String uri) throws ConfigException {
		if (m.containsKey(prefix)) {
			if (!uri.equals(m.get(prefix)))
				throw new ConfigException("Namespace conflict. The namespace '" + prefix + "' is used for both '" + uri + "' and '" + m.get(prefix) + "'");
		} else
			m.put(prefix, uri);
	}
	private void findNameSpaces(Map nsMap, Element element) throws ConfigException {
		List nsList = element.declaredNamespaces();
		for (Object o : nsList) {
			Namespace ns = (Namespace) o;
			// Ok, this is a hack to simplify the XPathTemplateMessageBuilder
			// 'user
			// interface': use 'def' as the default prefix
			if (ns.getPrefix() == null || ns.getPrefix().length() == 0)
				addNsPrefix(nsMap, "def", ns.getURI());
			else
				addNsPrefix(nsMap, ns.getPrefix(), ns.getURI());
		}
		Iterator it = element.elementIterator();
		while (it.hasNext())
			findNameSpaces(nsMap, (Element) it.next());
	}
}
