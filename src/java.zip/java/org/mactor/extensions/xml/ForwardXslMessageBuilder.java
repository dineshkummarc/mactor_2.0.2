/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions.xml;

import java.io.File;
import java.util.List;

import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import org.dom4j.io.DocumentResult;
import org.dom4j.io.DocumentSource;
import org.mactor.brokers.Message;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.MessageBuilderCommand;

public class ForwardXslMessageBuilder implements MessageBuilderCommand {
	public Message buildMessage(TestContext context, String templatePath, List<String> params) throws MactorException {
		Message last = context.getLastIncomingMessage();
		if (last == null)
			throw new MactorException("There is no incoming message to build a message from");
		if (templatePath == null || templatePath.length() == 0)
			throw new ConfigException("Invalid testspec. Template Path must be the relative path to the XSL file that should be used to transform the last received message into the result message");
		return transform(last, templatePath);
	}
	public Message transform(Message message, String xslPath) throws MactorException {
		DocumentSource source = new DocumentSource(message.getContentDocument());
		DocumentResult result = new DocumentResult();
		try {
			getTransformer(xslPath).transform(source, result);
			return Message.createMessage(result.getDocument());
		} catch (TransformerException te) {
			throw new MactorException("Failed to transform the received message using the specifed XSL '" + xslPath + "'. Problem:" + te.getMessage(), te);
		}
	}
	private Transformer getTransformer(String xslPath) throws MactorException {
		File absoluteXslPath = new File(xslPath);
		if (!absoluteXslPath.exists())
			throw new ConfigException("The specifed XSL file '" + absoluteXslPath.getAbsolutePath() + "' does not exist");
		TransformerFactory factory = TransformerFactory.newInstance();
		try {
			Templates t = factory.newTemplates(new StreamSource(absoluteXslPath));
			return t.newTransformer();
		} catch (Exception e) {
			throw new ConfigException("The specifed XSL file '" + absoluteXslPath.getAbsolutePath() + "' could not be loaded. Error:" + e.getMessage(), e);
		}
	}
}