/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions.xml;

import java.util.List;

import org.dom4j.Document;
import org.dom4j.InvalidXPathException;
import org.dom4j.Node;
import org.mactor.brokers.Message;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.ValueCommand;

/**
 * Extracts a selected field from the last received message <br/> The field to
 * select is specified as a single parameter containing the XPath expression
 * that selects the single attribute or element <br/> Namespace information in
 * the evaluated messages is ignored, so the XPath expressions must not include
 * namespace prefixes
 * 
 * @author Lars Ivar Almli
 */
public class XPathIgnoreNsValueExtractor implements ValueCommand {
	public String extractValue(TestContext context, List<String> params) throws MactorException {
		try {
			Message m = context.getLastIncomingMessage();
			if (m == null)
				throw new MactorException("There is no incoming message to validate!");
			Document doc = m.getContentDocumentNoNs();
			if (params.size() == 0)
				return null;
			Node n = doc.selectSingleNode(params.get(0));
			return n == null ? null : n.getText();
		} catch (InvalidXPathException ie) {
			throw new ConfigException("Invalid xpath expression '" + params.get(0) + "'. Error: " + ie.getMessage(), ie);
		}
	}
}
