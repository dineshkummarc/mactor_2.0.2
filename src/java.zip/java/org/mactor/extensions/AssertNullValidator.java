/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions;

import java.util.List;

import org.apache.log4j.Logger;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.ActionCommand;

/**
 * Asserts that the single parameter is null
 * 
 * @author Lars Ivar Almli
 */
public class AssertNullValidator implements ActionCommand {
	private static Logger log = Logger.getLogger(AssertNullValidator.class);
	public void perform(TestContext context, List<String> params) throws MactorException {
		if (params.size() != 1)
			throw new ConfigException("Invalid testspec. One parameter expected: [<the value to validate>]>");
		log.debug("AssertNullValidator:'" + params.get(0) + "'");
		if (params.get(0) != null && !params.get(0).equals("null")) // hack
			throw new MactorException("Assertions failed. The value was not null");
	}
}
