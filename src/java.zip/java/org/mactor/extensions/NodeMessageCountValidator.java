/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions;

import java.util.List;

import org.mactor.brokers.Message;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.ParseUtil;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.ActionCommand;
import org.mactor.framework.spec.MessagePublishSpec;
import org.mactor.framework.spec.MessageReceiveSpec;
import org.mactor.framework.spec.SpecNode;

/**
 * Asserts that the number of messages recived by the node specified by the
 * first parameter (by name) equals the number specifed in the second parameter
 * 
 * @author Lars Ivar Almli
 */
public class NodeMessageCountValidator implements ActionCommand {
	public void perform(TestContext context, List<String> params) throws MactorException {
		if (params.size() != 2)
			throw new ConfigException("Invalid testspec. Two parameters expected: [<node name>, <message count>]>");
		String nodeName = params.get(0);
		Integer expectedCount = ParseUtil.tryParseInt(params.get(1));
		if (expectedCount == null)
			throw new ConfigException("The second parameter must be a numeric value. Was: " + params.get(1));
		SpecNode node = context.getSpecNode(nodeName);
		if (node == null)
			throw new ConfigException("Unknown node:" + nodeName);
		int count = 0;
		if (node instanceof MessageReceiveSpec) {
			List<Message> history = context.getIncomingMessageHistory(nodeName);
			if (history != null)
				count = history.size();
		} else if (node instanceof MessagePublishSpec) {
			List<Message> history = context.getOutgoingMessageHistory(nodeName);
			if (history != null)
				count = history.size();
		} else {
			throw new ConfigException("The specified node is not a message node");
		}
		if (expectedCount.intValue() != count)
			throw new MactorException("Expected '" + expectedCount + "' got '" + count + "'");
	}
}
