/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions;

import java.util.List;

import org.apache.log4j.Logger;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.ActionCommand;

/**
 * Asserts that the two provider parameters are equal
 * 
 * @author Lars Ivar Almli
 */
public class AssertEqualsValidator implements ActionCommand {
	private static Logger log = Logger.getLogger(AssertEqualsValidator.class);
	public void perform(TestContext context, List<String> params) throws MactorException {
		if (params.size() != 2)
			throw new ConfigException("Invalid testspec. Two parameters expected: [<the value 1>,<the value 2>]>");
		if (!isEqual(params.get(0), params.get(1)))
			throw new MactorException("Assertions failed. '" + params.get(1) + "' is not equal to '" + params.get(0) + "'");
	}
	public static boolean isEqual(String s1, String s2) {
		if (s1 == null && s2 == null)
			return true;
		if (s1 == null)
			return false;
		return s1.equals(s2);
	}
}
