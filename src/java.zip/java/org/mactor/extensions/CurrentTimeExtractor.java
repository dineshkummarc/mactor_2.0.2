/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.extensions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.mactor.framework.MactorException;
import org.mactor.framework.TestContext;
import org.mactor.framework.extensioninterface.ValueCommand;

/**
 * Extracts the current time on the format: 'yyyy-MM-dd'T'HH:mm:ss.SSSZ' <br>
 * A single parameter can be provided to specify the number of minutes to add to
 * or substract from the current time (5 adds five minuts -120 subtracts to
 * hours )
 * 
 * @author Lars Ivar Almli
 */
public class CurrentTimeExtractor implements ValueCommand {
	public String extractValue(TestContext context, List<String> params) throws MactorException {
		Calendar cal = Calendar.getInstance();
		if (params != null && params.size() > 0 && params.get(0) != null && params.get(0).length() > 0) {
			try {
				String v = params.get(0);
				int minutes = Integer.parseInt(v);
				cal.add(Calendar.MINUTE, minutes);
			} catch (NumberFormatException nfe) {
			}
		}
		String s = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").format(cal.getTime());
		if (s.charAt(s.length() - 2) != ':') // Bug in SimpleDateFormat?
			s = s.substring(0, s.length() - 2) + ":" + s.substring(s.length() - 2);
		return s;
	}
}