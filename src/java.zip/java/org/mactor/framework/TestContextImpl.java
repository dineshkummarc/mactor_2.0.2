/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.mactor.brokers.Message;
import org.mactor.framework.spec.GlobalConfig;
import org.mactor.framework.spec.SpecNode;
import org.mactor.framework.spec.TestSpec;
import org.mactor.framework.spec.GlobalConfig.Group;

/**
 * Maintains context information about the current executing test
 * 
 * @author Lars Ivar Almli
 */
public class TestContextImpl implements TestContext {
	private static final String START_TAG = "##{";
	private static final String END_TAG = "}";
	private Map<String, String> valueDic = new HashMap<String, String>();
	private MessageHistoryStore sentMessageHistory = new MessageHistoryStore();
	private MessageHistoryStore receivedMessageHistory = new MessageHistoryStore();
	private GlobalConfig globalConfig;
	private TestSpec testSpec;
	public TestContextImpl(GlobalConfig globalConfig, TestSpec testSpec) {
		this.globalConfig = globalConfig;
		this.testSpec = testSpec;
	}
	public void setValues(Map<String, String> nameValueMap) {
		valueDic.putAll(nameValueMap);
	}
	public void setValue(String name, String value) {
		valueDic.put(name, value);
	}
	public Object getValue(String name) {
		return valueDic.get(name);
	}
	public Map<String, String> getValues() {
		return valueDic; // Collections.unmodifiableMap(
	}
	public void addReceivedMessage(String nodeName, Message message) {
		receivedMessageHistory.addMessage(nodeName, message);
	}
	public void addOutgoingMessage(String nodeName, Message message) {
		sentMessageHistory.addMessage(nodeName, message);
	}
	public Message getLastIncomingMessage() {
		return receivedMessageHistory.getLastMessage();
	}
	public Message getLastOutgoingMessage() {
		return sentMessageHistory.getLastMessage();
	}
	public List<Message> getIncomingMessageHistory(String nodeName) {
		return receivedMessageHistory.getMessageHistory(nodeName);
	}
	public List<Message> getOutgoingMessageHistory(String nodeName) {
		return sentMessageHistory.getMessageHistory(nodeName);
	}
	public List<Message> getIncomingMessageHistoryForCurrentNode() {
		return receivedMessageHistory.getLastModifiedMessageHistory();
	}
	public List<Message> getOutgoingMessageHistoryForCurrentNode() {
		return sentMessageHistory.getLastModifiedMessageHistory();
	}
	public List<String> substitute(List<String> candidates) {
		List<String> results = new LinkedList<String>();
		for (Iterator iter = candidates.iterator(); iter.hasNext();) {
			results.add(substitute((String) iter.next()));
		}
		return results;
	}
	public SpecNode getSpecNode(String nodeName) {
		return testSpec.findSpecNode(nodeName);
	}
	public String substitute(String candidate) {
		if (candidate == null)
			return null;
		StringBuffer sb = new StringBuffer();
		sub(sb, candidate);
		String v = sb.toString().trim();
		if (v.length() == 0)
			return null;
		return v;
	}
	private void sub(StringBuffer sb, String candidate) {
		if (candidate == null)
			return;
		int start = candidate.indexOf(START_TAG);
		if (start >= 0) {
			int end = candidate.indexOf(END_TAG, start + 3);
			if (end > 0) {
				String tag = candidate.substring(start + 3, end);
				if (valueDic.containsKey(tag)) {
					sb.append(candidate.substring(0, start)).append(valueDic.get(tag));
					if (end + 1 >= candidate.length())
						return;
					else
						sub(sb, candidate.substring(end + 1, candidate.length()));
				} else {
					sb.append(candidate.substring(0, end + 1));
					if (end + 1 >= candidate.length())
						return;
					else
						sub(sb, candidate.substring(end + 1, candidate.length()));
				}
				return;
			}
		}
		sb.append(candidate);
	}
	// Config related methods:
	public GlobalConfig getGlobalConfig() {
		return globalConfig;
	}
	public String getGlobalConfigValue(String valueName) {
		return globalConfig.getValue(valueName);
	}
	public Group getGlobalConfigGroup(String groupName) {
		return globalConfig.getGroup(groupName);
	}
	public Group getRequieredGlobalConfigGroup(String groupName) throws ConfigException {
		return globalConfig.getRequieredGroup(groupName);
	}
	private static class MessageHistoryStore {
		private MessageHistory lastModifedMessageHistory;
		private Map<String, MessageHistory> messageHistoryMap = new HashMap<String, MessageHistory>();
		public synchronized void addMessage(String node, Message message) {
			MessageHistory mh = messageHistoryMap.get(node);
			if (mh == null) {
				mh = new MessageHistory();
				messageHistoryMap.put(node, mh);
			}
			mh.addMessage(message);
			lastModifedMessageHistory = mh;
		}
		public synchronized List<Message> getLastModifiedMessageHistory() {
			if (lastModifedMessageHistory == null)
				return null;
			return lastModifedMessageHistory.getMessages();
		}
		public synchronized Message getLastMessage() {
			if (lastModifedMessageHistory == null)
				return null;
			return lastModifedMessageHistory.getLastMessage();
		}
		public synchronized List<Message> getMessageHistory(String nodeName) {
			MessageHistory mh = messageHistoryMap.get(nodeName);
			if (mh == null)
				return null;
			return mh.getMessages();
		}
	}
	public LinkedList<Message> getAllMessages() {
		LinkedList<Message> all = new LinkedList<Message>();
		for (MessageHistory mh : sentMessageHistory.messageHistoryMap.values()) {
			all.addAll(mh.getMessages());
		}
		for (MessageHistory mh : receivedMessageHistory.messageHistoryMap.values()) {
			all.addAll(mh.getMessages());
		}
		return all;
	}
	private static class MessageHistory {
		private LinkedList<Message> history = new LinkedList<Message>();
		public void addMessage(Message message) {
			history.add(message);
		}
		public LinkedList<Message> getMessages() {
			return history;
		}
		public Message getLastMessage() {
			if (history.size() == 0)
				return null;
			return history.getLast();
		}
	}
	public TestSpec getTestSpec() {
		return testSpec;
	}
}
