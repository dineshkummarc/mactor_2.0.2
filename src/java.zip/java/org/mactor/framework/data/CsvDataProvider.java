/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.data;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;

public class CsvDataProvider implements DataProvider {
	private String dataSourceConnectionSpec;
	CsvDataProvider(String dataSourceConnectionSpec) {
		this.dataSourceConnectionSpec = dataSourceConnectionSpec;
	}
	public DataTable loadData() throws MactorException {
		File source = ProjectContext.getGlobalInstance().getAbsolutePath(dataSourceConnectionSpec);
		if (!source.exists())
			throw new MactorException("The specifed file does not exist '" + source.getAbsolutePath() + "'");
		try {
			LineNumberReader fr = null;
			try {
				fr = new LineNumberReader(new FileReader(source));
				String header = fr.readLine();
				if (header == null)
					throw new MactorException("Invalid file format. The file  '" + source.getAbsolutePath() + "' is empty");
				String[] cols = header.split(";");
				if (cols == null || cols.length == 0)
					throw new MactorException("Invalid file format. The file  '" + source.getAbsolutePath() + "' does not contains any columns (colums must be seperated by the ';' character)");
				DataTable table = new DataTable();
				for (String col : cols)
					table.addColumn(col.trim());
				int colCount = cols.length;
				for (;;) {
					String line = fr.readLine();
					if (line == null)
						break;
					line = line.trim();
					if (line.length() == 0)
						continue;
					if (line.startsWith("#")) // skip comments
						continue;
					String[] cells = line.split(";");
					int count = cells == null ? 0 : cells.length;
					if (count != colCount)
						throw new MactorException("Invalid file format. The file  '" + source.getAbsolutePath() + "' contains an invalid number of columns on line '" + fr.getLineNumber()
								+ "'. Expected " + colCount + "' columns, but was '" + count + "'");
					table.addRow(cells);
				}
				return table;
			} finally {
				if (fr != null)
					fr.close();
			}
		} catch (IOException ioe) {
			throw new MactorException("Failed to read the file '" + source.getAbsolutePath() + "'. Error:" + ioe.getMessage(), ioe);
		}
	}
}
