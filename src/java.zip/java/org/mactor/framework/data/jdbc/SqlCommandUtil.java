/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.data.jdbc;

import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.GlobalConfig;
import org.mactor.framework.spec.GlobalConfig.Group;

public class SqlCommandUtil {
	private JdbcUtil db;
	private String sqlExpression;
	public SqlCommandUtil(String command, GlobalConfig globalConfig) throws MactorException {
		int start = command.indexOf(":");
		if (start <= 0 || start > command.length() - 4) {
			throw new ConfigException("Invalid sql command syntax 'sql:" + command
					+ "'. Correct syntax is: 'sql:<name of sql global config group>:<sql expession> | <sql script file ending with .sql>'  ");
		}
		String groupName = command.substring(0, start);
		this.sqlExpression = command.substring(start + 1, command.length());
		Group config = globalConfig.getRequieredGroup(groupName);
		this.db = new JdbcUtil(config.getValue("driver"), config.getRequieredValue("url"), config.getRequieredValue("username"), config.getRequieredValue("password"));
	}
	public JdbcUtil getDb() {
		return db;
	}
	public String getSqlExpression() {
		return sqlExpression;
	}
}
