/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.data.jdbc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.mactor.framework.MactorException;
import org.mactor.framework.data.DataTable;

public class JdbcUtil {
	private static Logger log = Logger.getLogger(JdbcUtil.class);
	private String driver;
	private String url;
	private String username;
	private String password;
	public JdbcUtil(String driver, String url, String username, String password) {
		this.driver = driver;
		this.url = url;
		this.username = username;
		this.password = password;
	}
	private Connection getConnection() throws MactorException {
		java.util.Properties props = new java.util.Properties();
		props.put("user", username);
		props.put("password", password);
		// props.put("protocol", "thin");
		try {
			if (driver != null) {
				java.sql.Driver d = (java.sql.Driver) Class.forName(driver).newInstance();
				java.sql.Connection conn = d.connect(url, props);
				return conn;
			} else {
				return DriverManager.getConnection(url, props);
			}
		} catch (ClassNotFoundException cfn) {
			throw new MactorException("The specified JDBC driver class '" + driver + "'was not found in the classpath");
		} catch (InstantiationException ie) {
			throw new MactorException("Unable to instantiate the specified JDBC driver class  '" + driver + "'", ie);
		} catch (IllegalAccessException iae) {
			throw new MactorException("Unable to instantiate the specified JDBC driver class  '" + driver + "'", iae);
		} catch (SQLException sqle) {
			throw new MactorException("Unable to connect to the specfied db-url '" + url + "'. Error: " + sqle.getMessage(), sqle);
		}
	}
	public String execSingleCellScriptQuery(File file) throws MactorException {
		return execSingleCellQuerySql(getExpressionFromFile(file));
	}
	private String getExpressionFromFile(File file) throws MactorException {
		if (!file.exists())
			throw new MactorException("The specifed sql script file '" + file.getAbsolutePath() + "' does not exist");
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			StringBuffer command = new StringBuffer();
			String line = br.readLine();
			while (line != null) {
				command.append(line).append("\n");
				line = br.readLine();
			}
			return command.toString();
		} catch (IOException ioe) {
			throw new MactorException("IO exception while reading the sql script file '" + file.getAbsolutePath() + "'. Error: " + ioe.getMessage(), ioe);
		}
	}
	public DataTable execQuerySql(String sql) throws MactorException {
		Connection conn = getConnection();
		try {
			return execQuery(conn, sql);
		} catch (SQLException sqle) {
			throw new MactorException("Failed to execute the query '" + sql + "'. Error: " + sqle.getMessage(), sqle);
		} finally {
			close(conn);
		}
	}
	public DataTable execScriptQuery(File file) throws MactorException {
		return execQuerySql(getExpressionFromFile(file));
	}
	public void execScript(File file, boolean ignoreSqlException) throws MactorException {
		if (!file.exists())
			throw new MactorException("The specifed sql script file '" + file.getAbsolutePath() + "' does not exist");
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String line = br.readLine();
			StringBuffer command = new StringBuffer();
			boolean inBlock = false;
			Connection conn = null;
			try {
				conn = getConnection();
				while (line != null) {
					line = line.trim();
					if (line.length() > 0) {
						if (line.equals("/") && inBlock) {
							inBlock = false;
							execUpdate(conn, command.toString(), ignoreSqlException);
							command = new StringBuffer();
						} else if (line.equals("--/")) {
							inBlock = true;
						} else if (inBlock) {
							command.append(line).append("\n");
						} else {
							if (line.endsWith(";")) {
								command.append(line.substring(0, line.length() - 1)).append("\n");
								execUpdate(conn, command.toString(), ignoreSqlException);
								command = new StringBuffer();
							} else {
								command.append(line).append("\n");
							}
						}
					}
					line = br.readLine();
				}
			} finally {
				close(conn);
			}
		} catch (IOException ioe) {
			throw new MactorException("IO exception while reading the sql script file '" + file.getAbsolutePath() + "'. Error: " + ioe.getMessage(), ioe);
		}
	}
	public void execUpdateSql(String sql) throws MactorException {
		Connection conn = getConnection();
		try {
			execUpdate(conn, sql, false);
		} finally {
			close(conn);
		}
	}
	public String execSingleCellQuerySql(String sql) throws MactorException {
		log.debug("Executing query:" + sql);
		Connection conn = getConnection();
		try {
			return execSingleCellQuery(conn, sql);
		} catch (SQLException sqle) {
			throw new MactorException("Failed to execute the query '" + sql + "'. Error: " + sqle.getMessage(), sqle);
		} finally {
			close(conn);
		}
	}
	private void execUpdate(Connection conn, String sql, boolean ignoreSqlException) throws MactorException {
		log.debug("Executing update:" + sql);
		Statement s = null;
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			close(s);
		} catch (SQLException sqle) {
			MactorException me = new MactorException("Failed to execute the update '" + sql + "'. Error: " + sqle.getMessage(), sqle);
			if (!ignoreSqlException)
				throw me;
			log.info("Ignoring:" + me.getMessage(), sqle);
		} finally {
			close(s);
		}
	}
	private void close(Connection s) {
		if (s != null) {
			try {
				s.close();
			} catch (SQLException _) {
			}
		}
	}
	private void close(Statement s) {
		if (s != null) {
			try {
				s.close();
			} catch (SQLException _) {
			}
		}
	}
	private void close(ResultSet s) {
		if (s != null) {
			try {
				s.close();
			} catch (SQLException _) {
			}
		}
	}
	private String execSingleCellQuery(Connection conn, String sql) throws SQLException {
		Statement s = null;
		ResultSet rs = null;
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			if (!rs.next()) {
				log.info("no rows");
				return null;
			} else {
				ResultSetMetaData md = rs.getMetaData();
				if (md.getColumnCount() > 0) {
					return rs.getString(1);
				} else {
					log.info("no colums");
				}
			}
			return null;
		} finally {
			close(rs);
			close(s);
		}
	}
	private DataTable execQuery(Connection conn, String sql) throws SQLException {
		Statement s = null;
		ResultSet rs = null;
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			if (!rs.next()) {
				log.info("no rows");
				return null;
			} else {
				ResultSetMetaData md = rs.getMetaData();
				int count = md.getColumnCount();
				if (count == 0) {
					log.info("no colums");
					return null;
				} else {
					DataTable table = new DataTable();
					for (int i = 1; i <= count; i++) {
						table.addColumn(md.getColumnName(i));
					}
					do {
						String[] row = new String[count];
						for (int i = 1; i <= count; i++) {
							row[i - 1] = rs.getString(i);
						}
						table.addRow(row);
					} while (rs.next());
					return table;
				}
			}
		} finally {
			close(rs);
			close(s);
		}
	}
}
