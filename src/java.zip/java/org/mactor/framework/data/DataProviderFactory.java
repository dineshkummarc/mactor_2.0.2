/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.data;

import org.mactor.framework.MactorException;

public class DataProviderFactory {
	public static final String SQL = "sql";
	public static final String FILE = "file";
	public static DataProvider getDataProvider(String dataSource) throws MactorException {
		String[] parts = parse(dataSource);
		if (FILE.equals(parts[0]))
			return new CsvDataProvider(parts[1]);
		else if (SQL.equals(parts[0]))
			return new SqlDataProvider(parts[1]);
		else {
			throw new MactorException("Unsupported data source type '" + parts[0] + "'");
		}
	}
	private static String[] parse(String dataSource) throws MactorException {
		if (dataSource == null || dataSource.trim().length() == 0)
			throw new MactorException("Unparseable data source string '" + dataSource + "'");
		String[] parsed = new String[2];
		int split = dataSource.indexOf(":");
		if (split < 0 || split + 2 >= dataSource.length())
			throw new MactorException("Unparseable data source string '" + dataSource + "'");
		parsed[0] = dataSource.substring(0, split);
		parsed[1] = dataSource.substring(split + 1, dataSource.length());
		return parsed;
	}
}
