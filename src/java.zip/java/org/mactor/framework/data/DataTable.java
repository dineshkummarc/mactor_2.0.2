/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.data;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataTable {
	private List<String> columns = new ArrayList<String>();
	private List<DataRow> rows = new ArrayList<DataRow>();
	private Map<String, Integer> columnIndexMap = new HashMap<String, Integer>();
	public void setColumns(List<String> columns) {
		this.columns = new ArrayList<String>();
		columnIndexMap.clear();
		for (String col : columns) {
			addColumn(col);
		}
	}
	public void addColumn(String column) {
		columnIndexMap.put(column, new Integer(columns.size()));
		columns.add(column);
	}
	public int getColumnCount() {
		return columns.size();
	}
	public String getColumn(int index) {
		return columns.get(index);
	}
	public Map<String, String> getRowData(int rowIndex) {
		Map<String, String> map = new HashMap<String, String>();
		int colCount = getColumnCount();
		for (int j = 0; j < colCount; j++) {
			String col = getColumn(j);
			map.put(col, getValue(rowIndex, col));
		}
		return map;
	}
	public void addRow(List<String> cellValues) {
		rows.add(new DataRow(cellValues));
	}
	public void addRow(String[] cellValues) {
		rows.add(new DataRow(Arrays.asList(cellValues)));
	}
	public int getRowCount() {
		return rows.size();
	}
	public String getValue(int row, String columnName) {
		Integer index = columnIndexMap.get(columnName);
		if (index == null)
			return null;
		return getValue(row, index.intValue());
	}
	public String getValue(int row, int column) {
		if (row >= rows.size())
			return null;
		return rows.get(row).getValue(column);
	}
	public static class DataRow {
		private List<String> values = new ArrayList<String>();
		public DataRow() {
		}
		public DataRow(List<String> values) {
			this.values = new ArrayList<String>(values);
		}
		public String getValue(int colIndex) {
			if (colIndex >= values.size())
				return null;
			return values.get(colIndex);
		}
	}
	public String toString() {
		StringWriter sw = new StringWriter();
		try {
			writeAsCsv(sw);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sw.toString();
	}
	public void writeAsHtml(Writer out) throws IOException {
		out.write("\n<table>\n");
		out.write("<tr>");
		for (String col : columns) {
			out.write("<td>");
			out.write(col);
			out.write("</td>");
		}
		out.write("</tr>\n");
		for (DataRow row : rows) {
			out.write("<tr>");
			for (String val : row.values) {
				out.write("<td>");
				out.write(val);
				out.write("</td>");
			}
			out.write("</tr>\n");
		}
		out.write("</table>\n<br/><br/>");
	}
	public void writeAsCsv(Writer out) throws IOException {
		for (int i = 0; i < columns.size(); i++) {
			out.write(columns.get(i));
			if (i < columns.size() - 1)
				out.write(";");
		}
		for (DataRow row : rows) {
			out.write("\n");
			for (int i = 0; i < row.values.size(); i++) {
				out.write(row.values.get(i));
				if (i < row.values.size() - 1)
					out.write(";");
			}
		}
		out.write("\n");
	}
}
