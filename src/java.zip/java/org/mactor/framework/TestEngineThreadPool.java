/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.util.LinkedList;

import org.apache.log4j.Logger;

// This primitive pool will grow to the max allowed threads and stay there
public class TestEngineThreadPool {
	static Logger log = Logger.getLogger(TestEngineThreadPool.class);
	private int maxNumberOfThreads;
	private boolean stopped = false;
	public TestEngineThreadPool(int maxNumberOfThreads) {
		this.maxNumberOfThreads = maxNumberOfThreads;
	}
	LinkedList<Worker> idleWorkers = new LinkedList<Worker>();
	LinkedList<Worker> activeWorkers = new LinkedList<Worker>();
	private Object lock = new Object();
	public void terminate() {
		log.debug("Stopping test-engine thread pool...");
		stopped = true;
		synchronized (lock) {
			for (Worker w : activeWorkers) {
				w.stop();
			}
		}
		log.debug("Thread pool stopped");
	}
	private Worker getIdleWorker() throws InterruptedException {
		synchronized (lock) {
			for (; !stopped;) {
				if (idleWorkers.size() > 0) {
					Worker w = idleWorkers.removeLast();
					activeWorkers.add(w);
					return w;
				} else if ((activeWorkers.size() + idleWorkers.size()) < maxNumberOfThreads) {
					Worker w = new Worker();
					activeWorkers.add(w);
					new Thread(w).start();
					return w;
				}
				lock.wait();
			}
		}
		return null;
	}
	/**
	 * Block until thread is available
	 * 
	 * @param runnable
	 */
	public void addJob(TestRunnable runnable) {
		try {
			synchronized (lock) {
				Worker w = getIdleWorker();
				if (w == null)
					throw new RuntimeException("The thread pool has been stopped. No more jobs can be added");
				w.assignJob(runnable);
			}
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
	}
	public void join() {
		try {
			synchronized (lock) {
				for (;;) {
					if (activeWorkers.size() == 0)
						break;
					lock.wait();
				}
				stopped = true;
			}
			for (Worker w : idleWorkers) {
				w.stop();
			}
		} catch (InterruptedException ie) {
		}
	}
	private void completed(Worker w) {
		synchronized (lock) {
			if (!activeWorkers.remove(w))
				throw new RuntimeException("Unexpected state");
			idleWorkers.add(w);
			lock.notifyAll();
		}
		log.debug("active:" + activeWorkers.size());
	}
	private class Worker implements Runnable {
		TestRunnable job;
		TestRunnable runningJob;
		private Object lock = new Object();
		public void run() {
			while (!stopped) {
				try {
					synchronized (lock) {
						if (job != null)
							runningJob = job;
						else
							lock.wait();
						if (job != null)
							runningJob = job;
						job = null;
					}
					if (runningJob != null) {
						try {
							runningJob.run();
						} finally {
							runningJob = null;
							completed(this);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		public void stop() {
			log.debug("Stopping test-engine worker");
			TestRunnable tmp = runningJob;
			if (tmp != null)
				tmp.stop();
		}
		public void assignJob(TestRunnable job) {
			synchronized (this.lock) {
				this.job = job;
				this.lock.notifyAll();
			}
		}
	}
	public static class TestRunnable implements Runnable {
		boolean succes = false;
		int index;
		TestEngine testEngine;
		public TestRunnable(int index, TestEngine testEngine) {
			this.index = index;
			this.testEngine = testEngine;
		}
		public boolean isSucces() {
			return succes;
		}
		public void stop() {
			testEngine.stop();
		}
		public void run() {
			try {
				testEngine.runTest(index);
				this.succes = true;
			} catch (MactorException ce) {
				ce.printStackTrace();
			}
		}
	}
}