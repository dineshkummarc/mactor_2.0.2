/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.commandexecutors.shell;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;

public class ExecUtil {
	public static void executeCommand(String command) throws MactorException {
		try {
			Runtime r = Runtime.getRuntime();
			Process p = r.exec(command, null, ProjectContext.getGlobalInstance().getProjectDir());
			int exitCode = p.waitFor();
			if (exitCode != 0) {
				throw new MactorException("Command '" + command + "' failed. Exit code: '" + exitCode + "'");
			}
		} catch (IOException ioe) {
			throw new MactorException("Failed to execute command '" + command + "'. Error:" + ioe.getMessage(), ioe);
		} catch (InterruptedException ie) {
			throw new MactorException("Failed to execute command '" + command + "'. Error:" + ie.getMessage(), ie);
		}
	}
	public static String executeCommandWithOutput(String command) throws MactorException {
		StringBuffer sb = new StringBuffer();
		try {
			Runtime r = Runtime.getRuntime();
			Process p = r.exec(command, null, ProjectContext.getGlobalInstance().getProjectDir());
			BufferedInputStream bis = new BufferedInputStream(p.getInputStream());
			BufferedReader br = new BufferedReader(new InputStreamReader(bis));
			char[] buffer = new char[1000];
			for (;;) {
				int count = br.read(buffer, 0, buffer.length);
				if (count > 0) {
					sb.append(buffer, 0, count);
				} else {
					break;
				}
			}
			int exitCode = p.waitFor();
			if (exitCode != 0) {
				throw new MactorException("Command '" + command + "' failed. Exit code: '" + exitCode + "'");
			}
			return sb.toString();
		} catch (IOException ioe) {
			throw new MactorException("Failed to execute command '" + command + "'. Error:" + ioe.getMessage(), ioe);
		} catch (InterruptedException ie) {
			throw new MactorException("Failed to execute command '" + command + "'. Error:" + ie.getMessage(), ie);
		}
	}
}
