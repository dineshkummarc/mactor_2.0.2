/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.commandexecutors;

import java.util.List;

import org.mactor.framework.MactorException;
import org.mactor.framework.TestContextImpl;
import org.mactor.framework.commandexecutors.bsh.BshValueCommandExecutor;
import org.mactor.framework.commandexecutors.java.JavaValueCommandExecutor;
import org.mactor.framework.commandexecutors.java.SequenceValueCommandExecutor;
import org.mactor.framework.commandexecutors.shell.ShellValueCommandExecutor;
import org.mactor.framework.commandexecutors.sql.SqlValueCommandExecutor;
import org.mactor.framework.spec.ValueSpec;

public class ValueCommandExecutorFactory {
	public static ValueCommandExecutor createExecutor(TestContextImpl context, ValueSpec spec) throws MactorException {
		String[] parsed = FactoryUtil.parseCommand(context.substitute(spec.getCommand()));
		List<String> params = context.substitute(spec.getParams());
		ValueCommandExecutor c = null;
		if (FactoryUtil.JAVA.equalsIgnoreCase(parsed[0])) {
			c = new JavaValueCommandExecutor(parsed[1], params);
		} else if (FactoryUtil.SHELL.equalsIgnoreCase(parsed[0])) {
			c = new ShellValueCommandExecutor(parsed[1], params);
		} else if (FactoryUtil.SEQUENCE.equalsIgnoreCase(parsed[0])) {
			c = new SequenceValueCommandExecutor(parsed[1], params);
		} else if (FactoryUtil.SQL.equalsIgnoreCase(parsed[0])) {
			c = new SqlValueCommandExecutor(parsed[1]);
		} else if (FactoryUtil.BSH.equalsIgnoreCase(parsed[0])) {
			c = new BshValueCommandExecutor(parsed[1]);
		} else {
			throw new MactorException("Unsupported command type '" + parsed[0] + "'");
		}
		return c;
	}
}
