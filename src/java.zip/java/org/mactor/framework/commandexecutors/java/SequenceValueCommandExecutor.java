/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.commandexecutors.java;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mactor.framework.MactorException;
import org.mactor.framework.ParseUtil;
import org.mactor.framework.TestContextImpl;
import org.mactor.framework.commandexecutors.ValueCommandExecutor;

public class SequenceValueCommandExecutor implements ValueCommandExecutor {
	private static Map<String, Sequence> seqMap = new HashMap<String, Sequence>();
	private String prefix = "";
	private String name;
	private static Object lock = new Object();
	public SequenceValueCommandExecutor(String command, List<String> params) {
		this.name = command;
		Integer start = null;
		if (params != null && params.size() > 0)
			start = ParseUtil.tryParseInt(params.get(0));
		long n = 0;
		if (start != null)
			n = start.longValue();
		else
			n = System.currentTimeMillis();
		synchronized (lock) {
			if (!seqMap.containsKey(name)) {
				seqMap.put(name, new Sequence(n));
			}
		}
	}
	public String extractValue(TestContextImpl context) throws MactorException {
		Sequence seq = null;
		synchronized (lock) {
			seq = seqMap.get(name);
		}
		return prefix + seq.next();
	}
	private static class Sequence {
		private long seq;
		public Sequence(long start) {
			this.seq = start;
		}
		public synchronized long next() {
			return ++seq;
		}
	}
}
