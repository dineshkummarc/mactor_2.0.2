/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.commandexecutors;

import java.util.List;

import org.mactor.framework.MactorException;
import org.mactor.framework.TestContextImpl;
import org.mactor.framework.commandexecutors.bsh.BshMessageBuilderCommandExecutor;
import org.mactor.framework.commandexecutors.java.JavaMessageBuilderCommandExecutor;
import org.mactor.framework.commandexecutors.shell.ShellMessageBuilderCommandExecutor;
import org.mactor.framework.spec.MessageBuilderSpec;
import org.mactor.framework.spec.ProjectContext;

public class MessageBuilderCommandExecutorFactory {
	public static MessageBuilderCommandExecutor createExecutor(TestContextImpl context, MessageBuilderSpec spec) throws MactorException {
		String[] parsed = FactoryUtil.parseCommand(context.substitute(spec.getCommand()));
		List<String> params = context.substitute(spec.getParams());
		String templatePath = ProjectContext.getGlobalInstance().getAbsolutePath(context.substitute(spec.getTemplatePath())).getAbsolutePath();
		MessageBuilderCommandExecutor c = null;
		if (FactoryUtil.JAVA.equalsIgnoreCase(parsed[0])) {
			c = new JavaMessageBuilderCommandExecutor(parsed[1], params, templatePath);
		} else if (FactoryUtil.SHELL.equalsIgnoreCase(parsed[0])) {
			c = new ShellMessageBuilderCommandExecutor(parsed[1], params, templatePath);
		} else if (FactoryUtil.BSH.equalsIgnoreCase(parsed[0])) {
			c = new BshMessageBuilderCommandExecutor(parsed[1], params, templatePath);
		} else {
			throw new MactorException("Unsupported command type '" + parsed[0] + "'");
		}
		return c;
	}
}
