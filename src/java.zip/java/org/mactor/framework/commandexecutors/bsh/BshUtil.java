/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.commandexecutors.bsh;

import java.io.File;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.mactor.framework.MactorException;
import org.mactor.framework.TestContextImpl;
import org.mactor.framework.spec.ProjectContext;

import bsh.EvalError;
import bsh.Interpreter;
import bsh.ParseException;
import bsh.TargetError;

public class BshUtil {
	public static Object executeCommand(Map<String, Object> variables, String scriptFilename, TestContextImpl context) throws MactorException {
		File path = ProjectContext.getGlobalInstance().getAbsolutePath(scriptFilename);
		if (!path.exists())
			throw new MactorException("The specifed BeanShell script '" + path.getAbsolutePath() + "' does not exist");
		String script = ProjectContext.getGlobalInstance().readStringFromFile(scriptFilename, false);
		if (context != null) {
			script = context.substitute(script);
		}
		try {
			Interpreter i = new Interpreter();
			Iterator<Entry<String, Object>> it = variables.entrySet().iterator();
			while (it.hasNext()) {
				Entry<String, Object> e = it.next();
				i.set(e.getKey(), e.getValue());
			}
			return i.eval(script);
		} catch (TargetError e) {
			throw new MactorException("Failed to execute the BeanShell script '" + path.getAbsolutePath() + "'. The script valid, but an exception was thrown while exceuting the script. Line:"
					+ e.getErrorLineNumber() + ". Description: " + e.getErrorText() + ". Cause:" + e.getTarget());
		} catch (ParseException e) {
			throw new MactorException("Failed to execute the BeanShell script '" + path.getAbsolutePath() + "'. The script has a syntactic error:" + e);
		} catch (EvalError e) {
			throw new MactorException("Failed to execute the BeanShell script '" + path.getAbsolutePath() + "'. Error in scrip:" + e);
		}
	}
}
