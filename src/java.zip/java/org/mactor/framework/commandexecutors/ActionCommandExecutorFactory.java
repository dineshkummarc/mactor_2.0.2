/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.commandexecutors;

import java.util.List;

import org.mactor.framework.MactorException;
import org.mactor.framework.TestContextImpl;
import org.mactor.framework.commandexecutors.bsh.BshActionCommandExecutor;
import org.mactor.framework.commandexecutors.java.JavaActionCommandExecutor;
import org.mactor.framework.commandexecutors.shell.ShellActionCommandExecutor;
import org.mactor.framework.commandexecutors.sql.SqlActionCommandExecutor;
import org.mactor.framework.spec.ActionSpec;

public class ActionCommandExecutorFactory {
	public static ActionCommandExecutor createExecutor(TestContextImpl context, ActionSpec spec) throws MactorException {
		String[] parsed = FactoryUtil.parseCommand(context.substitute(spec.getCommand()));
		List<String> params = context.substitute(spec.getParams());
		ActionCommandExecutor c = null;
		if (FactoryUtil.JAVA.equalsIgnoreCase(parsed[0])) {
			c = new JavaActionCommandExecutor(parsed[1], params);
		} else if (FactoryUtil.SHELL.equalsIgnoreCase(parsed[0])) {
			c = new ShellActionCommandExecutor(parsed[1], params);
		} else if (FactoryUtil.SQL.equalsIgnoreCase(parsed[0])) {
			c = new SqlActionCommandExecutor(parsed[1], params);
		} else if (FactoryUtil.BSH.equalsIgnoreCase(parsed[0])) {
			c = new BshActionCommandExecutor(parsed[1], params);
		} else {
			throw new MactorException("Unsupported command type '" + parsed[0] + "'");
		}
		return c;
	}
}
