/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.mactor.brokers.Message;
import org.mactor.brokers.MessageBrokerManager;
import org.mactor.brokers.MessageSubscriber;
import org.mactor.framework.TestEvent.EventType;
import org.mactor.framework.commandexecutors.ActionCommandExecutor;
import org.mactor.framework.commandexecutors.ActionCommandExecutorFactory;
import org.mactor.framework.commandexecutors.MessageBuilderCommandExecutorFactory;
import org.mactor.framework.commandexecutors.MessageSelectorCommandExecutorFactory;
import org.mactor.framework.commandexecutors.ValueCommandExecutor;
import org.mactor.framework.commandexecutors.ValueCommandExecutorFactory;
import org.mactor.framework.spec.ActionSpec;
import org.mactor.framework.spec.ConditionSpec;
import org.mactor.framework.spec.LoopSpec;
import org.mactor.framework.spec.MessagePublishSpec;
import org.mactor.framework.spec.MessageReceiveSpec;
import org.mactor.framework.spec.MessageRespondSpec;
import org.mactor.framework.spec.MessageSubscribeSpec;
import org.mactor.framework.spec.SpecNode;
import org.mactor.framework.spec.TestSpec;
import org.mactor.framework.spec.ValueSpec;

/**
 * The test-runner implementation
 * 
 * @author Lars Ivar Almli
 */
public class TestEngine {
	protected static Logger log = Logger.getLogger(TestEngine.class);
	protected static Logger test_timing_log = Logger.getLogger("test_timing");
	private TestContextImpl context;
	private TestFeedbackListener feedbackListener;
	private MessageBrokerManager brokerManager;
	private Map<String, MessageWaiter> messageWaiters = new HashMap<String, MessageWaiter>();
	private TestSpec testSpec;
	private int testDataIndex;
	private String testInstanceId = AppUtil.getNextId("TI");
	private String testRunInstanceId;
	public void stop() {
		log.debug("Stopping test engine instance");
		cleanUp();
	}
	private synchronized void cleanUp() {
		try {
			for (MessageWaiter mw : messageWaiters.values()) {
				try {
					this.brokerManager.unsubscribe(mw.getChannel(), mw);
					mw.stop();
				} catch (Exception e) {
					log.error("Failed to unsubscribe", e);
				}
				mw.stop();
			}
			messageWaiters.clear();
		} catch (Exception e) {
			log.error("Failed to stop test engine instance", e);
		}
	}
	public TestEngine(String testRunInstanceId, TestContextImpl context, TestFeedbackListener feedbackListener) throws MactorException {
		this.context = context;
		this.testRunInstanceId = testRunInstanceId;
		this.brokerManager = MessageBrokerManager.getInstance();
		this.testSpec = context.getTestSpec();
		this.feedbackListener = feedbackListener;
	}
	private void reportNodeStart(SpecNode node) {
		feedbackListener.onNodeEvent(new TestEvent(testRunInstanceId, testInstanceId, EventType.Start, testSpec, node, testDataIndex, null, true, null), context);
	}
	private void reportSuccessfulNodeEnd(SpecNode node, String output) {
		feedbackListener.onNodeEvent(new TestEvent(testRunInstanceId, testInstanceId, EventType.End, testSpec, node, testDataIndex, output, true, null), context);
	}
	private void reportFaultyNodeEnd(SpecNode node, String output, MactorException cause) {
		feedbackListener.onNodeEvent(new TestEvent(testRunInstanceId, testInstanceId, EventType.End, testSpec, node, testDataIndex, output, false, cause), context);
	}
	private void reportTerminated(boolean success, MactorException cause) {
		feedbackListener.onNodeEvent(new TestEvent(testRunInstanceId, testInstanceId, EventType.End, testSpec, testSpec, testDataIndex, null, success, cause), context);
	}
	private void reportTestStart() {
		feedbackListener.onNodeEvent(new TestEvent(testRunInstanceId, testInstanceId, EventType.Start, testSpec, testSpec, testDataIndex, null, true, null), context);
	}
	public void runTest(int testDataIndex) throws MactorException {
		this.testDataIndex = testDataIndex;
		if (testSpec.getDelayBeforeStartSeconds() != 0)
			sleep(testSpec.getDelayBeforeStartSeconds() * 1000);
		reportTestStart();
		MactorException ex = null;
		try {
			try {
				doNodes(testSpec.getSpecNodes());
			} catch (MactorException e) {
				ex = e;
				throw e;
			}
		} finally {
			cleanUp();
			reportTerminated(ex == null, ex);
		}
	}
	private void doNodes(List<SpecNode> nodes) throws MactorException {
		for (SpecNode node : nodes) {
			try {
				reportNodeStart(node);
				doNode(node);
				reportSuccessfulNodeEnd(node, "Success");
			} catch (MactorException ce) {
				reportFaultyNodeEnd(node, "Error", ce);
				throw ce;
			} catch (RuntimeException e) {
				MactorException re = new MactorException(e);
				reportFaultyNodeEnd(node, "Runtime error", re);
				throw re;
			}
		}
	}
	private void doNode(SpecNode node) throws MactorException {
		if (log.isDebugEnabled())
			log.debug("starting on node " + node.getName());
		long nodeStartTime = 0;
		Exception ex = null;
		if (test_timing_log.isInfoEnabled()) {
			nodeStartTime = System.currentTimeMillis();
		}
		try {
			if (node instanceof MessageSubscribeSpec) {
				doMessageSubscribeNode((MessageSubscribeSpec) node);
			} else if (node instanceof MessagePublishSpec) {
				doMessagePublishNode((MessagePublishSpec) node);
			} else if (node instanceof MessageReceiveSpec) {
				doMessageReceiveNode((MessageReceiveSpec) node);
			} else if (node instanceof ValueSpec) {
				doValueNode((ValueSpec) node);
			} else if (node instanceof ActionSpec) {
				doActionNode((ActionSpec) node);
			} else if (node instanceof MessageRespondSpec) {
				doMessageResponseNode((MessageRespondSpec) node);
			} else if (node instanceof LoopSpec) {
				doLoopNode((LoopSpec) node);
			} else if (node instanceof ConditionSpec) {
				doConditionNode((ConditionSpec) node);
			} else {
				throw new MactorException("Unsupported node:" + node.getName());
			}
		} catch (MactorException me) {
			ex = me;
			if (log.isDebugEnabled())
				log.debug("%%%%% NODE: " + node.getName());
			throw me;
		} catch (RuntimeException re) {
			ex = re;
			throw re;
		} finally {
			if (test_timing_log.isInfoEnabled()) {
				test_timing_log.info(testRunInstanceId + ";" + testInstanceId + ";" + node.getName() + ";" + (ex == null) + ";" + (System.currentTimeMillis() - nodeStartTime));
			}
		}
	}
	private void doMessageSubscribeNode(MessageSubscribeSpec spec) throws MactorException {
		MessageWaiter mw = new MessageWaiter(spec.getChannel());
		if (messageWaiters.containsKey(spec.getName()))
			throw new RuntimeException("Unexpected state");
		messageWaiters.put(spec.getName(), mw);
		this.brokerManager.subscribe(spec.getChannel(), mw, MessageSelectorCommandExecutorFactory.createExecutor(context, spec.getMessageSelector()));
	}
	private void doMessagePublishNode(MessagePublishSpec spec) throws MactorException {
		Message message = MessageBuilderCommandExecutorFactory.createExecutor(context, ((MessagePublishSpec) spec).getMessageBuilder()).buildMessage(context);
		message.getMessageContextInfo().setNode(spec);
		context.addOutgoingMessage(spec.getName(), message);
		Message response = this.brokerManager.publish(spec.getChannel(), message);
		if (response != null) {
			context.addReceivedMessage(spec.getName(), response);
		}
	}
	private void doMessageReceiveNode(MessageReceiveSpec spec) throws MactorException {
		MessageWaiter mw = messageWaiters.get(spec.getMessageSubscribeNodeName());
		mw.start(spec.getMaxTimeoutSeconds(), spec.getMinMessageCount(), spec.getMaxMessageCount(), spec.isBlockUntilTimeout());
		while (true) {
			IncomingMessage im = null;
			try {
				im = mw.getMessage();
				if (im == null)
					break;
				im.getMessage().getMessageContextInfo().setNode(spec);
				if (spec.hasResponseNode())
					pushPendingMessage(im);
				context.addReceivedMessage(spec.getName(), im.message);
				doNodes(spec.getSpecNodes());
				im.completed();
			} catch (Throwable t) {
				if (im != null)
					im.canceled();
				if (t instanceof MactorException)
					throw (MactorException) t;
				else
					throw new MactorException(t);
			}
		}
	}
	private void doLoopNode(LoopSpec spec) throws MactorException {
		int count = spec.getCount();
		if (count == 0)
			count = Integer.MAX_VALUE;
		for (int i = 0; i < count; i++) {
			doNodes(spec.getSpecNodes());
		}
	}
	private void doConditionNode(ConditionSpec spec) throws MactorException {
		if (Boolean.parseBoolean(context.substitute(spec.getExecute()))) {
			doNodes(spec.getSpecNodes());
		}
	}
	private void doMessageResponseNode(MessageRespondSpec spec) throws MactorException {
		Message responseMessage = MessageBuilderCommandExecutorFactory.createExecutor(context, ((MessageRespondSpec) spec).getMessageBuilder()).buildMessage(context);
		context.addOutgoingMessage(spec.getName(), responseMessage);
		popPendingMessage().setResponseMessage(responseMessage);
	}
	private LinkedList<IncomingMessage> pendingMessages = new LinkedList<IncomingMessage>();
	private IncomingMessage popPendingMessage() {
		return pendingMessages.removeLast();
	}
	private void pushPendingMessage(IncomingMessage rw) {
		pendingMessages.addLast(rw);
	}
	private void doValueNode(ValueSpec spec) throws MactorException {
		ValueCommandExecutor vce = ValueCommandExecutorFactory.createExecutor(context, spec);
		context.setValue(spec.getName(), vce.extractValue(context));
	}
	private void doActionNode(ActionSpec spec) throws MactorException {
		ActionCommandExecutor vce = ActionCommandExecutorFactory.createExecutor(context, spec);
		vce.perform(context);
	}
	public static class IncomingMessage {
		Message message;
		Message responseMessage;
		boolean complete = false;
		public IncomingMessage(Message message) {
			this.message = message;
		}
		public void setResponseMessage(Message responseMessage) {
			this.responseMessage = responseMessage;
		}
		private Object lock = new Object();
		public void completed() {
			synchronized (lock) {
				complete = true;
				message.consume();
				lock.notifyAll();
			}
		}
		public void canceled() {
			synchronized (lock) {
				complete = true;
				lock.notifyAll();
			}
		}
		Message waitForCompletion() throws InterruptedException {
			synchronized (lock) {
				if (!complete)
					lock.wait();
			}
			return responseMessage;
		}
		public Message getMessage() {
			return message;
		}
	}
	public static class MessageWaiter implements MessageSubscriber {
		private LinkedList<IncomingMessage> messages = new LinkedList<IncomingMessage>();
		private int maxMessageCount;
		private int minMessageCount;
		private int maxTimeoutSeconds;
		private boolean blockUntilTimeout;
		private Object lock = new Object();
		private int count;
		private int returnedCount;
		private long timeStart;
		private String channel;
		private boolean stopped = false;
		public String getChannel() {
			return channel;
		}
		public MessageWaiter(String channel) {
			this.channel = channel;
		}
		public void stop() {
			synchronized (lock) {
				stopped = true;
				lock.notifyAll();
			}
			for (IncomingMessage m : messages) {
				m.canceled();
			}
		}
		public void start(int maxTimeoutSeconds, int minMessageCount, int maxMessageCount, boolean blockUntilTimeout) {
			this.returnedCount = 0;
			this.maxTimeoutSeconds = maxTimeoutSeconds;
			this.minMessageCount = minMessageCount;
			this.maxMessageCount = maxMessageCount;
			this.blockUntilTimeout = blockUntilTimeout;
			this.timeStart = System.currentTimeMillis();
			if (maxTimeoutSeconds == 0)
				this.maxTimeoutSeconds = 60 * 60 * 24 * 365; // a year
			if (maxMessageCount == 0)
				this.maxMessageCount = 1000000000; // one billion
		}
		public Message onMessage(Message message) {
			try {
				IncomingMessage im = new IncomingMessage(message);
				synchronized (lock) {
					if (stopped) {
						lock.notifyAll();
						return null;
					}
					this.messages.add(im);
					count++;
					lock.notifyAll();
				}
				return im.waitForCompletion();
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		public IncomingMessage getMessage() throws MessageTimoutException {
			while (!stopped) {
				if (this.returnedCount >= this.maxMessageCount)
					return null;
				if (!blockUntilTimeout && this.returnedCount >= this.minMessageCount)
					return null;
				long timeLeft = maxTimeoutSeconds * 1000 - (System.currentTimeMillis() - timeStart);
				if (timeLeft <= 0) {
					if (this.returnedCount >= this.minMessageCount)
						return null;
					else
						throw new MessageTimoutException("Timout reached after receiving " + this.returnedCount + " messages");
				}
				try {
					synchronized (lock) {
						if (messages.size() > 0) {
							IncomingMessage m = messages.removeLast();
							returnedCount++;
							return m;
						} else if (timeLeft > 0) {
							lock.wait(timeLeft);
						}
						if (messages.size() > 0) {
							IncomingMessage m = messages.removeLast();
							returnedCount++;
							return m;
						}
					}
				} catch (InterruptedException ie) {
					throw new RuntimeException(ie);
				}
			}
			log.debug("Message Worker was stopped");
			return null;
		}
	}
	private void sleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException ie) {
		}
	}
}