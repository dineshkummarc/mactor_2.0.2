/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.mactor.brokers.MessageBroker;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;

public class ReflectionUtil {
	public static Object createInstance(String className) throws MactorException {
		try {
			Class c = Class.forName(className);
			return c.newInstance();
		} catch (ClassNotFoundException cnf) {
			throw new MactorException("The class '" + className + "' was not found in the classpath", cnf);
		} catch (InstantiationException ie) {
			throw new MactorException("Unable to create objects from '" + className + "'. Check that the class has a default contructor", ie);
		} catch (IllegalAccessException iae) {
			throw new MactorException("Unable to create objects from '" + className + "'. Illegal access", iae);
		}
	}
	public static MessageBroker createMessageBroker(MessageBrokerConfig config) throws MactorException {
		String className = config.getBrokerClass();
		try {
			Class c = Class.forName(className);
			Constructor ct = c.getConstructor(new Class[] { MessageBrokerConfig.class });
			Object mb = ct.newInstance(new Object[] { config });
			if (!(mb instanceof MessageBroker))
				throw new MactorException("The specified message broker class does not implement '" + MessageBroker.class.getName() + "'");
			return (MessageBroker) mb;
		} catch (ClassNotFoundException cnf) {
			throw new MactorException("The specified MessageBroker implementation was not found in the class path. Class '" + className + "'", cnf);
		} catch (NoSuchMethodException nm) {
			throw new MactorException("The specified MessageBroker implementation class '" + className + "' does not have the requiered contructor (that takes a single arguemtn of type '"
					+ MessageBrokerConfig.class.getName() + "')", nm);
		} catch (IllegalAccessException iae) {
			throw new MactorException("Unable to instantiate the MessageBroker '" + className + "'. Illegal access", iae);
		} catch (InvocationTargetException it) {
			throw new MactorException("Unable to instantiate the MessageBroker '" + className + "'. InvocationTargetException", it);
		} catch (InstantiationException ie) {
			throw new MactorException("Unable to instantiate the MessageBroker '" + className + "'. InstantiationException", ie);
		}
	}
}
