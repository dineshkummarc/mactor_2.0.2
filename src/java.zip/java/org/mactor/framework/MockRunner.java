/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.util.List;

import org.apache.log4j.Logger;
import org.mactor.framework.TestEngineThreadPool.TestRunnable;
import org.mactor.framework.spec.GlobalConfig;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.framework.spec.TestSpec;

/**
 * 
 * @author Lars Ivar Almli
 */
public class MockRunner {
	protected static Logger log = Logger.getLogger(MockRunner.class);
	private boolean stopped = false;
	int numberOfTestThreads;
	List<TestSpec> testSpecs;
	TestEngineThreadPool pool;
	int errorCount = 0;
	GlobalConfig gc;
	EventReporter reporter;
	private String mockInstanceId = AppUtil.getNextId("M");
	public MockRunner(int numberOfTestThreads, List<TestSpec> testSpecs, TestFeedbackListener fl) throws MactorException {
		super();
		if (numberOfTestThreads < 1)
			numberOfTestThreads = 1;
		reporter = new EventReporter(mockInstanceId, fl);
		this.numberOfTestThreads = numberOfTestThreads;
		this.testSpecs = testSpecs;
		pool = new TestEngineThreadPool(numberOfTestThreads);
		gc = ProjectContext.getGlobalInstance().loadGlobalConfig();
	}
	boolean started = false;
	public void start() throws MactorException {
		if (started)
			throw new MactorException("The mock runner can only be used once");
		started = true;
		new Thread(new Runnable() {
			public void run() {
				runMock();
			}
		}).start();
	}
	private void runMock() {
		try {
			reporter.start();
			while (!stopped) {
				for (TestSpec ts : testSpecs) {
					if (stopped)
						break;
					TestContextImpl context = new TestContextImpl(gc, ts);
					TestRunnable r = new TestRunnable(0, new TestEngine(mockInstanceId, context, reporter));
					pool.addJob(r); // blocks until a thread is available..
				}
			}
		} catch (Throwable t) {
			if (stopped)
				log.info("Mock runner stopped");
			else
				log.error("Mock runner terminated due to an unhandled exception:" + t.getMessage(), t);
		} finally {
			reporter.stop();
		}
	}
	private Object lock = new Object();
	public void waitForCompletion() {
		synchronized (lock) {
			if (stopped)
				return;
			try {
				lock.wait();
			} catch (InterruptedException ie) {
			}
		}
	}
	public void stop() {
		stopped = true;
		try {
			pool.terminate();
			reporter.stop();
		} finally {
			synchronized (lock) {
				lock.notifyAll();
			}
		}
	}
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}
}
