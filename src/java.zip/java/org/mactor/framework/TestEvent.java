/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.util.Calendar;

import org.mactor.framework.spec.SpecNode;
import org.mactor.framework.spec.TestSpec;

public class TestEvent {
	public enum EventType {
		Start, End
	};
	private EventType eventType;
	private String outputText;
	private SpecNode node;
	private boolean successful = true;
	private int dataId;
	private MactorException cause;
	private Calendar time = Calendar.getInstance();
	private String testInstanceId;
	private String testRunInstanceId;
	private TestSpec testSpec;
	public TestEvent(String testRunInstanceId, String testInstanceId, EventType eventType, TestSpec testSpec, SpecNode node, int dataId, String outputText, boolean successful, MactorException cause) {
		this.testRunInstanceId = testRunInstanceId;
		this.testInstanceId = testInstanceId;
		this.eventType = eventType;
		this.outputText = outputText;
		this.testSpec = testSpec;
		this.node = node;
		this.successful = successful;
		this.dataId = dataId;
		this.cause = cause;
	}
	public Calendar getTime() {
		return time;
	}
	public int getDataId() {
		return dataId;
	}
	public EventType getEventType() {
		return eventType;
	}
	public boolean isStartEventType() {
		return EventType.Start.equals(eventType);
	}
	public SpecNode getNode() {
		return node;
	}
	public String getOutputText() {
		return outputText;
	}
	public boolean isSuccessful() {
		return successful;
	}
	public boolean isSuccessfulTestCompleteEvent() {
		return isSuccessful() && isTestCompleteEvent();
	}
	public boolean isFaultTestCompleteEvent() {
		return !isSuccessful() && isTestCompleteEvent();
	}
	public boolean isTestCompleteEvent() {
		return (node instanceof TestSpec) && EventType.End.equals(eventType);
	}
	public MactorException getCause() {
		return cause;
	}
	public String getTestRunInstanceId() {
		return testRunInstanceId;
	}
	public void setTestRunInstanceId(String testRunInstanceId) {
		this.testRunInstanceId = testRunInstanceId;
	}
	public TestSpec getTestSpec() {
		return testSpec;
	}
	public String getTestInstanceId() {
		return testInstanceId;
	}
}
