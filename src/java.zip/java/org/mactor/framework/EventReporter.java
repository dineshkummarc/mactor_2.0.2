/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.util.Iterator;
import java.util.LinkedList;

public class EventReporter implements Runnable, TestFeedbackListener {
	LinkedList<EI> eventQueue = new LinkedList<EI>();
	private Object lock = new Object();
	private TestFeedbackListener listener;
	private boolean stopped = false;
	private String testRunInstanceId;
	public EventReporter(String testRunInstanceId, TestFeedbackListener listener) {
		super();
		this.listener = listener;
		this.testRunInstanceId = testRunInstanceId;
	}
	public void onNodeEvent(TestEvent event, TestContext context) {
		EI e = new EI();
		e.te = event;
		e.context = context;
		synchronized (lock) {
			eventQueue.add(e);
			lock.notifyAll();
		}
	}
	public void onTestRunCompleted(String testRunInstanceId, int succededCount, int failedCount) {
	}
	int succededCount;
	int failedCount;
	public void run() {
		while (!stopped) {
			LinkedList<EI> current = null;
			synchronized (lock) {
				if (eventQueue.size() == 0) {
					try {
						lock.wait();
					} catch (InterruptedException ie) {
					}
				}
				if (eventQueue.size() > 0) {
					current = eventQueue;
					eventQueue = new LinkedList<EI>();
				}
			}
			if (current != null) {
				Iterator<EI> it = current.iterator();
				while (it.hasNext()) {
					EI e = (EI) it.next();
					if (e.te.isTestCompleteEvent()) {
						if (e.te.isSuccessful())
							succededCount++;
						else
							failedCount++;
					}
					listener.onNodeEvent(e.te, e.context);
				}
			}
		}
		listener.onTestRunCompleted(testRunInstanceId, succededCount, failedCount);
	}
	public void start() {
		stopped = false;
		new Thread(this).start();
	}
	public void stop() {
		stopped = true;
		synchronized (lock) {
			lock.notifyAll();
		}
	}
	private static class EI {
		TestEvent te;
		TestContext context;
	}
}