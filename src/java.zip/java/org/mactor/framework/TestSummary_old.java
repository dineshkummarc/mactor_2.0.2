/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.mactor.brokers.Message;
import org.mactor.brokers.MessageContextInfo;
import org.mactor.framework.spec.SpecNode;

public class TestSummary_old {
	private MessageInfo[] messageHistory;
	private Map<String, String> contextValues;
	private Calendar testStartTime;
	private Calendar testCompleteTime;
	private boolean success;
	private String failedMessage;
	public Map<String, String> getContextValues() {
		return contextValues;
	}
	public String getFailedMessage() {
		return failedMessage;
	}
	public MessageInfo[] getMessageHistory() {
		return messageHistory;
	}
	public boolean isSuccess() {
		return success;
	}
	public Calendar getTestCompleteTime() {
		return testCompleteTime;
	}
	public Calendar getTestStartTime() {
		return testStartTime;
	}
	public static TestSummary_old create(TestContext context, LinkedList<TestEvent> events) {
		TestSummary_old ts = new TestSummary_old();
		ts.contextValues = context.getValues();
		ts.messageHistory = getSortedMessageHistory(context);
		if (events != null && events.size() > 0) {
			ts.testStartTime = events.getFirst().getTime();
			TestEvent last = events.getLast();
			ts.testCompleteTime = last.getTime();
			ts.success = last.isSuccessfulTestCompleteEvent();
			if (last.isFaultTestCompleteEvent()) {
				TestEvent errorNode = events.get(events.size() - 2);
				ts.failedMessage = errorNode.getNode().getName() + " - failed with: " + (errorNode.getCause() == null ? "unknown reason" : errorNode.getCause().getMessage());
			}
		}
		return ts;
	}
	private static MessageInfo[] getSortedMessageHistory(TestContext context) {
		List<MessageInfo> result = new LinkedList<MessageInfo>();
		List<Message> all = context.getAllMessages();
		Collections.sort(all, new Comparator<Message>() {
			public int compare(Message m0, Message m1) {
				long n0 = m0.getMessageContextInfo().getMessageSequenceNumber();
				long n1 = m1.getMessageContextInfo().getMessageSequenceNumber();
				if (n0 == n1)
					return 0;
				if (n0 > n1)
					return 1;
				return -1;
			}
		});
		for (Message m : all) {
			if (!m.getMessageContextInfo().isResponseMessage()) {
				result.add(MessageInfo.create(m.getMessageContextInfo()));
				if (m.getMessageContextInfo().hasResponseMessage())
					result.add(MessageInfo.create(m.getMessageContextInfo().getResponseMessage().getMessageContextInfo()));
			}
		}
		return result.toArray(new MessageInfo[result.size()]);
	}
	public static class MessageInfo {
		private String archivePath;
		private SpecNode node;
		private String channel;
		private Calendar createdTime;
		private boolean incoming;
		private boolean response;
		public static MessageInfo create(MessageContextInfo mci) {
			MessageInfo mi = new MessageInfo();
			mi.archivePath = mci.getArchivePath();
			mi.channel = mci.getChannel();
			mi.createdTime = mci.getCreatedTime();
			mi.node = mci.getNode();
			mi.incoming = mci.isIncoming();
			mi.response = mci.isResponseMessage();
			return mi;
		}
		public String getArchivePath() {
			return archivePath;
		}
		public String getChannel() {
			return channel;
		}
		public Calendar getCreatedTime() {
			return createdTime;
		}
		public boolean isIncoming() {
			return incoming;
		}
		public SpecNode getNode() {
			return node;
		}
		public boolean isResponse() {
			return response;
		}
	}
}
