/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework;

import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.mactor.framework.TestEngineThreadPool.TestRunnable;
import org.mactor.framework.data.DataTable;
import org.mactor.framework.spec.GlobalConfig;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.framework.spec.TestSpec;

/**
 * 
 * @author Lars Ivar Almli
 */
public class TestRunner {
	protected static Logger log = Logger.getLogger(TestRunner.class);
	private boolean terminate = false;
	int numberOfTestThreads;
	TestSpec testSpec;
	DataTable testData;
	private String instanceId = AppUtil.getNextId("TR");
	TestEngineThreadPool pool;
	int errorCount = 0;
	List<TestRunnable> jobs = new LinkedList<TestRunnable>();
	GlobalConfig gc;
	EventReporter reporter;
	public TestRunner(int numberOfTestThreads, TestSpec testSpec, DataTable testData, TestFeedbackListener fl) throws MactorException {
		super();
		if (numberOfTestThreads < 1)
			numberOfTestThreads = 1;
		reporter = new EventReporter(instanceId, fl);
		this.numberOfTestThreads = numberOfTestThreads;
		this.testSpec = testSpec;
		this.testData = testData;
		pool = new TestEngineThreadPool(numberOfTestThreads);
		gc = ProjectContext.getGlobalInstance().loadGlobalConfig();
	}
	boolean started = false;
	private Object lock = new Object();
	private boolean completed = false;
	public void start() throws MactorException {
		if (started)
			throw new MactorException("The test runner can only be used once");
		started = true;
		new Thread(new Runnable() {
			public void run() {
				reporter.start();
				try {
					try {
						int dataCount = testData.getRowCount();
						for (int i = 0; (i < dataCount) && !terminate; i++) {
							TestContextImpl context = new TestContextImpl(gc, testSpec);
							context.setValues(testData.getRowData(i));
							TestRunnable r = new TestRunnable(i, new TestEngine(instanceId, context, reporter));
							jobs.add(r);
							pool.addJob(r);
						}
					} catch (MactorException me) {
						log.warn("Exception while initializing test", me);
					}
					pool.join();
					for (TestRunnable runnable : jobs) {
						if (!runnable.isSucces())
							errorCount++;
					}
				} finally {
					reporter.stop();
					synchronized (lock) {
						completed = true;
						lock.notifyAll();
					}
				}
			}
		}).start();
	}
	public int waitForCompletion() {
		try {
			synchronized (lock) {
				if (!completed)
					lock.wait();
			}
		} catch (InterruptedException ie) {
		}
		return errorCount;
	}
	public void stop() {
		terminate = true;
		pool.terminate();
		reporter.stop();
	}
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}
}
