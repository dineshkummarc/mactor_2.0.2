/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.dom4j.Element;
import org.mactor.framework.MactorException;

public abstract class CommandSpec extends SpecNode {
	private String command;
	private List<String> params = new LinkedList<String>();
	public String getCommand() {
		return command;
	}
	public List<String> getParams() {
		return params;
	}
	protected static CommandSpec loadSpec(CommandSpec spec, Element element) throws MactorException {
		if (element == null)
			return null;
		spec.name = element.attributeValue("name");
		spec.command = element.attributeValue("command");
		Iterator it = element.elementIterator("param");
		while (it.hasNext())
			spec.params.add(((Element) it.next()).getTextTrim());
		return spec;
	}
	public String getDescription() {
		return "Command:" + command + ". Params:" + params;
	}
	public Element addToElement(Element parent) {
		Element e = parent.addElement(getType());
		e.addAttribute("name", name);
		e.addAttribute("command", command);
		for (String s : params) {
			e.addElement("param").setText(s);
		}
		return e;
	}
	public void setCommand(String command) {
		this.command = command;
	}
}
