/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import org.dom4j.Element;
import org.mactor.framework.MactorException;

public class ConditionSpec extends ContainerSpec {
	public String getExecute() {
		return execute;
	}
	@Override
	public String getType() {
		return "condition";
	}
	private String execute;
	public static ConditionSpec loadSpec(Element element) throws MactorException {
		if (element == null)
			return null;
		ConditionSpec s = new ConditionSpec();
		s.name = element.attributeValue("name");
		s.execute = element.attributeValue("execute");
		s.loadContainedNodes(element);
		return s;
	}
	public String getShortDescription() {
		return "Condition node - '" + name + "'";
	}
	public String getDescription() {
		return "Condition";
	}
	public Element addToElement(Element parent) {
		Element e = parent.addElement(getType());
		e.addAttribute("name", name);
		e.addAttribute("execute", execute);
		super.writeContainedNodesToElement(e);
		return e;
	}
	public void setExecute(String execute) {
		this.execute = execute;
	}
}
