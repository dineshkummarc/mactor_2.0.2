/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.LinkedList;
import java.util.Properties;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.dom4j.Document;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.mactor.framework.MactorException;

public class ProjectContext {
	private File projectDir;
	private File projectConfigDir;
	private String globalConfigName;
	private String messageBrokerConfigName;
	private static ProjectContext instance;
	private boolean dirty;
	private static Object lock = new Object();
	public static ProjectContext getGlobalInstance() {
		if (instance == null) {
			synchronized (lock) {
				if (instance == null) {
					instance = new ProjectContext();
				}
			}
		}
		return instance;
	}
	public String getProjectName() {
		return projectDir.getName();
	}
	private File getFileDir(boolean isConfigDir) {
		if (isConfigDir)
			return projectConfigDir;
		return projectDir;
	}
	public File getAbsolutePath(String relativePath) {
		try {
			return new File(projectDir.getAbsolutePath() + "/" + relativePath).getCanonicalFile();
		} catch (IOException e) {
			e.printStackTrace();
			return new File(projectDir.getAbsolutePath() + "/" + relativePath);
		}
	}
	public String getRelativePath(File path) {
		if (path == null)
			return null;
		File filePath = new File(path.getAbsolutePath());
		File fDir = null;
		if (!filePath.isDirectory())
			fDir = filePath.getParentFile();
		else
			fDir = new File(path.getAbsolutePath());
		// find first common dir
		LinkedList<String> relativeSegments = new LinkedList<String>();
		int pDirDownCounter = 0;
		boolean found = false;
		while (fDir != null) {
			pDirDownCounter = 0;
			File pDir = new File(projectDir.getAbsolutePath());
			while (pDir != null) {
				if (fDir.equals(pDir)) {
					found = true;
					break;
				}
				pDir = pDir.getParentFile();
				pDirDownCounter++;
			}
			if (found)
				break;
			relativeSegments.addFirst(fDir.getName());
			fDir = fDir.getParentFile();
		}
		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < pDirDownCounter; i++)
			sb.append("../");
		for (String seg : relativeSegments)
			sb.append(seg).append("/");
		if (!path.isDirectory())
			sb.append(path.getName());
		return sb.toString();
	}
	public Document readFromFile(String name, boolean isConfigFile) throws MactorException {
		return readFromFile(new File(getFileDir(isConfigFile).getAbsolutePath() + "/" + name));
	}
	public Document readFromFile(File path) throws MactorException {
		if (path == null || !path.exists())
			throw new MactorException("The file '" + path + "' does not exist");
		SAXReader reader = new SAXReader();
		try {
			final String sl = XMLConstants.W3C_XML_SCHEMA_NS_URI;
			SchemaFactory factory = SchemaFactory.newInstance(sl);
			StreamSource ss = new StreamSource(Thread.currentThread().getContextClassLoader().getResourceAsStream("mactor.xsd"));
			Schema schema = factory.newSchema(ss);
			Validator v = schema.newValidator();
			v.validate(new StreamSource(path));
			Document doc = reader.read(path);
			return doc;
		} catch (Exception e) {
			throw new MactorException("Faile to parse file '" + path.getAbsolutePath() + "'. Error:" + e.getMessage(), e);
		}
	}
	public void writeDocumentToFile(File file, Document doc) throws MactorException {
		try {
			OutputFormat format = OutputFormat.createPrettyPrint();
			FileWriter fw = new FileWriter(file);
			XMLWriter xw = new XMLWriter(fw, format);
			doc.normalize();
			xw.write(doc.getRootElement());
			xw.flush();
			fw.close();
		} catch (IOException ioe) {
			throw new MactorException("Failed to write the  file '" + file.getAbsolutePath() + "'. Error:" + ioe.getMessage(), ioe);
		}
	}
	public File writeStringToFile(String name, String content, boolean isConfigFile) throws MactorException {
		File path = new File(getFileDir(isConfigFile).getAbsolutePath() + "/" + name);
		if (path.isDirectory())
			throw new MactorException("The file '" + path.getAbsolutePath() + "' is a directory");
		try {
			FileWriter fw = new FileWriter(path);
			fw.write(content);
			fw.flush();
			fw.close();
		} catch (IOException ioe) {
			throw new MactorException("Failed to write the  file '" + path.getAbsolutePath() + "'. Error:" + ioe.getMessage(), ioe);
		}
		return path;
	}
	public String readStringFromFile(String name, boolean isConfigFile) throws MactorException {
		File path = new File(getFileDir(isConfigFile).getAbsolutePath() + "/" + name);
		if (!path.exists())
			return null;
		if (path.isDirectory())
			throw new MactorException("The file '" + path.getAbsolutePath() + "' is a directory");
		try {
			FileReader fr = new FileReader(path);
			StringWriter out = new StringWriter();
			int c;
			while ((c = fr.read()) != -1) {
				out.write(c);
			}
			fr.close();
			return out.toString();
		} catch (IOException ioe) {
			throw new MactorException("Failed to write the  file '" + path.getAbsolutePath() + "'. Error:" + ioe.getMessage(), ioe);
		}
	}
	public File renameFile(File oldFile, String newFilename) throws MactorException {
		File currentFile = new File(oldFile.getAbsolutePath());
		File newFile = new File(oldFile.getParent() + "/" + newFilename);
		if (!currentFile.renameTo(newFile))
			throw new MactorException("Failed to rename file '" + currentFile.getAbsolutePath() + "' to file '" + newFile.getAbsolutePath() + "'");
		return newFile;
	}
	public File duplicateFile(File file) throws MactorException {
		File currentFile = new File(file.getAbsolutePath());
		File newFile = new File(file.getParent() + "/" + getNextFilename(file.getName(), file.getParentFile()));
		try {
			Reader in = new BufferedReader(new FileReader(currentFile));
			Writer out = new BufferedWriter(new FileWriter(newFile));
			int c;
			while ((c = in.read()) != -1) {
				out.write(c);
			}
			out.flush();
			in.close();
			out.close();
			return newFile;
		} catch (IOException e) {
			throw new MactorException("Failed to copy file '" + currentFile.getAbsolutePath() + "' to file '" + newFile.getAbsolutePath() + "'");
		}
	}
	public void deleteFile(File file) throws MactorException {
		if (!file.delete())
			throw new MactorException("Unable to delete the file '" + file.getAbsolutePath() + "'");
	}
	private static class CurrentFilesFilter implements FilenameFilter {
		String name;
		String ending;
		CurrentFilesFilter(String name, String ending) {
			this.name = name;
			this.ending = ending;
		}
		public boolean accept(File dir, String fn) {
			return fn.endsWith(ending) & fn.startsWith(name);
		}
	}
	public String getNextFilename(String filename, boolean isConfigFile) {
		return getNextFilename(filename, getFileDir(isConfigFile));
	}
	private String getNextFilename(String filename, File dir) {
		int endingIndex = filename.lastIndexOf(".");
		String name = null;
		String ending = "";
		if (endingIndex > 0) {
			name = filename.substring(0, endingIndex);
			ending = filename.substring(endingIndex, filename.length());
		} else {
			name = filename;
		}
		int nextIndex = getNextIndex(dir, name, ending);
		if (nextIndex == 0)
			return filename;
		return name + nextIndex + ending;
	}
	private int getNextIndex(File dir, String name, String ending) {
		String[] filename = dir.list(new CurrentFilesFilter(name, ending));
		if (filename == null || filename.length == 0)
			return 0;
		int largest = 0;
		for (int i = 0; i < filename.length; i++) {
			String index = filename[i].substring(name.length());
			if (ending != null && ending.length() > 0) {
				int n = index.lastIndexOf(ending);
				if (n > 0)
					index = index.substring(0, n);
			}
			try {
				int n = Integer.parseInt(index);
				if (n > largest)
					largest = n;
			} catch (NumberFormatException nfe) {
			}
		}
		return largest + 1;
	}
	public File getProjectDir() {
		return projectDir;
	}
	public File getProjectConfigDir() {
		return projectConfigDir;
	}
	public void setProjectDir(File dir) {
		projectDir = new File(dir.getAbsolutePath());
		loadProjectFile();
	}
	public void setGlobalConfigName(String globalConfigName) {
		this.globalConfigName = globalConfigName;
		writeProjectFile();
	}
	public void setMessageBrokerConfigName(String messageBrokerConfigName) {
		this.messageBrokerConfigName = messageBrokerConfigName;
		writeProjectFile();
	}
	public void setProjectConfigDir(File projectConfigDir) {
		this.projectConfigDir = projectConfigDir;
		writeProjectFile();
	}
	public GlobalConfig loadGlobalConfig() throws MactorException {
		if (globalConfigName == null || globalConfigName.length() == 0)
			return null;
		return new GlobalConfig(readFromFile(globalConfigName, true));
	}
	public MessageBrokersConfig loadMessageBrokersConfig() throws MactorException {
		if (messageBrokerConfigName == null || messageBrokerConfigName.length() == 0)
			return null;
		return new MessageBrokersConfig(readFromFile(messageBrokerConfigName, true));
	}
	private void writeProjectFile() {
		File f = new File(projectDir.getAbsolutePath() + "/mactor.mproject");
		Properties projectProps = new Properties();
		projectProps.put("config_dir", getRelativePath(projectConfigDir));
		if (globalConfigName != null)
			projectProps.put("global_config", globalConfigName);
		if (messageBrokerConfigName != null)
			projectProps.put("message_broker_config", messageBrokerConfigName);
		try {
			FileOutputStream fos = new FileOutputStream(f);
			projectProps.store(fos, "");
			fos.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	private void loadProjectFile() {
		File f = new File(projectDir.getAbsolutePath() + "/mactor.mproject");
		Properties projectProps = new Properties();
		try {
			if (!f.exists()) {
				FileWriter fw = new FileWriter(f);
				fw.write("config_dir=");
				fw.close();
			}
			projectProps.load(new FileInputStream(f));
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		String cd = projectProps.getProperty("config_dir");
		if (cd != null && cd.length() > 0) {
			projectConfigDir = getAbsolutePath(cd);
		} else {
			projectConfigDir = new File(projectDir.getAbsolutePath());
		}
		globalConfigName = projectProps.getProperty("global_config");
		messageBrokerConfigName = projectProps.getProperty("message_broker_config");
	}
	public String getGlobalConfigName() {
		return globalConfigName;
	}
	public String getMessageBrokerConfigName() {
		return messageBrokerConfigName;
	}
	public boolean isDirty() {
		return dirty;
	}
	public void setDirty(boolean dirty) {
		this.dirty = dirty;
		if (dirty && listener != null)
			listener.onDirty();
	}
	ProjectContextListener listener;
	public interface ProjectContextListener {
		void onDirty();
	}
	public ProjectContextListener getListener() {
		return listener;
	}
	public void setListener(ProjectContextListener listener) {
		this.listener = listener;
	}
}
