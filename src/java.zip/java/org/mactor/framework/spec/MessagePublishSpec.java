/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import org.dom4j.Element;
import org.mactor.framework.MactorException;

public class MessagePublishSpec extends SpecNode {
	@Override
	public String getType() {
		return "message_publish";
	}
	private String channel;
	private MessageBuilderSpec messageBuilder;
	public String getChannel() {
		return channel;
	}
	public static MessagePublishSpec loadSpec(Element element) throws MactorException {
		if (element == null)
			return null;
		MessagePublishSpec s = new MessagePublishSpec();
		s.name = element.attributeValue("name");
		s.channel = element.attributeValue("channel");
		s.messageBuilder = MessageBuilderSpec.loadSpec(element.element("message_builder"));
		return s;
	}
	public Element addToElement(Element parent) {
		Element e = parent.addElement(getType());
		e.addAttribute("name", name);
		e.addAttribute("channel", channel);
		getMessageBuilder().addToElement(e);
		return e;
	}
	public MessageBuilderSpec getMessageBuilder() {
		if (messageBuilder == null)
			messageBuilder = new MessageBuilderSpec();
		return messageBuilder;
	}
	public String getShortDescription() {
		return "Publisher node - '" + name + "'";
	}
	public String getDescription() {
		return "Channel:" + channel + ". Message builder:(" + messageBuilder.getDescription() + ")";
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
}