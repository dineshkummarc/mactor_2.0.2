/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.framework.ParseUtil;

public class MessageReceiveSpec extends ContainerSpec {
	@Override
	public String getType() {
		return "message_receive";
	}
	private int maxMessageCount;
	private int minMessageCount;
	private int maxTimeoutSeconds;
	private boolean blockUntilTimeout;
	private String messageSubscribeNodeName;
	private boolean hasResponseNode = false;
	public boolean hasResponseNode() {
		return hasResponseNode;
	}
	public String getMessageSubscribeNodeName() {
		return messageSubscribeNodeName;
	}
	public int getMaxTimeoutSeconds() {
		return maxTimeoutSeconds;
	}
	public int getMaxMessageCount() {
		return maxMessageCount;
	}
	public int getMinMessageCount() {
		return minMessageCount;
	}
	public boolean isBlockUntilTimeout() {
		return blockUntilTimeout;
	}
	public static MessageReceiveSpec loadSpec(Element element) throws MactorException {
		if (element == null)
			return null;
		MessageReceiveSpec s = new MessageReceiveSpec();
		s.name = element.attributeValue("name");
		s.messageSubscribeNodeName = element.attributeValue("message_subscribe_node_name");
		s.minMessageCount = ParseUtil.tryParseIntVal(element.attributeValue("min_message_count"));
		s.maxMessageCount = ParseUtil.tryParseIntVal(element.attributeValue("max_message_count"));
		s.maxTimeoutSeconds = ParseUtil.tryParseIntVal(element.attributeValue("max_timeout_seconds"));
		s.blockUntilTimeout = Boolean.parseBoolean(element.attributeValue("block_until_timeout"));
		s.loadContainedNodes(element);
		for (SpecNode n : s.getSpecNodes()) {
			if (n instanceof MessageRespondSpec) {
				s.hasResponseNode = true;
				break;
			}
		}
		return s;
	}
	public Element addToElement(Element parent) {
		Element e = parent.addElement(getType());
		e.addAttribute("name", name);
		e.addAttribute("message_subscribe_node_name", messageSubscribeNodeName);
		e.addAttribute("min_message_count", minMessageCount + "");
		e.addAttribute("max_message_count", maxMessageCount + "");
		e.addAttribute("max_timeout_seconds", maxTimeoutSeconds + "");
		e.addAttribute("block_until_timeout", blockUntilTimeout + "");
		super.writeContainedNodesToElement(e);
		return e;
	}
	public String getShortDescription() {
		return "Receiver node - '" + name + "'";
	}
	public String getDescription() {
		return "Refered subscriber node:" + messageSubscribeNodeName + ". Max message count:" + maxMessageCount + ". Min message count" + minMessageCount + ". Max timeout (seconds):"
				+ maxTimeoutSeconds + ". Block until timeout:" + blockUntilTimeout;
	}
	public void setBlockUntilTimeout(boolean blockUntilTimeout) {
		this.blockUntilTimeout = blockUntilTimeout;
	}
	public void setMaxMessageCount(int maxMessageCount) {
		this.maxMessageCount = maxMessageCount;
	}
	public void setMaxTimeoutSeconds(int maxTimeoutSeconds) {
		this.maxTimeoutSeconds = maxTimeoutSeconds;
	}
	public void setMessageSubscribeNodeName(String messageSubscribeNodeName) {
		this.messageSubscribeNodeName = messageSubscribeNodeName;
	}
	public void setMinMessageCount(int minMessageCount) {
		this.minMessageCount = minMessageCount;
	}
}
