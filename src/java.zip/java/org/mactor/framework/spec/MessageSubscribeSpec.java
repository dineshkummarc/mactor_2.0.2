/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import org.dom4j.Element;
import org.mactor.framework.MactorException;

public class MessageSubscribeSpec extends SpecNode {
	public void setChannel(String channel) {
		this.channel = channel;
	}
	@Override
	public String getType() {
		return "message_subscribe";
	}
	private String channel;
	private MessageSelectorSpec messageSelector;
	public String getChannel() {
		return channel;
	}
	public MessageSelectorSpec getMessageSelector() {
		if (messageSelector == null)
			messageSelector = new MessageSelectorSpec();
		return messageSelector;
	}
	public static MessageSubscribeSpec loadSpec(Element element) throws MactorException {
		if (element == null)
			return null;
		MessageSubscribeSpec s = new MessageSubscribeSpec();
		s.name = element.attributeValue("name");
		s.channel = element.attributeValue("channel");
		s.messageSelector = MessageSelectorSpec.loadSpec(element.element("message_selector"));
		return s;
	}
	@Override
	public Element addToElement(Element parent) {
		Element e = parent.addElement(getType());
		e.addAttribute("name", name);
		e.addAttribute("channel", channel);
		getMessageSelector().addToElement(e);
		return e;
	}
	public String getShortDescription() {
		return "Subscriber node - '" + name + "'";
	}
	public String getDescription() {
		return "Channel:" + channel + ". Selector:(" + messageSelector.getDescription() + ")";
	}
}