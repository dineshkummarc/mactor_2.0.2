/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.dom4j.Element;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;

public abstract class ContainerSpec extends SpecNode {
	private List<SpecNode> specNodes = new LinkedList<SpecNode>();
	public List<SpecNode> getSpecNodes() {
		return specNodes;
	}
	public void addSpecNode(SpecNode node) throws MactorException {
		specNodes.add(node);
	}
	public void loadContainedNodes(Element element) throws MactorException {
		if (element == null)
			return;
		Iterator it = element.elementIterator();
		while (it.hasNext()) {
			Element el = (Element) it.next();
			SpecNode spec = null;
			if (el.getName().equals("message_subscribe")) {
				spec = MessageSubscribeSpec.loadSpec(el);
			} else if (el.getName().equals("message_publish")) {
				spec = MessagePublishSpec.loadSpec(el);
			} else if (el.getName().equals("message_receive")) {
				spec = MessageReceiveSpec.loadSpec(el);
			} else if (el.getName().equals("action")) {
				spec = ActionSpec.loadSpec(el);
			} else if (el.getName().equals("value")) {
				spec = ValueSpec.loadSpec(el);
			} else if (el.getName().equals("message_respond")) {
				spec = MessageRespondSpec.loadSpec(el);
			} else if (el.getName().equals("loop")) {
				spec = LoopSpec.loadSpec(el);
			} else if (el.getName().equals("condition")) {
				spec = ConditionSpec.loadSpec(el);
			} else {
				throw new ConfigException("Unsupported node type '" + el.getName() + "'");
			}
			spec.parentNode = this;
			addSpecNode(spec);
		}
		return;
	}
	public void writeContainedNodesToElement(Element element) {
		for (SpecNode n : specNodes) {
			n.addToElement(element);
		}
	}
}
