/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

public class TestDataBundleHtmlParser {
	/*
	 * List<TestData> dataList = new LinkedList<TestData>(); public void
	 * add(TestData data) { dataList.add(data); } public void insertTable(int
	 * index, TestData data) { dataList.add(index, data); } public void
	 * removeTable(int index) { dataList.remove(index); } public void
	 * removeTable(TestData table) { dataList.remove(table); } public static
	 * TestDataBundleHtmlParser parseFile(File file) throws MactorException {
	 * try { HtmlFileParserCallback parserCallback = new
	 * HtmlFileParserCallback(); Reader reader = new FileReader(file); new
	 * ParserDelegator().parse(reader, parserCallback, true); return
	 * parserCallback.bundle; } catch (Exception e) { throw new
	 * MactorException("Failed to parse the file '" + file.getAbsolutePath() +
	 * "'. Error: " + e, e); } } public static TestDataBundleHtmlParser
	 * parseString(String content) throws MactorException { try {
	 * HtmlFileParserCallback parserCallback = new HtmlFileParserCallback();
	 * Reader reader = new StringReader(content); new
	 * ParserDelegator().parse(reader, parserCallback, true); return
	 * parserCallback.bundle; } catch (Exception e) { throw new
	 * MactorException("Failed to parse the string. Error: " + e, e); } }
	 * private static class HtmlFileParserCallback extends
	 * HTMLEditorKit.ParserCallback { TestDataBundleHtmlParser bundle = new
	 * TestDataBundleHtmlParser(); TestData data = null; List<String> row =
	 * null; boolean inCell = false; int rowIndex = 0; String cellValue = null;
	 * public void handleText(char[] data, int pos) { if (inCell) { cellValue =
	 * new String(data); } } public void handleStartTag(Tag t,
	 * MutableAttributeSet a, int pos) { if (HTML.Tag.TABLE.equals(t)) { data =
	 * new TestData(); rowIndex = -1; } else if (HTML.Tag.TR.equals(t)) {
	 * rowIndex++; if (rowIndex > 1) row = new LinkedList<String>(); } else if
	 * (HTML.Tag.TD.equals(t)) { inCell = true; } } public void handleEndTag(Tag
	 * t, int pos) { if (HTML.Tag.TABLE.equals(t)) { if (data != null) {
	 * bundle.add(data); data = null; } } else if (HTML.Tag.TR.equals(t)) { if
	 * (row != null && data != null) { data.addRow(row); row = null; } } else if
	 * (HTML.Tag.TD.equals(t)) { if (cellValue != null) { if (rowIndex == 0) {
	 * data.setTestSpecPath(cellValue); } else if (rowIndex == 1 && data !=
	 * null) { data.addColumn(cellValue); } else if (data != null && row !=
	 * null) { row.add(cellValue); } } cellValue = null; inCell = false; } } }
	 * public void write(Writer out) throws IOException { for (TestData data :
	 * dataList) { out.write("<html><body>"); data.write(out); out.write("</body></html>"); } }
	 * @Override public String toString() { try { StringWriter sw = new
	 * StringWriter(); write(sw); return sw.toString(); } catch (IOException e) {
	 * throw new RuntimeException(e); // unexpected } } public List<TestData>
	 * getDataList() { return dataList; }
	 * 
	 */
}
