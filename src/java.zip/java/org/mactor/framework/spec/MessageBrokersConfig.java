/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.framework.ParseUtil;

public class MessageBrokersConfig {
	private List<MessageBrokerConfig> brokers = new LinkedList<MessageBrokerConfig>();
	private Document doc;
	public String asXML() {
		return XmlUtil.getPrettyXML(doc.getRootElement());
	}
	public List<MessageBrokerConfig> getMessageBrokers() {
		return Collections.unmodifiableList(brokers);
	}
	public MessageBrokersConfig(Document doc) throws MactorException {
		if (doc == null || doc.getRootElement() == null)
			throw new MactorException("Invalid MessageBrokerConfig: null");
		this.doc = doc;
		Element element = doc.getRootElement();
		if (!"message_broker_config".equals(element.getName()))
			throw new MactorException("Invalid MessageBrokerConfig. Root node: '" + element.getName() + "'. Expected: 'message_broker_config'");
		Iterator it = element.elementIterator("message_broker");
		while (it.hasNext()) {
			brokers.add(MessageBrokerConfig.loadConfig((Element) it.next()));
		}
	}
	public static class MessageBrokerConfig {
		private Map<String, ChannelConfig> channels = new HashMap<String, ChannelConfig>();
		private Map<String, String> values = new HashMap<String, String>();
		private String brokerClass;
		private String name;
		private String archivePath;
		private boolean arhiveDeadLetterMessage;
		private boolean archiveConsumedMessages;
		private int messageReadLimit;
		private int messageReadIntervalSeconds;
		public boolean isArchiveConsumedMessages() {
			return archiveConsumedMessages;
		}
		public String getArchivePath() {
			return archivePath;
		}
		public boolean isArhiveDeadLetterMessage() {
			return arhiveDeadLetterMessage;
		}
		public String getBrokerClass() {
			return brokerClass;
		}
		public Map<String, ChannelConfig> getChannels() {
			return channels;
		}
		public String getName() {
			return name;
		}
		public Map<String, String> getValues() {
			return values;
		}
		public String getValue(String name) {
			return values.get(name);
		}
		public ChannelConfig getChannelConfig(String channelName) {
			return channels.get(channelName);
		}
		public ChannelConfig getRequieredChannelConfig(String channelName) throws MactorException {
			ChannelConfig cf = channels.get(channelName);
			if (cf == null)
				throw new MactorException("There is no channel config for channel '" + channelName + "'");
			return cf;
		}
		private static MessageBrokerConfig loadConfig(Element element) throws MactorException {
			MessageBrokerConfig mbc = new MessageBrokerConfig();
			mbc.name = element.attributeValue("name");
			mbc.archivePath = element.attributeValue("archive_path");
			mbc.brokerClass = element.attributeValue("broker_class");
			mbc.messageReadIntervalSeconds = ParseUtil.tryParseIntVal(element.attributeValue("message_read_interval_seconds"));
			if (mbc.messageReadIntervalSeconds == 0)
				mbc.messageReadIntervalSeconds = 10;
			mbc.messageReadLimit = ParseUtil.tryParseIntVal(element.attributeValue("message_read_limit"));
			if (mbc.messageReadLimit == 0)
				mbc.messageReadLimit = 20;
			mbc.archiveConsumedMessages = Boolean.parseBoolean(element.attributeValue("archive_consumed_messages"));
			mbc.arhiveDeadLetterMessage = Boolean.parseBoolean(element.attributeValue("archive_dead_letter_messages"));
			Iterator it = element.elementIterator("channel");
			while (it.hasNext()) {
				ChannelConfig c = ChannelConfig.loadConfig((Element) it.next());
				mbc.channels.put(c.getName(), c);
			}
			it = element.elementIterator("value");
			while (it.hasNext()) {
				Element e = (Element) it.next();
				mbc.values.put(e.attributeValue("name"), e.getTextTrim());
			}
			return mbc;
		}
		public static class ChannelConfig {
			private Map<String, String> values = new HashMap<String, String>();
			private String name;
			private boolean requiresResponse;
			public String getValue(String valueName) {
				return values.get(valueName);
			}
			public String getRequieredValue(String valueName) throws MactorException {
				String value = getValue(valueName);
				if (value == null)
					throw new MactorException("The channel config named '" + name + "' does not specify the requiered value '" + valueName + "'");
				return value;
			}
			public String getValue(String valueName, String defValue) {
				String v = values.get(valueName);
				return v == null ? defValue : v;
			}
			public static ChannelConfig loadConfig(Element element) throws MactorException {
				ChannelConfig c = new ChannelConfig();
				c.name = element.attributeValue("name");
				c.requiresResponse = Boolean.parseBoolean(element.attributeValue("requires_response"));
				Iterator it = element.elementIterator("value");
				while (it.hasNext()) {
					Element e = (Element) it.next();
					c.values.put(e.attributeValue("name"), e.getTextTrim());
				}
				return c;
			}
			public String getName() {
				return name;
			}
			public Map<String, String> getValues() {
				return values;
			}
			private void writeNodes(Element e) {
				e.addAttribute("name", getName());
				e.addAttribute("requires_response", requiresResponse + "");
				for (Entry<String, String> entry : values.entrySet()) {
					Element val = e.addElement("value");
					val.addAttribute("name", entry.getKey());
					val.setText(entry.getValue().trim());
				}
			}
			public boolean isRequiresResponse() {
				return requiresResponse;
			}
		}
		public int getMessageReadIntervalSeconds() {
			return messageReadIntervalSeconds;
		}
		public int getMessageReadLimit() {
			return messageReadLimit;
		}
		private void writeNodes(Element e) {
			e.addAttribute("archive_path", getArchivePath() + "");
			e.addAttribute("broker_class", getBrokerClass());
			e.addAttribute("message_read_interval_seconds", getMessageReadLimit() + "");
			e.addAttribute("archive_consumed_messages", isArchiveConsumedMessages() + "");
			e.addAttribute("archive_dead_letter_messages", isArhiveDeadLetterMessage() + "");
			for (Entry<String, ChannelConfig> entry : channels.entrySet()) {
				Element channelElement = e.addElement("channel");
				entry.getValue().writeNodes(channelElement);
			}
		}
	}
	private void writeNodes(Element e) {
		for (MessageBrokerConfig config : brokers)
			config.writeNodes(e.addElement("message_brokers_config"));
	}
	public Document toNewDocument() {
		Document newDoc = DocumentHelper.createDocument();
		writeNodes(newDoc.addElement("message_brokers_config"));
		return newDoc;
	}
}
