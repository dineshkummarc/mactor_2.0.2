/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.ParseUtil;

public class GlobalConfig {
	private Map<String, String> values = new HashMap<String, String>();
	private Map<String, Group> groups = new HashMap<String, Group>();
	private int maxNumberOfTestThreads;
	private Document doc;
	public String asXML() {
		return XmlUtil.getPrettyXML(doc.getRootElement());
	}
	public String getValue(String valueName) {
		return values.get(valueName);
	}
	public Group getGroup(String groupName) {
		return groups.get(groupName);
	}
	public Group getRequieredGroup(String groupName) throws ConfigException {
		Group value = groups.get(groupName);
		if (value == null)
			throw new ConfigException("The requiered global config group  named '" + groupName + "' was not found in the global config");
		return value;
	}
	public Map<String, String> getValues() {
		return Collections.unmodifiableMap(values);
	}
	public Map<String, Group> getGroups() {
		return Collections.unmodifiableMap(groups);
	}
	public GlobalConfig(Document globalConfigDoc) throws MactorException {
		if (globalConfigDoc == null || globalConfigDoc.getRootElement() == null)
			throw new MactorException("Invalid GlobalConfig: null");
		Element element = globalConfigDoc.getRootElement();
		if (!"global_config".equals(element.getName()))
			throw new MactorException("Invalid GlobalConfig. Root node: '" + element.getName() + "'. Expected: 'global_config'");
		doc = element.getDocument();
		maxNumberOfTestThreads = ParseUtil.tryParseIntVal(element.attributeValue("max_test_threads"));
		if (maxNumberOfTestThreads == 0)
			maxNumberOfTestThreads = 10;
		Iterator it = element.elementIterator("value");
		while (it.hasNext()) {
			Element e = (Element) it.next();
			values.put(e.attributeValue("name"), e.getTextTrim());
		}
		it = element.elementIterator("group");
		while (it.hasNext()) {
			Group g = Group.loadGroup((Element) it.next());
			groups.put(g.name, g);
		}
	}
	public static class Group {
		private Map<String, String> values = new HashMap<String, String>();
		public String getValue(String valueName) {
			return values.get(valueName);
		}
		public String getRequieredValue(String valueName) throws MactorException {
			String value = getValue(valueName);
			if (value == null)
				throw new MactorException("The global config group  named '" + name + "' does not specify the requiered value '" + valueName + "'");
			return value;
		}
		public Map<String, String> getValues() {
			return Collections.unmodifiableMap(values);
		}
		private String name;
		public static Group loadGroup(Element element) {
			Group g = new Group();
			g.name = element.attributeValue("name");
			Iterator it = element.elementIterator("value");
			while (it.hasNext()) {
				Element e = (Element) it.next();
				g.values.put(e.attributeValue("name"), e.getTextTrim());
			}
			return g;
		}
		public String getName() {
			return name;
		}
	}
	public int getMaxNumberOfTestThreads() {
		return maxNumberOfTestThreads;
	}
}
