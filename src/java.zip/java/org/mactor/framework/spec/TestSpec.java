/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.framework.ParseUtil;

public class TestSpec extends ContainerSpec {
	@Override
	public String getType() {
		return "test";
	}
	private int delayBeforeStartSeconds;
	private Map<String, SpecNode> nodeMap = new HashMap<String, SpecNode>();
	private Document doc;
	public String asXML() {
		return XmlUtil.getPrettyXML(doc.getRootElement());
	}
	private void buildIndex() throws MactorException {
		addContainerSpecToMap(this);
	}
	private void addContainerSpecToMap(ContainerSpec node) throws MactorException {
		addToNodeMap(node);
		if (node instanceof MessageReceiveSpec && !nodeMap.containsKey(((MessageReceiveSpec) node).getMessageSubscribeNodeName())) {
			throw new MactorException("The MessageReceiveSpec node '" + node.getName() + "' refers to an unknown MessageSubscribeSpec node '"
					+ ((MessageReceiveSpec) node).getMessageSubscribeNodeName() + "'");
		}
		Iterator it = node.getSpecNodes().iterator();
		while (it.hasNext()) {
			SpecNode n = (SpecNode) it.next();
			if (n instanceof ContainerSpec) {
				addContainerSpecToMap((ContainerSpec) n);
			} else {
				addToNodeMap(n);
			}
		}
	}
	private void addToNodeMap(SpecNode node) throws MactorException {
		if (nodeMap.containsKey(node.getName())) {
			throw new MactorException("Nameable nodes in the test-spec must have unique names. The name '" + node.getName() + "' has been used on multiple nodes");
		}
		nodeMap.put(node.getName(), node);
	}
	public int getDelayBeforeStartSeconds() {
		return delayBeforeStartSeconds;
	}
	public SpecNode findSpecNode(String nodeName) {
		return nodeMap.get(nodeName);
	}
	public static TestSpec loadFromFile(String name) throws MactorException {
		return TestSpec.loadFromDocument(ProjectContext.getGlobalInstance().readFromFile(name, false), name);
	}
	public static TestSpec loadFromDocument(Document doc, String name) throws MactorException {
		if (doc == null)
			throw new MactorException("Invalid document: null");
		Element element = doc.getRootElement();
		if (element == null)
			throw new MactorException("Invalid Test: null");
		if (!"test".equals(element.getName()))
			throw new MactorException("Invalid Test spec. Root node: '" + element.getName() + "'. Expected: 'test'");
		TestSpec s = new TestSpec();
		s.name = name;
		s.doc = element.getDocument();
		s.delayBeforeStartSeconds = ParseUtil.tryParseIntVal(element.attributeValue("delay_before_start_seconds"));
		s.loadContainedNodes(element);
		s.buildIndex();
		return s;
	}
	public Element addToElement(Element e) {
		throw new RuntimeException("Not implemented");
	}
	public String getShortDescription() {
		return "Test node - '" + name + "'";
	}
	public String getDescription() {
		return "Delay defore start (seconds):" + delayBeforeStartSeconds;
	}
}
