/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import org.dom4j.Element;
import org.mactor.framework.MactorException;

public class MessageRespondSpec extends SpecNode {
	@Override
	public String getType() {
		return "message_respond";
	}
	private MessageBuilderSpec messageBuilder;
	public static MessageRespondSpec loadSpec(Element element) throws MactorException {
		if (element == null)
			return null;
		MessageRespondSpec s = new MessageRespondSpec();
		s.name = element.attributeValue("name");
		s.messageBuilder = MessageBuilderSpec.loadSpec(element.element("message_builder"));
		return s;
	}
	public Element addToElement(Element parent) {
		Element e = parent.addElement(getType());
		e.addAttribute("name", name);
		getMessageBuilder().addToElement(e);
		return e;
	}
	public MessageBuilderSpec getMessageBuilder() {
		if (messageBuilder == null)
			messageBuilder = new MessageBuilderSpec();
		return messageBuilder;
	}
	public String getShortDescription() {
		return "Message response node - '" + name + "'";
	}
	public String getDescription() {
		return "Message response. Message builder:(" + messageBuilder.getDescription() + ")";
	}
}
