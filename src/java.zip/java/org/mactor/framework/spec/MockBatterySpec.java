/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.framework.spec;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.mactor.framework.MactorException;

public class MockBatterySpec {
	private String name;
	private int threadCount = 1;
	public List<String> getTests() {
		return tests;
	}
	public List<TestSpec> getTestSpecs() throws MactorException {
		List<TestSpec> ts = new LinkedList<TestSpec>();
		for (String t : tests)
			ts.add(TestSpec.loadFromFile(t));
		return ts;
	}
	public int getThreadCount() {
		return threadCount;
	}
	public String getType() {
		return "mock_battery";
	}
	public static MockBatterySpec loadFromFile(String name) throws MactorException {
		return MockBatterySpec.loadFromDocument(ProjectContext.getGlobalInstance().readFromFile(name, false), name);
	}
	private List<String> tests = new LinkedList<String>();
	public static MockBatterySpec loadFromDocument(Document doc, String name) throws MactorException {
		if (doc == null)
			throw new MactorException("Invalid document: null");
		Element element = doc.getRootElement();
		if (element == null)
			throw new MactorException("Invalid MockBattery: null");
		MockBatterySpec b = new MockBatterySpec();
		b.name = name;
		if (element.attributeValue("test_threads") != null)
			b.threadCount = Integer.parseInt(element.attributeValue("test_threads"));
		Iterator it = element.elementIterator("test");
		while (it.hasNext()) {
			Element e = (Element) it.next();
			b.tests.add(e.attributeValue("name"));
		}
		return b;
	}
	public String getName() {
		return name;
	}
}
