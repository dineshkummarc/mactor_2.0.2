/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.tibrv;

import java.util.HashMap;
import java.util.Map;

import org.mactor.brokers.AbstractMessageBroker;
import org.mactor.brokers.Message;
import org.mactor.brokers.MessageBroker;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;

import com.tibco.tibrv.Tibrv;
import com.tibco.tibrv.TibrvException;
import com.tibco.tibrv.TibrvListener;
import com.tibco.tibrv.TibrvMsg;
import com.tibco.tibrv.TibrvMsgCallback;
import com.tibco.tibrv.TibrvMsgField;
import com.tibco.tibrv.TibrvRvdTransport;
import com.tibco.tibrv.TibrvXml;

/**
 * A message broker for Tibco Rendezvous (suitable for TIBCO BusinessWorks
 * projects). (Add the tibrvj.jar library from your version of TIBCO Rv to the
 * MActor classpath)
 * 
 * @author Lars Ivar Almli
 * @see MessageBroker
 */
public class TibcoRvMessageBroker extends AbstractMessageBroker {
	private TibrvRvdTransport transport;
	private static final String FIELD_NAME = "xml";
	public TibcoRvMessageBroker(MessageBrokerConfig config) throws MactorException {
		super(config);
		try {
			Tibrv.open(Tibrv.IMPL_NATIVE);
			this.transport = new TibrvRvdTransport(config.getValue("service"), config.getValue("network"), config.getValue("daemon"));
			startDipatchThread();
		} catch (TibrvException tre) {
			throw new MactorException("Failed to initialize TibcoRvMessageBroker", tre);
		}
	}
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		terminate();
	}
	public void terminate() {
		super.terminate();
		try {
			Tibrv.close();
		} catch (Exception e) {
			log.warn("Failed to close Tibrv connection", e);
		}
	}
	public void publish(String channel, Message message) throws MactorException {
		sendMessage(channel, message, false);
	}
	public Message publishWithResponse(String channel, Message message) throws MactorException {
		return sendMessage(channel, message, true);
	}
	@Override
	protected void onFirstSubscribe(String channel) throws MactorException {
		registerListener(channel);
	}
	@Override
	protected void onLastSubscribe(String channel) throws MactorException {
		TibrvListener l = listeners.remove(channel);
		if (l != null)
			l.destroy();
	}
	private Message sendMessage(String channel, Message message, boolean expectResponse) throws MactorException {
		ChannelConfig cc = config.getRequieredChannelConfig(channel);
		String subject = cc.getRequieredValue("subject");
		try {
			TibrvMsg msg = new TibrvMsg();
			msg.setSendSubject(subject);
			msg.update(FIELD_NAME, new TibrvXml(message.getContent().getBytes()));
			if (expectResponse) {
				if (log.isDebugEnabled()) {
					log.debug("Sending message on channel: '" + channel + "', subject: '" + subject + "', message: '" + msg + "'. Expecting reponse message..");
				}
				TibrvMsg responseMessage = transport.sendRequest(msg, 0);
				return messageFromMessage(responseMessage);
			} else {
				if (log.isDebugEnabled()) {
					log.debug("Sending message on channel: '" + channel + "', subject: '" + subject + "', message: '" + msg + "'. No reponse message expected");
				}
				transport.send(msg);
				return null;
			}
		} catch (TibrvException tre) {
			throw new MactorException(tre);
		}
	}
	private void startDipatchThread() {
		Thread t = new Thread(new Runnable() {
			public void run() {
				while (true) {
					try {
						Tibrv.defaultQueue().dispatch();
					} catch (TibrvException e) {
						log.error("Error while dispatching message from default queue", e);
					} catch (InterruptedException ie) {
						log.info("Interrupted. Terminating dispatch loop..");
						return;
					}
				}
			}
		});
		t.start();
	}
	private Message messageFromMessage(TibrvMsg msg) throws MactorException, TibrvException {
		if (msg == null)
			throw new MactorException("Received an empty message");
		TibrvMsgField field = msg.getField(FIELD_NAME);
		if (field == null)
			throw new MactorException("Received a message without a '" + FIELD_NAME + "' field");
		if (!(field.data instanceof TibrvXml)) {
			throw new MactorException("Received a message where the '" + FIELD_NAME + "' field does not contain XML");
		}
		return Message.createMessage(new String(((TibrvXml) field.data).getBytes()));
	}
	Map<String, TibrvListener> listeners = new HashMap<String, TibrvListener>();
	private synchronized void registerListener(String channel) throws MactorException {
		ChannelConfig cc = config.getRequieredChannelConfig(channel);
		String subject = cc.getRequieredValue("subject");
		try {
			TibrvListener l = new TibrvListener(Tibrv.defaultQueue(), new SubjectListener(channel), transport, subject, null);
			listeners.put(channel, l);
		} catch (TibrvException tre) {
			throw new MactorException("Failed to create listener for channel '" + channel + "'", tre);
		}
	}
	private class SubjectListener implements TibrvMsgCallback {
		String channel;
		SubjectListener(String channel) {
			this.channel = channel;
		}
		public void onMsg(TibrvListener listener, TibrvMsg msg) {
			try {
				if (log.isDebugEnabled()) {
					log.debug("Received message on channel: '" + channel + "', subject: '" + msg.getSendSubject() + "', with reply subject: '" + msg.getReplySubject() + "', message: '" + msg + "'");
				}
				Message m = messageFromMessage(msg);
				Message resultMessage = raiseOnMessage(channel, m, false);
				if (resultMessage != null && msg.getReplySubject() != null) {
					TibrvMsg reyplyMsg = new TibrvMsg();
					reyplyMsg.update(FIELD_NAME, new TibrvXml(resultMessage.getContent().getBytes()));
					transport.sendReply(reyplyMsg, msg);
				}
			} catch (MactorException me) {
				log.info("Exception while processing message from channel '" + channel + "'", me);
			} catch (TibrvException tre) {
				log.warn("Tibco exception while processing message from channel '" + channel + "'", tre);
			}
		}
	}
}
