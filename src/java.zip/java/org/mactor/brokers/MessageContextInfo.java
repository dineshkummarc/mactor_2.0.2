/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers;

import java.util.Calendar;

import org.mactor.framework.spec.SpecNode;

/**
 * Context information about a message
 * 
 * @author Lars Ivar Almli
 */
public class MessageContextInfo {
	private String archivePath;
	private SpecNode node;
	private String channel;
	private Message responseToMessage;
	private Message responseMessage;
	private Calendar createdTime = Calendar.getInstance();
	private boolean incoming;
	private long messageSequenceNumber;
	public boolean isIncoming() {
		return incoming;
	}
	public boolean isResponseMessage() {
		return responseToMessage != null;
	}
	public boolean hasResponseMessage() {
		return responseMessage != null;
	}
	public void setIncoming(boolean incoming) {
		this.incoming = incoming;
	}
	public MessageContextInfo(long messageSequenceNumber) {
		this.messageSequenceNumber = messageSequenceNumber;
	}
	public String getArchivePath() {
		return archivePath;
	}
	public String getChannel() {
		return channel;
	}
	public SpecNode getNode() {
		return node;
	}
	public Message getResponseToMessage() {
		return responseToMessage;
	}
	public void setResponseToMessage(Message responseToMessage) {
		this.responseToMessage = responseToMessage;
	}
	public void setArchivePath(String archivePath) {
		this.archivePath = archivePath;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public void setNode(SpecNode node) {
		this.node = node;
	}
	public Calendar getCreatedTime() {
		return createdTime;
	}
	public long getMessageSequenceNumber() {
		return messageSequenceNumber;
	}
	public Message getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(Message responseMessage) {
		this.responseMessage = responseMessage;
	}
}
