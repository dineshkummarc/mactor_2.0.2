/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.mactor.brokers.MessageBrokerManager.MessageInfo;
import org.mactor.brokers.MessageBrokerManager.MessageInfoListener;
import org.mactor.framework.MactorException;
import org.mactor.framework.extensioninterface.MessageSelectorCommand;

/**
 * Provides archiving of all incoming and outgoing messages to the file system
 * and capturing of context info about the sent and receivd messages
 * 
 * @author Lars Ivar Almli
 */
class MessageBrokerDecorator implements MessageBroker {
	protected static Logger inLog = Logger.getLogger("MactorIncomingMessage");
	protected static Logger inResLog = Logger.getLogger("MactorIncomingResponse");
	protected static Logger outLog = Logger.getLogger("MactorOutgingMessage");
	protected static Logger outResLog = Logger.getLogger("MactorOutgingResponse");
	protected static Logger log = Logger.getLogger(MessageBrokerDecorator.class);
	private MessageBroker broker;
	private ArchiveUtil au;
	private String archivePath;
	static MessageInfoReporter reporter = createReporter();
	static MessageInfoReporter createReporter() {
		MessageInfoReporter r = new MessageInfoReporter();
		r.start();
		return r;
	}
	public MessageBrokerDecorator(boolean archiveMessages, String archivePath, MessageBroker broker) {
		if (archiveMessages)
			this.au = new ArchiveUtil(archivePath);
		this.archivePath = archivePath;
		this.broker = broker;
	}
	Map<String, Set<MessageInfoListener>> listeners = new HashMap<String, Set<MessageInfoListener>>();
	public synchronized void addMessageInfoListener(String channel, MessageInfoListener listener) {
		Set<MessageInfoListener> cl = listeners.get(channel);
		if (cl == null) {
			cl = new HashSet<MessageInfoListener>();
			listeners.put(channel, cl);
		}
		cl.add(listener);
	}
	public synchronized void removeMessageInfoListener(String channel, MessageInfoListener listener) {
		Set<MessageInfoListener> cl = listeners.get(channel);
		if (cl != null) {
			cl.remove(listener);
		}
	}
	public void publish(String channel, Message message) throws MactorException {
		if (message == null)
			throw new MactorException("Can not publish an empty message");
		if (log.isDebugEnabled())
			log.debug("publish on " + channel);
		message.getMessageContextInfo().setChannel(channel);
		message.getMessageContextInfo().setIncoming(false);
		File f = null;
		if (au != null)
			f = au.archive(channel, message);
		if (f != null)
			message.getMessageContextInfo().setArchivePath(f.getAbsolutePath());
		reporter.addJob(listeners.get(channel), message.getMessageContextInfo());
		outLog.info(channel);
		broker.publish(channel, message);
	}
	public Message publishWithResponse(String channel, Message message) throws MactorException {
		if (message == null)
			throw new MactorException("Can not publish an empty message");
		if (log.isDebugEnabled())
			log.debug("publishWithResponse on " + channel);
		message.getMessageContextInfo().setChannel(channel);
		message.getMessageContextInfo().setIncoming(false);
		File f = null;
		if (au != null)
			f = au.archive(channel, message);
		if (f != null)
			message.getMessageContextInfo().setArchivePath(f.getAbsolutePath());
		reporter.addJob(listeners.get(channel), message.getMessageContextInfo());
		outLog.info(channel);
		Message res = broker.publishWithResponse(channel, message);
		if (res != null) {
			outResLog.info(channel);
			res.getMessageContextInfo().setIncoming(true);
			res.getMessageContextInfo().setResponseToMessage(message);
			res.getMessageContextInfo().setChannel(channel);
			message.getMessageContextInfo().setResponseMessage(res);
			if (au != null)
				f = au.archive_response(f, res);
			if (f != null)
				res.getMessageContextInfo().setArchivePath(f.getAbsolutePath());
			reporter.addJob(listeners.get(channel), res.getMessageContextInfo());
		}
		return res;
	}
	Map<MessageSubscriber, MessageBrokerDecoratorIncoming> map = new HashMap<MessageSubscriber, MessageBrokerDecoratorIncoming>();
	public void subscribe(String channel, MessageSubscriber subscriber, MessageSelectorCommand messageSelector) throws MactorException {
		MessageBrokerDecoratorIncoming decorator = new MessageBrokerDecoratorIncoming(au != null, channel, archivePath, subscriber);
		map.put(subscriber, decorator);
		broker.subscribe(channel, decorator, messageSelector);
	}
	public void unsubscribe(String channel, MessageSubscriber subscriber) throws MactorException {
		broker.unsubscribe(channel, map.remove(subscriber));
	}
	private class MessageBrokerDecoratorIncoming implements MessageSubscriber {
		private MessageSubscriber subscriber;
		private String channel;
		private ArchiveUtil au;
		public MessageBrokerDecoratorIncoming(boolean archiveMessages, String channel, String path, MessageSubscriber subscriber) {
			this.subscriber = subscriber;
			this.channel = channel;
			if (archiveMessages)
				this.au = new ArchiveUtil(path);
		}
		public Message onMessage(Message message) {
			File f = null;
			message.getMessageContextInfo().setChannel(channel);
			message.getMessageContextInfo().setIncoming(true);
			if (au != null)
				f = au.archive(channel, message);
			if (f != null)
				message.getMessageContextInfo().setArchivePath(f.getAbsolutePath());
			inLog.info(channel);
			reporter.addJob(listeners.get(channel), message.getMessageContextInfo());
			Message res = subscriber.onMessage(message);
			if (res != null) {
				if (au != null)
					f = au.archive_response(f, res);
				res.getMessageContextInfo().setResponseToMessage(message);
				res.getMessageContextInfo().setChannel(channel);
				message.getMessageContextInfo().setResponseMessage(res);
				res.getMessageContextInfo().setIncoming(false);
				if (f != null)
					res.getMessageContextInfo().setArchivePath(f.getAbsolutePath());
				inResLog.info(channel);
				reporter.addJob(listeners.get(channel), res.getMessageContextInfo());
			}
			return res;
		}
	}
	public void terminate() {
		map.clear();
		broker.terminate();
		listeners.clear();
	}
	private static class MessageInfoReporter implements Runnable {
		LinkedList<ReportJob> jobs = new LinkedList<ReportJob>();
		private Object lock = new Object();
		MessageInfoReporter() {
		}
		public void run() {
			for (;;) {
				try {
					LinkedList<ReportJob> todo = null;
					synchronized (lock) {
						if (jobs.size() > 0) {
							todo = jobs;
							jobs = new LinkedList<ReportJob>();
						} else {
							lock.wait();
						}
					}
					if (todo != null)
						doJobs(todo);
				} catch (Throwable t) {
					t.printStackTrace();
				}
			}
		}
		private void doJobs(LinkedList<ReportJob> jobs) {
			for (ReportJob job : jobs) {
				// ignore job.listeners - concurrent mod.. (listeners are not
				// added removed
				// frequently)
				for (MessageInfoListener l : job.listeners) {
					l.onMessageInfo(MessageInfo.create(job.messageInfo));
				}
			}
		}
		public void addJob(Set<MessageInfoListener> listeners, MessageContextInfo messageInfo) {
			if (listeners == null || listeners.isEmpty())
				return;
			synchronized (lock) {
				jobs.add(new ReportJob(listeners, messageInfo));
				lock.notify();
			}
		}
		public void start() {
			new Thread(this).start();
		}
		private static class ReportJob {
			public Set<MessageInfoListener> listeners;
			public MessageContextInfo messageInfo;
			public ReportJob(Set<MessageInfoListener> listeners, MessageContextInfo messageInfo) {
				this.listeners = listeners;
				this.messageInfo = messageInfo;
			}
		}
	}
	public String getArchivePath() {
		return archivePath;
	}
}
