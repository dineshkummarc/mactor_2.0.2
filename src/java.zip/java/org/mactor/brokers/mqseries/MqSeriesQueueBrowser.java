/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.mqseries;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.mactor.brokers.Message;
import org.mactor.framework.MactorException;
import org.mactor.framework.ParseUtil;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

/**
 * 
 * @author Lars Ivar Almli
 */
public class MqSeriesQueueBrowser {
	protected static Logger log = Logger.getLogger(MqSeriesQueueBrowser.class);
	private MQQueue mqQueue;
	private MQQueueManager mqQueueManager;
	private String channel;
	MQMessage mqMessage = new MQMessage();
	MQGetMessageOptions gmo = new MQGetMessageOptions();
	static {
		MQException.log = null;
	}
	public MqSeriesQueueBrowser(ChannelConfig cf) throws MactorException {
		this.channel = cf.getName();
		Hashtable props = new Hashtable();
		try {
			props.put(MQC.TRANSPORT_PROPERTY, MQC.TRANSPORT_MQSERIES_CLIENT);
			props.put(MQC.HOST_NAME_PROPERTY, cf.getRequieredValue("host"));
			props.put(MQC.PORT_PROPERTY, new Integer(ParseUtil.tryParseIntVal(cf.getRequieredValue("port"))));
			props.put(MQC.CHANNEL_PROPERTY, cf.getRequieredValue("channel"));
			mqQueueManager = new MQQueueManager(cf.getRequieredValue("queue_manager"), props);
			mqQueue = mqQueueManager.accessQueue(cf.getRequieredValue("queue"), MQC.MQOO_BROWSE);
		} catch (MQException e) {
			throw new MactorException(e);
		}
	}
	public Message browseFirstMessage() throws MactorException {
		return browseMessage(MQC.MQGMO_NO_WAIT | MQC.MQGMO_BROWSE_FIRST);
	}
	public Message browseNextMessage() throws MactorException {
		return browseMessage(MQC.MQGMO_NO_WAIT | MQC.MQGMO_BROWSE_NEXT);
	}
	public void consumeMessage() throws MactorException {
		try {
			gmo.options = MQC.MQGMO_MSG_UNDER_CURSOR;
			mqQueue.get(mqMessage, gmo);
		} catch (MQException me) {
			throw new MactorException("Failed to consume the message. Error:" + me.getMessage(), me);
		}
	}
	private Message browseMessage(int options) throws MactorException {
		try {
			mqMessage.clearMessage();
			mqMessage.correlationId = MQC.MQCI_NONE;
			mqMessage.messageId = MQC.MQMI_NONE;
			gmo.options = options;
			mqQueue.get(mqMessage, gmo);
			int len = mqMessage.getTotalMessageLength();
			if (len > 0) {
				byte[] buffer = new byte[mqMessage.getTotalMessageLength()];
				mqMessage.readFully(buffer);
				return Message.createMessage(new ByteArrayInputStream(buffer));
			}
		} catch (MQException me) {
			if (me.reasonCode == 2033) {// no messages
			} else
				throw new MactorException("MQ Series error occured with completion code '" + me.completionCode + "' and reeason code '" + me.reasonCode + "' while attempting to read from channel '"
						+ channel + "'");
		} catch (IOException ioe) {
			ioe.printStackTrace();
			throw new MactorException("An IOException occured while trying to browse a message from channel '" + channel + "'", ioe);
		}
		return null;
	}
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		close();
	}
	public void close() {
		try {
			if (mqQueue != null)
				mqQueue.close();
			mqQueueManager.disconnect();
		} catch (MQException ex) {
			log.info("A WebSphere MQ Error occured : Completion Code " + ex.completionCode + " Reason Code " + ex.reasonCode);
		} catch (Exception ex) {
			log.info("An IOException occured whilst writing to the message buffer: " + ex);
		}
	}
}
