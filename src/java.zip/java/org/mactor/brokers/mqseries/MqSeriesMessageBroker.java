/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.mqseries;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.mactor.brokers.Message;
import org.mactor.brokers.PollingMessageBrokerTemplate;
import org.mactor.framework.MactorException;
import org.mactor.framework.ParseUtil;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQMsg2;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

/**
 * A message broker for IBM MQ Series (add the com.ibm.mq.jar library from your
 * version of MQ Series to the MActor classpath)
 * <p>
 * 
 * @author Lars Ivar Almli
 */
public class MqSeriesMessageBroker extends PollingMessageBrokerTemplate {
	private Map<String, MqConnectionWrapper> channelMap = new HashMap<String, MqConnectionWrapper>();
	private MessageBrokerConfig config;
	static {
		MQException.log = null;
	}
	public void terminate() {
		super.terminate();
		for (MqConnectionWrapper mq : channelMap.values())
			mq.close();
		channelMap.clear();
	}
	public MqSeriesMessageBroker(MessageBrokerConfig config) {
		super(config);
		this.config = config;
	}
	private MqConnectionWrapper getMqConnectionWrapper(String channel) throws MactorException {
		MqConnectionWrapper w = channelMap.get(channel);
		if (w == null) {
			w = new MqConnectionWrapper(config.getRequieredChannelConfig(channel));
			channelMap.put(channel, w);
		}
		return w;
	}
	protected List<Message> doGetMessages(String channel, int maxMessageCount) throws MactorException {
		List<Message> messages = new LinkedList<Message>();
		MqConnectionWrapper cw = getMqConnectionWrapper(channel);
		for (int i = 0; i < maxMessageCount; i++) {
			Message m = cw.getMessage();
			if (m == null)
				break;
			messages.add(m);
		}
		return messages;
	}
	protected void doPublishMessage(String channel, Message message) throws MactorException {
		getMqConnectionWrapper(channel).sendMessage(message);
	}
	private class MqConnectionWrapper {
		private String channel;
		private String mqQueueManagerName;
		private String mqHost;
		private int mqPort;
		private String mqQueue;
		private String mqChannel;
		private MQQueue mqOutgoingQueue;
		private MQQueue mqIncomingQueue;
		private MQQueueManager mqQueueManager;
		public MqConnectionWrapper(ChannelConfig cf) throws MactorException {
			this.mqQueueManagerName = cf.getRequieredValue("queue_manager");
			this.mqHost = cf.getRequieredValue("host");
			this.mqPort = ParseUtil.tryParseIntVal(cf.getRequieredValue("port"));
			this.mqQueue = cf.getRequieredValue("queue");
			this.mqChannel = cf.getRequieredValue("channel");
			this.channel = cf.getName();
		}
		public void sendMessage(Message message) throws MactorException {
			try {
				MQMsg2 msg = new MQMsg2();
				msg.setMessageData(message.getContent().trim().getBytes());
				MQPutMessageOptions pmo = new MQPutMessageOptions();
				getOutgoingQueue().putMsg2(msg, pmo);
			} catch (MQException me) {
				throw new MactorException("MQ Series error occured with completion code '" + me.completionCode + "' and reeason code '" + me.reasonCode + "' while attempting to send to channel  '"
						+ channel + "'");
			}
		}
		private final static String RFH2_FORMAT = "MQHRF2  ";
		public Message getMessage() throws MactorException {
			try {
				MQMessage rcvMessage = new MQMessage();
				MQGetMessageOptions gmo = new MQGetMessageOptions();
				gmo.options = MQC.MQGMO_WAIT;
				gmo.waitInterval = 500;// 500ms
				getIncomingQueue().get(rcvMessage, gmo);
				int headerLength = 0;
				if (RFH2_FORMAT.equals(rcvMessage.format)) { // Skip RFH2
																// header
					rcvMessage.seek(4);
					int version = rcvMessage.readInt();
					headerLength = rcvMessage.readInt();
					int encoding = rcvMessage.readInt();
					int codedCharSetId = rcvMessage.readInt();
					rcvMessage.skipBytes(8);
					int flags = rcvMessage.readInt();
					int nameValueCodedCharSetId = rcvMessage.readInt();
					rcvMessage.seek(headerLength);
				}
				int len = rcvMessage.getTotalMessageLength() - headerLength;
				if (len > 0) {
					byte[] buffer = new byte[len];
					rcvMessage.readFully(buffer);
					return Message.createMessage(new ByteArrayInputStream(buffer));
				}
			} catch (MQException me) {
				if (me.reasonCode == 2033) {// no messages
				} else
					throw new MactorException("MQ Series error occured with completion code '" + me.completionCode + "' and reeason code '" + me.reasonCode
							+ "' while attempting to read from channel '" + channel + "'");
			} catch (IOException ioe) {
				ioe.printStackTrace();
				throw new MactorException("An IOException occured while trying to read a message from channel '" + channel + "'", ioe);
			}
			return null;
		}
		private Hashtable buildProperties() {
			Hashtable props = new Hashtable();
			props.put(MQC.TRANSPORT_PROPERTY, MQC.TRANSPORT_MQSERIES_CLIENT);
			props.put(MQC.HOST_NAME_PROPERTY, mqHost);
			props.put(MQC.PORT_PROPERTY, new Integer(mqPort));
			props.put(MQC.CHANNEL_PROPERTY, mqChannel);
			return props;
		}
		private MQQueueManager getManager() throws MQException {
			if (mqQueueManager == null) {
				mqQueueManager = new MQQueueManager(mqQueueManagerName, buildProperties());
			}
			return mqQueueManager;
		}
		private MQQueue getOutgoingQueue() throws MQException {
			if (mqOutgoingQueue == null) {
				mqOutgoingQueue = getManager().accessQueue(mqQueue, MQC.MQOO_OUTPUT);
			}
			return mqOutgoingQueue;
		}
		private MQQueue getIncomingQueue() throws MQException {
			if (mqIncomingQueue == null) {
				mqIncomingQueue = getManager().accessQueue(mqQueue, MQC.MQOO_INPUT_AS_Q_DEF);
			}
			return mqIncomingQueue;
		}
		@Override
		protected void finalize() throws Throwable {
			super.finalize();
			close();
		}
		public void close() {
			try {
				if (mqOutgoingQueue != null)
					mqOutgoingQueue.close();
				if (mqIncomingQueue != null)
					mqIncomingQueue.close();
				mqQueueManager.disconnect();
			} catch (MQException ex) {
				log.info("A WebSphere MQ Error occured : Completion Code " + ex.completionCode + " Reason Code " + ex.reasonCode);
			} catch (Exception ex) {
				log.info("An IOException occured whilst writing to the message buffer: " + ex);
			}
		}
	}
}
