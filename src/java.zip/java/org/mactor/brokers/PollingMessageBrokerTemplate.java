/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.mactor.brokers.file.FileMessageBroker;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;

/**
 * A template for implementing message brokers for polling bases protocols (i.e.
 * such as file system polling)
 * 
 * @see FileMessageBroker
 * @author Lars Ivar Almli
 */
public abstract class PollingMessageBrokerTemplate extends AbstractMessageBroker {
	protected static Logger log = Logger.getLogger(PollingMessageBrokerTemplate.class);
	private final int messageReadLimit;
	private final int messageReadIntervalSeconds;
	public PollingMessageBrokerTemplate(MessageBrokerConfig config) {
		super(config);
		this.messageReadLimit = config.getMessageReadLimit();
		this.messageReadIntervalSeconds = config.getMessageReadIntervalSeconds();
	}
	public Message publishWithResponse(String channel, Message message) throws MactorException {
		publish(channel, message);
		return null;
	}
	public void publish(String channel, Message message) throws MactorException {
		doPublishMessage(channel, message);
	}
	public void terminate() {
		super.terminate();
		for (PollingWorker pw : workerMap.values())
			pw.terminate();
		workerMap.clear();
	}
	/**
	 * Template method called to check for incoming messages (the polling
	 * interval is defined by the message broker config)
	 * 
	 * @param channel
	 *            the channel
	 * @param maxMessageCount
	 *            the max number of messages to return (as defined in the
	 *            message broker config).
	 * @return list of messages
	 * @throws MactorException
	 *             if a problem occured (this will not cause the test to fail)
	 */
	protected abstract List<Message> doGetMessages(String channel, int maxMessageCount) throws MactorException;
	/**
	 * Template method called to publish a message.
	 * 
	 * @param channel
	 *            the channel
	 * @param message
	 *            the message
	 * @throws MactorException
	 *             if a problem occured (this will cause the test to fail)
	 */
	protected abstract void doPublishMessage(String channel, Message message) throws MactorException;
	Map<String, PollingWorker> workerMap = new HashMap<String, PollingWorker>();
	@Override
	protected void onFirstSubscribe(String channel) {
		workerMap.put(channel, new PollingWorker(channel));
	}
	@Override
	protected void onLastSubscribe(String channel) throws MactorException {
		PollingWorker pw = workerMap.remove(channel);
		pw.terminate();
	}
	private class PollingWorker {
		private String channel;
		private boolean terminated = false;
		public PollingWorker(String channel) {
			this.channel = channel;
			new Thread(new Runnable() {
				public void run() {
					work();
				};
			}).start();
		}
		private Object waitLock = new Object();
		public void terminate() {
			terminated = true;
			synchronized (waitLock) {
				waitLock.notifyAll();
			}
		}
		private void work() {
			try {
				while (!terminated) {
					synchronized (waitLock) {
						waitLock.wait(messageReadIntervalSeconds * 1000);
					}
					if (terminated)
						break;
					List<Message> candidates = null;
					try {
						log.debug("Polling for messages on channel '" + channel + "'");
						candidates = doGetMessages(this.channel, messageReadLimit);
					} catch (Exception me) {
						log.error("Error while polling for messages on channel '" + channel + "'", me);
					}
					if (candidates == null || candidates.size() == 0)
						continue;
					candidates = new LinkedList<Message>(candidates);
					for (Message message : candidates) {
						try {
							PollingMessageBrokerTemplate.this.raiseOnMessage(channel, message, false);
						} catch (Exception e) {
							log.info("Exception while delivering message to subscribers. Message: " + message, e);
						}
					}
				}
			} catch (InterruptedException ie) {
			} finally {
				log.info("Channel polling worker for channel '" + channel + "' terminated");
			}
		}
	}
}