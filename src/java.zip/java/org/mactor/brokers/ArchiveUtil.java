/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers;

import java.io.File;

import org.apache.log4j.Logger;
import org.mactor.framework.AppUtil;
import org.mactor.framework.MactorException;

class ArchiveUtil {
	protected static Logger log = Logger.getLogger(ArchiveUtil.class);
	private static long counter = System.currentTimeMillis();
	private static synchronized long getNext() {
		return counter++;
	}
	String out_prefix = AppUtil.getNextId("out_") + "_";
	String in_prefix = AppUtil.getNextId("in_") + "_";
	String path;
	public ArchiveUtil(String path) {
		this.path = path;
	}
	public File archive(String channel, Message message) {
		if (message == null)
			return null;
		File dir = new File(path + "/" + channel);
		if (log.isDebugEnabled())
			log.debug("Archive dir:" + dir.getAbsolutePath());
		if (!dir.exists() && !dir.mkdirs()) {
			log.info("Unable to archive messages. Directory '" + dir.getAbsolutePath() + "' could not be created");
			return null;
		}
		File file = null;
		try {
			String prefix = message.getMessageContextInfo().isIncoming() ? in_prefix : out_prefix;
			file = new File(dir.getAbsolutePath() + "/" + prefix + getNext() + ".xml");
			if (log.isDebugEnabled())
				log.debug("Archiving file:" + file.getAbsolutePath());
			message.writeToFile(file);
			return file;
		} catch (MactorException e) {
			log.info("Failed to archive message. Path '" + file.getAbsolutePath() + "'. Error: " + e.getMessage(), e);
		}
		return null;
	}
	public File archive_response(File relatedFile, Message message) {
		if (relatedFile == null || message == null)
			return null;
		File file = null;
		try {
			String prefix = message.getMessageContextInfo().isIncoming() ? "in_" : "out_";
			String dir = relatedFile.getParentFile().getAbsolutePath();
			String name = relatedFile.getName();
			file = new File(dir + "/" + prefix + name + "_resp.xml");
			if (log.isDebugEnabled())
				log.debug("Archiving file:" + file.getAbsolutePath());
			message.writeToFile(file);
		} catch (MactorException e) {
			log.info("Failed to archive message. Path '" + file.getAbsolutePath() + "'. Error: " + e.getMessage(), e);
		}
		return file;
	}
}
