/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.jms;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TemporaryQueue;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.mactor.brokers.AbstractMessageBroker;
import org.mactor.brokers.Message;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;

/**
 * A message broker for JMS (it should work with any JMS implementation - just
 * add the client JMS libraries from the particular JMS product to the MActor
 * class path)
 * 
 * @author Lars Ivar Almli
 */
public class JmsMessageBroker extends AbstractMessageBroker {
	public JmsMessageBroker(MessageBrokerConfig config) {
		super(config);
	}
	protected void onFirstSubscribe(String channel) throws MactorException {
		createSubscriber(config.getRequieredChannelConfig(channel));
	}
	public void publish(String channel, Message message) throws MactorException {
		getSender(config.getRequieredChannelConfig(channel)).send(message);
	}
	public Message publishWithResponse(String channel, Message message) throws MactorException {
		return getSender(config.getRequieredChannelConfig(channel)).send(message);
	}
	Map<String, Subscriber> subscribers = new HashMap<String, Subscriber>();
	public void createSubscriber(ChannelConfig channelConfig) throws MactorException {
		subscribers.put(channelConfig.getName(), new Subscriber(channelConfig));
	}
	@Override
	protected void onLastSubscribe(String channel) throws MactorException {
		Subscriber s = subscribers.remove(channel);
		if (s != null)
			s.close();
	}
	Map<String, Sender> senders = new HashMap<String, Sender>();
	private synchronized Sender getSender(ChannelConfig channelConfig) throws MactorException {
		Sender s = senders.get(channelConfig.getName());
		if (s == null) {
			s = new Sender(channelConfig);
			senders.put(channelConfig.getName(), s);
		}
		return s;
	}
	private class Sender {
		private QueueConnection qcon;
		private QueueSession qsession;
		private QueueSender qsender;
		private boolean respReq;
		public Sender(ChannelConfig channelConfig) throws MactorException {
			try {
				respReq = channelConfig.isRequiresResponse();
				String url = channelConfig.getRequieredValue("url");
				String connectionFactory = channelConfig.getRequieredValue("connection_factory");
				String contextFactory = channelConfig.getRequieredValue("initial_context_factory");
				String queueName = channelConfig.getRequieredValue("queue");
				String userName = channelConfig.getValue("username");
				String password = channelConfig.getValue("password");
				InitialContext ctx = getInitialContext(url, contextFactory);
				QueueConnectionFactory qconFactory = (QueueConnectionFactory) ctx.lookup(connectionFactory);
				if (userName != null && userName.length() > 0)
					this.qcon = qconFactory.createQueueConnection(userName, password);
				else
					this.qcon = qconFactory.createQueueConnection();
				this.qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
				Queue queue = (Queue) ctx.lookup(queueName);
				this.qsender = qsession.createSender(queue);
				qcon.start();
			} catch (Exception e) {
				throw new MactorException("Failed to create sender for channel '" + channelConfig.getName() + "'. Error:" + e.getMessage(), e);
			}
		}
		public Message send(Message message) throws MactorException {
			try {
				TextMessage m = qsession.createTextMessage();
				m.setText(message.getContent());
				TemporaryQueue replyQueue = null;
				if (respReq) {
					replyQueue = qsession.createTemporaryQueue();
					m.setJMSReplyTo(replyQueue);
				}
				qsender.send(m);
				if (respReq) {
					try {
						javax.jms.Message resp = qsession.createReceiver(replyQueue).receive(5 * 60 * 1000);// 5
						if (resp != null) {
							String msgText = null;
							if (resp instanceof TextMessage) {
								msgText = ((TextMessage) resp).getText();
							} else {
								msgText = resp.toString();
							}
							if (msgText != null)
								return Message.createMessage(msgText);
						}
					} finally {
						replyQueue.delete();
					}
				}
				return null;
			} catch (JMSException je) {
				throw new MactorException(je);
			}
		}
		public void close() {
			try {
				qsender.close();
				qsession.close();
				qcon.close();
			} catch (JMSException e) {
				log.warn("Failed to release queue sender", e);
			}
		}
	}
	private static InitialContext getInitialContext(String url, String jndiFactory) throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, jndiFactory);
		env.put(Context.PROVIDER_URL, url);
		return new InitialContext(env);
	}
	private class Subscriber {
		private QueueConnection qcon;
		private QueueSession qsession;
		private QueueReceiver qreceiver;
		private String channel;
		public Subscriber(ChannelConfig channelConfig) throws MactorException {
			this.channel = channelConfig.getName();
			try {
				String url = channelConfig.getRequieredValue("url");
				String connectionFactory = channelConfig.getRequieredValue("connection_factory");
				String contextFactory = channelConfig.getRequieredValue("initial_context_factory");
				String queueName = channelConfig.getRequieredValue("queue");
				String userName = channelConfig.getValue("username");
				String password = channelConfig.getValue("password");
				InitialContext ctx = getInitialContext(url, contextFactory);
				QueueConnectionFactory qconFactory = (QueueConnectionFactory) ctx.lookup(connectionFactory);
				if (userName != null && userName.length() > 0)
					this.qcon = qconFactory.createQueueConnection(userName, password);
				else
					this.qcon = qconFactory.createQueueConnection();
				this.qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
				Queue queue = (Queue) ctx.lookup(queueName);
				this.qreceiver = qsession.createReceiver(queue);
				this.qreceiver.setMessageListener(new MessageListener() {
					public void onMessage(javax.jms.Message message) {
						try {
							String msgText = null;
							if (message instanceof TextMessage) {
								msgText = ((TextMessage) message).getText();
							} else {
								msgText = message.toString();
							}
							Message resp = raiseOnMessage(Subscriber.this.channel, Message.createMessage(msgText), false);
							if (resp != null) {
								Destination replyTo = message.getJMSReplyTo();
								if (replyTo == null) {
									log.warn("Unable to deliver the reply message. The message received on channel '" + Subscriber.this.channel + "' does not contain a 'replyTo' destination");
								} else {
									String corrId = message.getJMSCorrelationID();
									TextMessage replyMessage = qsession.createTextMessage();
									if (corrId != null)
										replyMessage.setJMSCorrelationID(corrId);
									replyMessage.setText(resp.getContent());
									qsession.createSender((Queue) replyTo).send(replyMessage);
								}
							}
						} catch (Exception e) {
							log.warn("Exception after receiving jms message on channel '" + Subscriber.this.channel + "'. Message:" + message, e);
						}
					}
				});
				qcon.start();
			} catch (Exception e) {
				e.printStackTrace();
				throw new MactorException("Failed to create receiver for channel '" + channelConfig.getName() + "'. Error:" + e.getMessage(), e);
			}
		}
		public void close() {
			try {
				qreceiver.close();
				qsession.close();
				qcon.close();
			} catch (JMSException e) {
				log.warn("Failed to release queue receiver", e);
			}
		}
	}
	public void terminate() {
		super.terminate();
		for (Sender s : senders.values())
			s.close();
		senders.clear();
		for (Subscriber s : subscribers.values())
			s.close();
		subscribers.clear();
	}
}
