/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Map;

import javax.xml.transform.Templates;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.io.DocumentResult;
import org.dom4j.io.DocumentSource;
import org.dom4j.io.SAXReader;
import org.mactor.framework.AppUtil;
import org.mactor.framework.MactorException;

/**
 * The message implementation
 * 
 * @author Lars Ivar Almli
 */
public class Message {
	private boolean consumed;
	private Document doc;
	private Document docNoNs;
	private String content;
	private Map<String, String> messageProperties;
	private MessageContextInfo messageContextInfo;
	private static String app_instance_id = AppUtil.getAppInstanceId();
	private String id;
	private static Object lock = new Object();
	private static long counter = 0;
	private static long getNextId() {
		synchronized (lock) {
			return counter++;
		}
	}
	public Message() {
		long seq = getNextId();
		this.id = app_instance_id + "_" + seq;
		this.messageContextInfo = new MessageContextInfo(seq);
	}
	public Map<String, String> getMessageProperties() {
		return messageProperties;
	}
	public void consume() {
		this.consumed = true;
	}
	public boolean isConsumed() {
		return consumed;
	}
	public String getContent() {
		return content;
	}
	public Document getContentDocument() throws MactorException {
		if (this.doc != null)
			return this.doc;
		try {
			this.doc = DocumentHelper.parseText(content);
			return this.doc;
		} catch (DocumentException de) {
			throw new MactorException("Can not construct a message from invalid XML. Error:" + de.getMessage() + ". Message: '" + content + "'", de);
		}
	}
	public static Message createMessage(String content) throws MactorException {
		if (content == null || content.length() == 0)
			throw new MactorException("Can not create a message wihtout content");
		return createMessage(content, null);
	}
	public static Message createMessage(String content, Map<String, String> messageProperties) throws MactorException {
		Message m = new Message();
		m.content = content;
		m.getContentDocument();// force parse..
		m.messageProperties = messageProperties;
		return m;
	}
	public static Message createMessage(Document doc) throws MactorException {
		return createMessage(doc, null);
	}
	public static Message createMessage(Document doc, Map<String, String> messageProperties) throws MactorException {
		Message m = new Message();
		m.doc = doc;
		m.content = doc.asXML();
		m.messageProperties = messageProperties;
		return m;
	}
	public static Message createMessage(InputStream inputStream) throws MactorException {
		return createMessage(inputStream, null);
	}
	public static Message createMessage(InputStream inputStream, Map<String, String> messageProperties) throws MactorException {
		try {
			Message m = new Message();
			m.doc = new SAXReader().read(inputStream);
			m.content = m.doc.asXML();
			m.messageProperties = messageProperties;
			return m;
		} catch (DocumentException de) {
			throw new MactorException(de);
		}
	}
	public static Message createMessage(Reader reader) throws MactorException {
		return createMessage(reader, null);
	}
	public static Message createMessage(Reader reader, Map<String, String> messageProperties) throws MactorException {
		try {
			Message m = new Message();
			m.doc = new SAXReader().read(reader);
			m.content = m.doc.asXML();
			m.messageProperties = messageProperties;
			return m;
		} catch (DocumentException de) {
			throw new MactorException(de);
		}
	}
	public static Message createMessage(File file) throws MactorException {
		return createMessage(file, null);
	}
	public static Message createMessage(File file, Map<String, String> messageProperties) throws MactorException {
		try {
			return createMessage(new FileReader(file), messageProperties);
		} catch (IOException ioe) {
			throw new MactorException("Failed to load the message from file '" + file.getAbsolutePath() + "'", ioe);
		}
	}
	public void writeToFile(File destFile) throws MactorException {
		try {
			FileWriter w = new FileWriter(destFile);
			doc.write(w);
			w.flush();
			w.close();
		} catch (IOException ioe) {
			throw new MactorException("Failed to write the  file '" + destFile.getAbsolutePath() + "'. Error:" + ioe.getMessage(), ioe);
		}
	}
	public Document getContentDocumentNoNs() throws MactorException {
		if (docNoNs != null)
			return docNoNs;
		if (doc == null)
			return null;
		try {
			TransformerFactory factory = TransformerFactory.newInstance();
			Templates t = factory.newTemplates(new StreamSource(Thread.currentThread().getContextClassLoader().getResourceAsStream("remove-ns.xsl")));
			DocumentSource source = new DocumentSource(doc);
			DocumentResult result = new DocumentResult();
			t.newTransformer().transform(source, result);
			this.docNoNs = result.getDocument();
			return docNoNs;
		} catch (TransformerException tfe) {
			throw new MactorException("Failed remove namespaces from document Error:" + tfe.getMessage(), tfe);
		}
	}
	public String getId() {
		return id;
	}
	public MessageContextInfo getMessageContextInfo() {
		return messageContextInfo;
	}
}
