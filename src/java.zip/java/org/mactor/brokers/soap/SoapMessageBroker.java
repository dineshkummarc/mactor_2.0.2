/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.soap;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.dom4j.io.SAXReader;
import org.mactor.brokers.AbstractMessageBroker;
import org.mactor.brokers.Message;
import org.mactor.brokers.MessageBroker;
import org.mactor.brokers.http.HttpRequest;
import org.mactor.brokers.http.HttpRequestListener;
import org.mactor.brokers.http.HttpResponse;
import org.mactor.brokers.http.HttpServerManager;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;

/**
 * A SOAP message broker that supports both incoming operations (MActor working
 * as a SOAP-server) and outgoing operations (MActor working as a SOAP-client)
 * 
 * </p>
 * 
 * @author Lars Ivar Almli
 * @see MessageBroker
 */
public class SoapMessageBroker extends AbstractMessageBroker {
	public SoapMessageBroker(MessageBrokerConfig config) {
		super(config);
	}
	public void publish(String channel, Message message) throws MactorException {
		ChannelConfig cc = config.getRequieredChannelConfig(channel);
		sendSoapMessage(cc.getRequieredValue("SoapEndpoint"), cc.getRequieredValue("SoapAction"), cc.getValue("Username"), cc.getValue("Password"), message);
	}
	public Message publishWithResponse(String channel, Message message) throws MactorException {
		ChannelConfig cc = config.getRequieredChannelConfig(channel);
		return sendSoapMessage(cc.getRequieredValue("SoapEndpoint"), cc.getRequieredValue("SoapAction"), cc.getValue("Username"), cc.getValue("Password"), message);
	}
	@Override
	protected void onFirstSubscribe(String channel) throws MactorException {
		// System.out.println("onFirstSubscribe");
		ChannelConfig cc = config.getRequieredChannelConfig(channel);
		SoapEndpointListener epListener = getSoapEndpointListener(cc);
		String action = cc.getRequieredValue("SoapAction");
		epListener.addActionBinding(action, channel);
	}
	@Override
	protected void onLastSubscribe(String channel) throws MactorException {
		// System.out.println("onLastSubscribe");
		ChannelConfig cc = config.getRequieredChannelConfig(channel);
		SoapEndpointListener epListener = getSoapEndpointListener(cc);
		String action = cc.getRequieredValue("SoapAction");
		epListener.removeActionBinding(action);
		if (epListener.getActionBindingCount() == 0) {
			endpointListenerMap.remove(epListener.endpointKey);
			epListener.terminate();
		}
	}
	private SoapEndpointListener getSoapEndpointListener(ChannelConfig cc) throws MactorException {
		try {
			String endpoint = cc.getRequieredValue("SoapEndpoint");
			URL url = new URL(endpoint);
			int port = url.getDefaultPort();
			if (url.getPort() > 0)
				port = url.getPort();
			String real = url.getPath();
			if (url.getQuery() != null)
				real = real + "?" + url.getQuery();
			real = real.toLowerCase();
			String key = port + "-" + real;
			SoapEndpointListener l = endpointListenerMap.get(key);
			if (l == null) {
				l = new SoapEndpointListener(key, real, port, cc.getValue("WsdlFile"));
				endpointListenerMap.put(key, l);
			}
			return l;
		} catch (MalformedURLException e) {
			throw new ConfigException(e);
		}
	}
	public void terminate() {
		super.terminate();
		for (SoapEndpointListener l : endpointListenerMap.values())
			l.terminate();
	}
	private class WsdlProvider implements HttpRequestListener {
		File w;
		public WsdlProvider(File w) {
			this.w = w;
		}
		public HttpResponse onRequest(HttpRequest request) throws Exception {
			HttpResponse res = new HttpResponse();
			res.addHeader("Content-type", "text/xml");
			res.setData(new SAXReader().read(w));
			return res;
		}
	}
	private Map<String, SoapEndpointListener> endpointListenerMap = Collections.synchronizedMap(new HashMap<String, SoapEndpointListener>());
	private class SoapEndpointListener implements HttpRequestListener {
		private Map<String, String> actionToChannelMap = Collections.synchronizedMap(new HashMap<String, String>());
		String endpointKey;
		String url;
		int port;
		public SoapEndpointListener(String endpointKey, String url, int port, String wsdlFileName) throws MactorException {
			this.endpointKey = endpointKey;
			this.port = port;
			this.url = url;
			HttpServerManager.getHttpServer(port).addRequestListener(url, this);
			if (wsdlFileName != null) {
				File f = new File(ProjectContext.getGlobalInstance().getProjectConfigDir().getAbsolutePath() + "/" + wsdlFileName);
				if (f.exists()) {
					WsdlProvider wsdlP = new WsdlProvider(f);
					HttpServerManager.getHttpServer(port).addRequestListener(url + "?wsdl", wsdlP);
					HttpServerManager.getHttpServer(port).addRequestListener(url + "?wsdl=", wsdlP);
				}
			}
		}
		public void terminate() {
			log.info("Releasing endpoint '" + url + "'");
			removeListener(port, url);
			removeListener(port, url + "?wsdl");
			removeListener(port, url + "?wsdl=");
		}
		private void removeListener(int port, String url) {
			try {
				HttpServerManager.getHttpServer(port).removeRequestListener(url);
			} catch (MactorException me) {
				log.warn("Failed to remove HTTP listener on port '" + port + "'. Error:" + me.getMessage(), me);
			}
		}
		public int getActionBindingCount() {
			return actionToChannelMap.size();
		}
		public void removeActionBinding(String action) {
			actionToChannelMap.remove(action.toLowerCase());
		}
		public void addActionBinding(String action, String channel) {
			actionToChannelMap.put(action.toLowerCase(), channel);
		}
		public HttpResponse onRequest(HttpRequest request) throws Exception {
			Message m = Message.createMessage(request.getData());
			String action = trimAction(request.getHeader("soapaction"));
			String channel = actionToChannelMap.get(action);
			if (channel == null) {
				log.info("No listeneres registered for action '" + action + "'");
				return null;
			}
			Message resultMessage = raiseOnMessage(channel, m, false);
			if (resultMessage != null) {
				HttpResponse res = new HttpResponse();
				res.setData(resultMessage.getContentDocument());
				res.addHeader("Content-Type", " text/xml; charset=" + Charset.defaultCharset().name());
				return res;
			}
			return null;
		}
		private String trimAction(String action) {
			if (action == null || action.length() == 0)
				return action;
			if (action.startsWith("\"") || action.startsWith("'"))
				action = action.substring(1);
			if (action.endsWith("\"") || action.endsWith("'"))
				action = action.substring(0, action.length() - 1);
			return action.toLowerCase();
		}
	}
	private Message sendSoapMessage(String soapEndpoint, String soapAction, String username, String password, Message soapEnvelopeMessage) throws MactorException {
		try {
			URL url = new URL(soapEndpoint);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			OutputStreamWriter w = new OutputStreamWriter(bos);
			soapEnvelopeMessage.getContentDocument().write(w);
			w.flush();
			byte[] contentBuffer = bos.toByteArray();
			conn.setRequestProperty("Content-Length", contentBuffer.length + "");
			conn.setRequestProperty("Content-Type", " text/xml; charset=" + Charset.defaultCharset().name());
			conn.setRequestProperty("SOAPAction", soapAction);
			if (username != null && username.length() != 0)
				conn.setRequestProperty("Authorization", "Basic " + new sun.misc.BASE64Encoder().encode((username + ":" + password).getBytes()));
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			OutputStream out = conn.getOutputStream();
			out.write(contentBuffer);
			out.flush();
			out.close();
			int rc = conn.getResponseCode();
			if (rc != 200)
				throw new MactorException("Server rejected the soap message. Endpoint'" + soapEndpoint + " '. Action '" + soapAction + "' HTTP response code: " + rc);
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			Message response = Message.createMessage(in);
			in.close();
			return response;
		} catch (IOException ioe) {
			// TODO more specific error description
			throw new MactorException("Failed to send soap message " + ioe.getMessage(), ioe);
		}
	}
}
