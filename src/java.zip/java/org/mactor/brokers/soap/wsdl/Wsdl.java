/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.soap.wsdl;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.wsdl.Binding;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Definition;
import javax.wsdl.Input;
import javax.wsdl.Message;
import javax.wsdl.Operation;
import javax.wsdl.Output;
import javax.wsdl.Port;
import javax.wsdl.Service;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.soap.SOAPAddress;
import javax.wsdl.extensions.soap.SOAPBinding;
import javax.wsdl.extensions.soap.SOAPBody;
import javax.wsdl.extensions.soap.SOAPOperation;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLReader;
import javax.xml.namespace.QName;

import org.xml.sax.InputSource;

// This code is based on example provided by Jim Winfield at
// http://www2.sys-con.com/ITSG/virtualcd/WebServices/archives/0310/behera/index.htm
public class Wsdl {
	/** The default SOAP encoding to use. */
	public final static String DEFAULT_SOAP_ENCODING_STYLE = "http://schemas.xmlsoap.org/soap/encoding/";
	List<OperationInfo> operations;
	Definition def;
	public Wsdl(URL url) throws Exception {
		this(new InputSource(url.openStream()));
	}
	public Wsdl(File file) throws Exception {
		this(new InputSource(new FileInputStream(file)));
	}
	private Wsdl(InputSource is) throws Exception {
		WSDLReader reader = WSDLFactory.newInstance().newWSDLReader();
		def = reader.readWSDL(null, is);
		this.operations = getOperations(def);
	}
	private List<OperationInfo> getOperations(Definition def) {
		List<OperationInfo> operations = new LinkedList<OperationInfo>();
		Map services = def.getServices();
		if (services != null) {
			Iterator it = services.values().iterator();
			for (int i = 0; it.hasNext(); i++) {
				Service service = (Service) it.next();
				QName qName = service.getQName();
				String namespace = qName.getNamespaceURI();
				Map ports = service.getPorts();
				Iterator portIter = ports.values().iterator();
				while (portIter.hasNext()) {
					Port port = (Port) portIter.next();
					Binding binding = port.getBinding();
					Iterator operIter = getOperations(binding).iterator();
					while (operIter.hasNext()) {
						OperationInfo operation = (OperationInfo) operIter.next();
						operation.setNamespaceURI(namespace);
						operation.setPort(port.getName());
						operation.setService(service.getQName().getLocalPart());
						ExtensibilityElement addrElem = findExtensibilityElement(port.getExtensibilityElements(), "address");
						if (addrElem != null && addrElem instanceof SOAPAddress) {
							SOAPAddress soapAddr = (SOAPAddress) addrElem;
							operation.setTargetURL(soapAddr.getLocationURI());
						}
						operations.add(operation);
					}
				}
			}
		}
		return operations;
	}
	private List getOperations(Binding binding) {
		List operationInfos = new ArrayList();
		List operations = binding.getBindingOperations();
		if (operations != null && !operations.isEmpty()) {
			ExtensibilityElement soapBindingElem = findExtensibilityElement(binding.getExtensibilityElements(), "binding");
			String style = "document"; // default
			if (soapBindingElem != null && soapBindingElem instanceof SOAPBinding) {
				SOAPBinding soapBinding = (SOAPBinding) soapBindingElem;
				style = soapBinding.getStyle();
			}
			Iterator opIter = operations.iterator();
			int i = 0;
			while (opIter.hasNext()) {
				BindingOperation oper = (BindingOperation) opIter.next();
				ExtensibilityElement operElem = findExtensibilityElement(oper.getExtensibilityElements(), "operation");
				if (operElem != null && operElem instanceof SOAPOperation) {
					OperationInfo operationInfo = new OperationInfo(style);
					buildOperation(operationInfo, oper);
					// Add to the return list
					operationInfos.add(operationInfo);
				}
			}
		}
		return operationInfos;
	}
	private OperationInfo buildOperation(OperationInfo operationInfo, BindingOperation bindingOper) {
		Operation oper = bindingOper.getOperation();
		operationInfo.setTargetMethodName(oper.getName());
		ExtensibilityElement operElem = findExtensibilityElement(bindingOper.getExtensibilityElements(), "operation");
		if (operElem != null && operElem instanceof SOAPOperation) {
			SOAPOperation soapOperation = (SOAPOperation) operElem;
			operationInfo.setSoapActionURI(soapOperation.getSoapActionURI());
		}
		BindingInput bindingInput = bindingOper.getBindingInput();
		BindingOutput bindingOutput = bindingOper.getBindingOutput();
		ExtensibilityElement bodyElem = findExtensibilityElement(bindingInput.getExtensibilityElements(), "body");
		if (bodyElem != null && bodyElem instanceof SOAPBody) {
			SOAPBody soapBody = (SOAPBody) bodyElem;
			List styles = soapBody.getEncodingStyles();
			String encodingStyle = null;
			if (styles != null) {
				encodingStyle = styles.get(0).toString();
			}
			if (encodingStyle == null) {
				encodingStyle = DEFAULT_SOAP_ENCODING_STYLE;
			}
			operationInfo.setEncodingStyle(encodingStyle.toString());
			operationInfo.setTargetObjectURI(soapBody.getNamespaceURI());
		}
		Input inDef = oper.getInput();
		if (inDef != null) {
			Message inMsg = inDef.getMessage();
			if (inMsg != null) {
				operationInfo.setInputMessageName(inMsg.getQName().getLocalPart());
				// Set the body of the operation's input message
				// TODO:operationInfo.setInputMessageText(buildMessageText(operationInfo,
				// inMsg));
			}
		}
		Output outDef = oper.getOutput();
		if (outDef != null) {
			Message outMsg = outDef.getMessage();
			if (outMsg != null) {
				operationInfo.setOutputMessageName(outMsg.getQName().getLocalPart());
				// Set the body of the operation's output message
				// TODO:operationInfo.setOutputMessageText(buildMessageText(operationInfo,
				// outMsg));
			}
		}
		return operationInfo;
	}
	private ExtensibilityElement findExtensibilityElement(List extensibilityElements, String elementType) {
		if (extensibilityElements != null) {
			Iterator iter = extensibilityElements.iterator();
			while (iter.hasNext()) {
				ExtensibilityElement element = (ExtensibilityElement) iter.next();
				if (element.getElementType().getLocalPart().equalsIgnoreCase(elementType)) {
					return element;
				}
			}
		}
		return null;
	}
	public static class OperationInfo {
		private String operationType = "";
		private String encodingStyle = "";
		private String targetURL = "";
		private String namespaceURI = "";
		private String targetObjectURI = "";
		private String targetMethodName = "";
		private String inputMessageText = "";
		private String outputMessageText = "";
		private String inputMessageName = "";
		private String outputMessageName = "";
		private String soapActionURI = "";
		private String style = "document";
		private String port;
		private String service;
		public OperationInfo(String style) {
			super();
			setStyle(style);
		}
		public void setEncodingStyle(String value) {
			encodingStyle = value;
		}
		public String getEncodingStyle() {
			return encodingStyle;
		}
		public void setTargetURL(String value) {
			targetURL = value;
		}
		public String getTargetURL() {
			return targetURL;
		}
		public void setNamespaceURI(String value) {
			namespaceURI = value;
		}
		public String getNamespaceURI() {
			return namespaceURI;
		}
		public void setTargetObjectURI(String value) {
			targetObjectURI = value;
		}
		public String getTargetObjectURI() {
			return targetObjectURI;
		}
		public void setTargetMethodName(String value) {
			targetMethodName = value;
		}
		public String getTargetMethodName() {
			return targetMethodName;
		}
		public void setInputMessageName(String value) {
			inputMessageName = value;
		}
		public String getInputMessageName() {
			return inputMessageName;
		}
		public void setOutputMessageName(String value) {
			outputMessageName = value;
		}
		public String getOutputMessageName() {
			return outputMessageName;
		}
		public void setInputMessageText(String value) {
			inputMessageText = value;
		}
		public String getInputMessageText() {
			return inputMessageText;
		}
		public void setOutputMessageText(String value) {
			outputMessageText = value;
		}
		public String getOutputMessageText() {
			return outputMessageText;
		}
		public void setSoapActionURI(String value) {
			soapActionURI = value;
		}
		public String getSoapActionURI() {
			return soapActionURI;
		}
		public void setStyle(String value) {
			style = value;
		}
		public String getStyle() {
			return style;
		}
		public String toString() {
			return getTargetMethodName();
		}
		public String getOperationType() {
			return operationType;
		}
		public void setOperationType(String operationType) {
			this.operationType = operationType;
		}
		public String getPort() {
			return port;
		}
		public void setPort(String port) {
			this.port = port;
		}
		public String getService() {
			return service;
		}
		public void setService(String service) {
			this.service = service;
		}
	}
	public List<OperationInfo> getOperations() {
		return operations;
	}
}
