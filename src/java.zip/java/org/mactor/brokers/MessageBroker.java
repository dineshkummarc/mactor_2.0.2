/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers;

import org.mactor.framework.MactorException;
import org.mactor.framework.extensioninterface.MessageSelectorCommand;

/**
 * Defines the message broker interface
 * <p>
 * Message broker implementations is not requiered to implement both publish and
 * subscribe (UnsupportedOperationException should be thrown by methods not
 * implemented by the message broker)
 * </p>
 * <p>
 * Message broker implementations must have contructor that takes a
 * 
 * <pre>
 * MessageBrokerConfig
 * </pre>
 * 
 * as the single parameter
 * </p>
 * 
 * <p>
 * The simplest way to implement a message broker is to extend the
 * AbstractMessageBroker class, or the PollingMessageBrokerTemplate if the
 * protocol is polling based (i.e. the case for FilesMessageBroker)
 * </p>
 * 
 * @author Lars Ivar Almli
 */
public interface MessageBroker {
	/**
	 * Subscibe to message from a channel
	 * 
	 * @param channel
	 *            the channel
	 * @param subscriber
	 *            the subscriber that will receive the messages
	 * @param messageSelector
	 *            the message selector restricts which messages to receive from
	 *            the channel
	 * @throws MactorException
	 *             if some problem occures (this will cause the test to fail)
	 */
	void subscribe(String channel, MessageSubscriber subscriber, MessageSelectorCommand messageSelector) throws MactorException;
	/**
	 * Unsubscribe
	 * 
	 * @param channel
	 *            the channel
	 * @param subscriber
	 *            the subscriber
	 * @throws MactorException
	 *             if some problem occures
	 */
	void unsubscribe(String channel, MessageSubscriber subscriber) throws MactorException;
	/**
	 * Publish a message to a channel
	 * 
	 * @param channel
	 *            the channel
	 * @param message
	 *            the message
	 * @throws MactorException
	 *             if some problem occures (this will cause the test to fail)
	 */
	void publish(String channel, Message message) throws MactorException;
	/**
	 * Publish a message and expect a reponse (when dealing with synchrounous
	 * protcols)
	 * 
	 * @param channel
	 *            the channel
	 * @param message
	 *            the message
	 * @return the response message
	 * @throws MactorException
	 *             if some problem occures (this will cause the test to fail)
	 */
	Message publishWithResponse(String channel, Message message) throws MactorException;
	void terminate();
}
