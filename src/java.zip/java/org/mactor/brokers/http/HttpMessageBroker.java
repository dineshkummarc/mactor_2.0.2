/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.http;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import org.mactor.brokers.AbstractMessageBroker;
import org.mactor.brokers.Message;
import org.mactor.brokers.MessageBroker;
import org.mactor.framework.ConfigException;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;

/**
 * A simple message broker that supports posting/receinving XML messages over
 * HTTP (optionally with a response)
 * 
 * </p>
 * 
 * @author Lars Ivar Almli
 * @see MessageBroker
 */
public class HttpMessageBroker extends AbstractMessageBroker {
	public HttpMessageBroker(MessageBrokerConfig config) {
		super(config);
	}
	public void publish(String channel, Message message) throws MactorException {
		ChannelConfig cc = config.getRequieredChannelConfig(channel);
		sendMessage(cc.getRequieredValue("URL"), cc.getRequieredValue("Method"), message, false, cc.getValue("Username"), cc.getValue("Password"));
	}
	public Message publishWithResponse(String channel, Message message) throws MactorException {
		ChannelConfig cc = config.getRequieredChannelConfig(channel);
		return sendMessage(cc.getRequieredValue("URL"), cc.getRequieredValue("Method"), message, true, cc.getValue("Username"), cc.getValue("Password"));
	}
	@Override
	protected void onFirstSubscribe(String channel) throws MactorException {
		registerListener(channel);
	}
	@Override
	protected void onLastSubscribe(String channel) throws MactorException {
		UrlListener l = listeners.remove(channel);
		if (l != null)
			l.close();
	}
	Map<String, UrlListener> listeners = new HashMap<String, UrlListener>();
	private synchronized void registerListener(String channel) throws MactorException {
		UrlListener listener = new UrlListener(config.getRequieredChannelConfig(channel));
		listeners.put(channel, listener);
	}
	private class UrlListener implements HttpRequestListener {
		private String channel;
		private String realUrl;
		private int port;
		public UrlListener(ChannelConfig cc) throws MactorException {
			this.channel = cc.getName();
			String endpoint = cc.getRequieredValue("URL");
			try {
				URL url = new URL(endpoint);
				port = url.getDefaultPort();
				if (url.getPort() > 0)
					port = url.getPort();
				realUrl = url.getPath().toLowerCase();
				HttpServerManager.getHttpServer(port).addRequestListener(realUrl, this);
			} catch (MalformedURLException e) {
				throw new ConfigException(e);
			}
		}
		public void close() {
			try {
				System.out.println("removing:" + realUrl);
				HttpServerManager.getHttpServer(port).removeRequestListener(realUrl);
			} catch (MactorException me) {
				log.warn("Failed to remove HTTP listener on port '" + port + "'. Error:" + me.getMessage(), me);
			}
		}
		public HttpResponse onRequest(HttpRequest request) throws Exception {
			Message m = Message.createMessage(request.getData());
			Message result = raiseOnMessage(channel, m, false);
			if (result != null) {
				HttpResponse res = new HttpResponse();
				res.setData(result.getContentDocument());
				res.addHeader("Content-type", " text/xml; charset=" + Charset.defaultCharset().name());
				return res;
			} else {
				HttpResponse res = new HttpResponse();
				res.addHeader("Content-type", " text/plain; charset=" + Charset.defaultCharset().name());
				res.setData("");
				return res;
			}
		}
	}
	public Message sendMessage(String endPoint, String method, Message message, boolean expectResponse, String username, String password) throws MactorException {
		return HttpClient.sendMessage(endPoint, method, message, expectResponse, username, password);
	}
}
