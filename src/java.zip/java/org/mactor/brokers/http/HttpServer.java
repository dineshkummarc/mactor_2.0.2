/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.http;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.mactor.framework.MactorException;

/**
 * Simple HTTP server
 * 
 * @author Lars Ivar Almli
 */
public class HttpServer {
	protected static Logger log = Logger.getLogger(HttpServer.class);
	public HttpServer(int port) throws MactorException {
		Thread httpServer = new Thread(new HttpServerRunner(port));
		httpServer.start();
	}
	private class HttpServerRunner implements Runnable {
		ServerSocket ss;
		int port;
		public HttpServerRunner(int port) throws MactorException {
			this.port = port;
			try {
				this.ss = new ServerSocket(port);
			} catch (IOException ioe) {
				throw new MactorException("Failed to bind a HTTP listner on port '" + port + "'. Error: " + ioe.getMessage(), ioe);
			}
		}
		public void run() {
			try {
				while (!ss.isClosed()) {
					try {
						Socket client = ss.accept();
						new RequestWorker(client).start();
					} catch (IOException ioe) {
						log.warn("Exception while accepting client HTTP connection at port '" + port + "'. Error: " + ioe.getMessage(), ioe);
					}
				}
			} finally {
				if (ss != null && !ss.isClosed()) {
					try {
						ss.close();
					} catch (IOException ioe) {
						log.warn("Exception while closing HTTP server at port '" + port + "'. Error: " + ioe.getMessage(), ioe);
					}
				}
			}
		}
	}
	private class RequestWorker {
		Socket client;
		RequestWorker(Socket client) {
			this.client = client;
		}
		public void start() {
			new Thread() {
				@Override
				public void run() {
					handleRequest(client);
				}
			}.start();
		}
		boolean patientMode = true;
		private HttpRequestListener getListenerForUrl(String url) throws InterruptedException {
			HttpRequestListener listener = listeners.get(url);
			if (listener == null && patientMode) { // "buffering" to handle the
				// frequent
				// sub/unsub when running mock tests
				if (recentPatterns.contains(url)) {
					for (int i = 0; i < 20 && listener == null; i++) {
						Thread.sleep(200);
						listener = listeners.get(url);
					}
				}
			}
			return listener;
		}
		private void handleRequest(Socket client) {
			try {
				if (log.isDebugEnabled()) {
					log.debug("Handling request from " + client.getInetAddress());
				}
				HttpRequest req = new HttpRequest(client.getInputStream());
				String url = req.getRequestedUrl().toLowerCase();
				HttpRequestListener listener = getListenerForUrl(url);
				if (listener == null) {
					log.info("No listener for requested url '" + req.getRequestedUrl().toLowerCase());
					sendErrorResponse(client, "404");
				} else {
					try {
						HttpResponse res = listener.onRequest(req);
						if (res == null && patientMode) {
							for (int i = 0; i < 20 && res == null; i++) {
								Thread.sleep(200);
								res = listener.onRequest(req);
							}
						}
						if (res != null)
							sendSuccessResponse(client, res);
						else {
							log.info("No response produced for requested url '" + req.getRequestedUrl().toLowerCase());
							sendErrorResponse(client, "204");// No content
						}
					} catch (Exception e) {
						e.printStackTrace();
						sendErrorResponse(client, "500");
					}
				}
				client.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	private void sendErrorResponse(Socket client, String code) throws IOException {
		PrintWriter out = new PrintWriter(client.getOutputStream());
		out.println("HTTP/1.0 " + code);
		out.println("Content-Type: text/plain");
		out.println();
		out.flush();
		out.close();
	}
	private void sendSuccessResponse(Socket client, HttpResponse response) throws IOException {
		OutputStream stream = client.getOutputStream();
		PrintWriter out = new PrintWriter(stream);
		out.println("HTTP/1.0 200");
		for (Entry<String, String> e : response.getHeaders().entrySet()) {
			out.println(e.getKey() + ": " + e.getValue().trim());
		}
		out.println();
		out.flush();
		if (response.getData() != null) {
			stream.write(response.getData());
			stream.flush();
		}
		stream.close();
	}
	Set<String> recentPatterns = new HashSet<String>();
	Map<String, HttpRequestListener> listeners = new HashMap<String, HttpRequestListener>();
	public synchronized void addRequestListener(String url, HttpRequestListener listener) {
		url = url.toLowerCase();
		log.info("adding listener for:'" + url + "'");
		if (listeners.containsKey(url))
			throw new RuntimeException("Listener for url '" + url + "' already registered");
		listeners.put(url, listener);
		recentPatterns.add(url);
	}
	public synchronized void removeRequestListener(String url) {
		listeners.remove(url);
	}
}
