/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.http;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * Represents a HTTP Request
 * 
 * @author Lars Ivar Almli
 */
public class HttpRequest {
	protected static Logger log = Logger.getLogger(HttpRequest.class);
	String method;
	String requestedUrl;
	String data;
	Map<String, String> headers = new HashMap<String, String>();
	public HttpRequest(InputStream is) throws IOException {
		PushbackInputStream pis = new PushbackInputStream(is);
		String first = readLine(pis);
		String[] parts = first.split(" ");
		this.method = parts[0];
		this.requestedUrl = parts[1];
		while (true) {
			String header = readLine(pis);
			if (header == null || header.trim().length() == 0)
				break;
			int sep = header.indexOf(':');
			if (sep >= 0 && sep + 1 < header.length()) {
				this.headers.put(header.substring(0, sep).toLowerCase().trim(), header.substring(sep + 1, header.length()).toLowerCase().trim());
			}
		}
		if (log.isDebugEnabled())
			log.debug("Received request on url: '" + requestedUrl + "'. Headers:" + this.headers);
		if ("POST".equalsIgnoreCase(method)) {
			String str = headers.get("content-length");
			int len = 0;
			if (str == null)
				throw new IOException("Invalid request. Content-Length not specified in POST");
			try {
				len = Integer.parseInt(str.trim());
			} catch (NumberFormatException nof) {
				throw new IOException("Invalid request. Unparseable Content-Length header in POST");
			}
			if (log.isDebugEnabled()) {
				log.debug("Expecting content of length:" + len);
			}
			data = readContent(pis, len);
		}
		if (log.isDebugEnabled())
			log.debug("Content:" + data);
	}
	private String readLine(PushbackInputStream pis) throws IOException {
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		byte[] buffer = new byte[1];
		while (pis.read(buffer) >= 0) {
			if (isNewLine(buffer[0])) {
				if (pis.read(buffer) >= 0) {
					if (!isNewLine(buffer[0])) {
						pis.unread(buffer);
					}
				}
				break;
			}
			bao.write(buffer);
		}
		return bao.toString();
	}
	private String readContent(InputStream is, int len) throws IOException {
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		int tot = 0;
		byte[] buffer = new byte[len];
		while (true) {
			int read = is.read(buffer);
			if (read <= 0)
				break;
			bao.write(buffer, 0, read);
			tot = tot + read;
			if (tot >= len)
				break;
		}
		return bao.toString();
	}
	boolean isNewLine(byte c) {
		return c == '\n' || c == '\r';
	}
	public String getData() {
		return data;
	}
	public String getHeader(String headerName) {
		return headers.get(headerName);
	}
	public Map<String, String> getHeaders() {
		return headers;
	}
	public String getMethod() {
		return method;
	}
	public String getRequestedUrl() {
		return requestedUrl;
	}
}
