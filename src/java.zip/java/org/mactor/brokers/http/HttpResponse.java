/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.http;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;

import org.dom4j.Document;

/**
 * Represents a HTTP Reponse
 * 
 * @author Lars Ivar Almli
 */
public class HttpResponse {
	byte[] data;
	Map<String, String> headers = new HashMap<String, String>();
	public String getHeader(String headerName) {
		return headers.get(headerName);
	}
	public void addHeader(String name, String value) {
		headers.put(name, value);
	}
	public void setData(String data) throws IOException {
		if (data == null)
			data = "";
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		OutputStreamWriter w = new OutputStreamWriter(bos);
		w.write(data);
		w.flush();
		setData(bos.toByteArray());
	}
	public void setData(Document doc) throws IOException {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		OutputStreamWriter w = new OutputStreamWriter(bos);
		doc.write(w);
		w.flush();
		setData(bos.toByteArray());
	}
	public void setData(byte[] data) {
		this.data = data;
		headers.put("Content-Length", this.data.length + "");
	}
	public Map<String, String> getHeaders() {
		return headers;
	}
	public byte[] getData() {
		return data;
	}
}
