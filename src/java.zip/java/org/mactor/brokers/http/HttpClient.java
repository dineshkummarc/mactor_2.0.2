/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.http;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

import org.mactor.brokers.Message;
import org.mactor.framework.MactorException;

public class HttpClient {
	public static final Message sendMessage(String endPoint, String method, Message message, boolean expectResponse, String username, String password) throws MactorException {
		try {
			URL url = new URL(endPoint);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			OutputStreamWriter w = new OutputStreamWriter(bos);
			message.getContentDocument().write(w);
			w.flush();
			byte[] contentBuffer = bos.toByteArray();
			conn.setRequestProperty("Content-Length", contentBuffer.length + "");
			conn.setRequestProperty("Content-Type", " text/xml; charset=" + Charset.defaultCharset().name());
			if (username != null && username.length() != 0)
				conn.setRequestProperty("Authorization", "Basic " + new sun.misc.BASE64Encoder().encode((username + ":" + password).getBytes()));
			conn.setRequestMethod(method);
			conn.setDoOutput(true);
			conn.setDoInput(true);
			OutputStream out = conn.getOutputStream();
			out.write(contentBuffer);
			out.flush();
			out.close();
			int rc = conn.getResponseCode();
			if (rc < 200 || rc > 299)
				throw new MactorException("Server rejected the message. URL '" + endPoint + " '. Method '" + method + "' HTTP response code: " + rc);
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			if (expectResponse) {
				Message response = Message.createMessage(in);
				in.close();
				return response;
			} else {
				in.close();
				return null;
			}
		} catch (Exception me) {
			// TODO more specific error description
			throw new MactorException("Failed to send HTTP message " + me.getMessage(), me);
		}
	}
}
