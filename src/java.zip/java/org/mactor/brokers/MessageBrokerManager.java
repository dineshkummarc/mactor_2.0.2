/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers;

import java.io.File;
import java.io.FileFilter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import org.apache.log4j.Logger;
import org.mactor.framework.MactorException;
import org.mactor.framework.extensioninterface.MessageSelectorCommand;
import org.mactor.framework.spec.MessageBrokersConfig;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;

/**
 * Singleton that loads and maintains all message brokers. And works as a facade
 * to the message brokers (hiding the broker-channel association).
 * 
 * @author Lars Ivar Almli
 */
public class MessageBrokerManager {
	protected static Logger log = Logger.getLogger(MessageBrokerManager.class);
	private static MessageBrokerManager manager;
	private boolean active;
	private Map<String, MessageBrokerHolder> channelToBrokerMap = new HashMap<String, MessageBrokerHolder>();
	public static synchronized MessageBrokerManager getInstance() throws MactorException {
		if (manager != null)
			return manager;
		manager = new MessageBrokerManager(ProjectContext.getGlobalInstance().loadMessageBrokersConfig());
		return manager;
	}
	public static boolean isActive() {
		return manager != null;
	}
	public void terminate() {
		manager = null;
		for (MessageBrokerHolder mh : channelToBrokerMap.values()) {
			try {
				mh.broker.terminate();
			} catch (Exception e) {
				log.warn("Failed to terminate message broker '" + mh.config.getName() + "'", e);
			}
		}
		channelToBrokerMap.clear();
	}
	private MessageBrokerManager(MessageBrokersConfig config) throws MactorException {
		if (config == null)
			throw new MactorException("A Message Broker Configuration must be provided (select one in Project Settings...)");
		for (MessageBrokerConfig mbc : config.getMessageBrokers()) {
			MessageBroker broker = createMessageBroker(mbc);
			boolean archiveMessages = mbc.isArchiveConsumedMessages() && mbc.getArchivePath() != null && mbc.getArchivePath().length() > 0;
			addBroker(mbc, new MessageBrokerDecorator(archiveMessages, mbc.getArchivePath(), broker));
		}
	}
	private synchronized void addBroker(MessageBrokerConfig mbc, MessageBrokerDecorator broker) throws MactorException {
		for (ChannelConfig cc : mbc.getChannels().values()) {
			if (channelToBrokerMap.containsKey(cc.getName()))
				throw new MactorException("Duplicate channel definition. Channel '" + cc.getName() + "' is defined in both '" + mbc.getName() + "' and '"
						+ channelToBrokerMap.get(cc.getName()).config.getName() + "'");
			channelToBrokerMap.put(cc.getName(), new MessageBrokerHolder(broker, mbc));
		}
	}
	private MessageBrokerHolder getBrokerHolder(String channel) throws MactorException {
		MessageBrokerHolder brokerHolder = channelToBrokerMap.get(channel);
		if (brokerHolder == null)
			throw new MactorException("No MessageBroker is registered for channel '" + channel + "'");
		return brokerHolder;
	}
	private MessageBrokerDecorator getBroker(String channel) throws MactorException {
		return getBrokerHolder(channel).broker;
	}
	public void addMessageInfoListener(MessageInfoListener listener) throws MactorException {
		for (String channel : channelToBrokerMap.keySet())
			getBroker(channel).addMessageInfoListener(channel, listener);
	}
	public void addMessageInfoListener(String channel, MessageInfoListener listener) throws MactorException {
		getBroker(channel).addMessageInfoListener(channel, listener);
	}
	public void removeMessageInfoListener(String channel, MessageInfoListener listener) throws MactorException {
		getBroker(channel).removeMessageInfoListener(channel, listener);
	}
	public Message publish(String channel, Message message) throws MactorException {
		MessageBrokerHolder h = getBrokerHolder(channel);
		ChannelConfig cc = h.config.getChannelConfig(channel);
		if (cc.isRequiresResponse())
			return getBroker(channel).publishWithResponse(channel, message);
		getBroker(channel).publish(channel, message);
		return null;
	}
	public void subscribe(String channel, MessageSubscriber subscriber, MessageSelectorCommand messageSelector) throws MactorException {
		getBroker(channel).subscribe(channel, subscriber, messageSelector);
	}
	public void unsubscribe(String channel, MessageSubscriber subscriber) throws MactorException {
		getBroker(channel).unsubscribe(channel, subscriber);
	}
	public ArrayList<MessageInfo> loadMessageInfoFromArchive(String channel) throws MactorException {
		MessageBrokerDecorator mb = getBroker(channel);
		String path = mb.getArchivePath();
		if (path == null) {
			throw new MactorException("No archive path is specifed for the message broker that contains the channel '" + channel + "'");
		}
		return MessageInfo.loadFromArchiveDir(new File(path + "/" + channel));
	}
	public void clearArchive(String channel) throws MactorException {
		MessageBrokerDecorator mb = getBroker(channel);
		String path = mb.getArchivePath();
		if (path == null) {
			throw new MactorException("No archive path is specifed for the message broker that contains the channel '" + channel + "'");
		}
		MessageInfo.clearArchiveDir(new File(path + "/" + channel));
	}
	private class MessageBrokerHolder {
		MessageBrokerDecorator broker;
		MessageBrokerConfig config;
		public MessageBrokerHolder(MessageBrokerDecorator broker, MessageBrokerConfig config) {
			this.broker = broker;
			this.config = config;
		}
	}
	private static MessageBroker createMessageBroker(MessageBrokerConfig config) throws MactorException {
		String className = config.getBrokerClass();
		try {
			Class c = Class.forName(className);
			Constructor ct = c.getConstructor(new Class[] { MessageBrokerConfig.class });
			Object mb = ct.newInstance(new Object[] { config });
			if (!(mb instanceof MessageBroker))
				throw new MactorException("The specified message broker class does not implement '" + MessageBroker.class.getName() + "'");
			return (MessageBroker) mb;
		} catch (ClassNotFoundException cnf) {
			throw new MactorException("The specified MessageBroker implementation was not found in the classpath. Class '" + className + "'", cnf);
		} catch (NoSuchMethodException nm) {
			throw new MactorException("The specified MessageBroker implementation class '" + className + "' does not have the requiered contructor (that takes a single argument of type '"
					+ MessageBrokerConfig.class.getName() + "')", nm);
		} catch (IllegalAccessException iae) {
			throw new MactorException("Unable to instantiate the MessageBroker '" + className + "'. Illegal access", iae);
		} catch (InvocationTargetException it) {
			throw new MactorException("Unable to instantiate the MessageBroker '" + className + "'. InvocationTargetException", it);
		} catch (InstantiationException ie) {
			throw new MactorException("Unable to instantiate the MessageBroker '" + className + "'. InstantiationException", ie);
		}
	}
	public static interface MessageInfoListener {
		void onMessageInfo(MessageInfo messageInfo);
	}
	private static class AF implements FileFilter {
		public boolean accept(File pathname) {
			String n = pathname.getName();
			return pathname.isFile() && n.endsWith(".xml") && (n.startsWith("out_") || n.startsWith("in_"));
		}
	}
	public static class MessageInfo implements Comparable<MessageInfo> {
		private String archivePath;
		private String channel;
		private Calendar createdTime;
		private boolean incoming;
		private boolean response;
		public int compareTo(org.mactor.brokers.MessageBrokerManager.MessageInfo other) {
			return createdTime.compareTo(other.createdTime);
		}
		public static MessageInfo create(MessageContextInfo mci) {
			MessageInfo mi = new MessageInfo();
			mi.archivePath = mci.getArchivePath();
			mi.channel = mci.getChannel();
			mi.createdTime = mci.getCreatedTime();
			mi.incoming = mci.isIncoming();
			mi.response = mci.isResponseMessage();
			return mi;
		}
		public static ArrayList<MessageInfo> loadFromArchiveDir(File channelArchiveDir) {
			if (channelArchiveDir == null || !channelArchiveDir.exists())
				return new ArrayList<MessageInfo>();
			LinkedList<MessageInfo> mis = new LinkedList<MessageInfo>();
			File[] files = channelArchiveDir.listFiles(new AF());
			if (files != null) {
				for (File f : files) {
					MessageInfo m = MessageInfo.createFromFileInfo(f);
					if (m != null)
						mis.add(m);
				}
			}
			Collections.sort(mis);
			return new ArrayList<MessageInfo>(mis);
		}
		public static void clearArchiveDir(File channelArchiveDir) {
			if (channelArchiveDir == null || !channelArchiveDir.exists())
				return;
			File[] files = channelArchiveDir.listFiles(new AF());
			if (files != null) {
				for (File f : files) {
					f.delete();
				}
			}
		}
		public static MessageInfo createFromFileInfo(File f) {
			if (!f.exists())
				return null;
			MessageInfo mi = new MessageInfo();
			mi.createdTime = Calendar.getInstance();
			mi.createdTime.setTimeInMillis(f.lastModified());
			String fn = f.getName();
			mi.response = fn.endsWith("_resp.xml");
			mi.incoming = fn.startsWith("in_");
			mi.channel = f.getParent();
			mi.archivePath = f.getAbsolutePath();
			return mi;
		}
		public String getArchivePath() {
			return archivePath;
		}
		public String getChannel() {
			return channel;
		}
		public Calendar getCreatedTime() {
			return createdTime;
		}
		public boolean isIncoming() {
			return incoming;
		}
		public boolean isResponse() {
			return response;
		}
	}
}
