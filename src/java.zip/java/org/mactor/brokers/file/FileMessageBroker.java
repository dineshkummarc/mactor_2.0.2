/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers.file;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.mactor.brokers.Message;
import org.mactor.brokers.MessageBroker;
import org.mactor.brokers.PollingMessageBrokerTemplate;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;

/**
 * A message broker for communicating via file shares.
 * 
 * </p>
 * 
 * @author Lars Ivar Almli
 * @see MessageBroker
 */
public class FileMessageBroker extends PollingMessageBrokerTemplate {
	private MessageBrokerConfig config;
	private final boolean postActionDelete;
	public FileMessageBroker(MessageBrokerConfig config) throws MactorException {
		super(config);
		this.config = config;
		this.postActionDelete = "DELETE".equalsIgnoreCase(config.getValue("PostAction"));
	}
	@Override
	protected synchronized List<Message> doGetMessages(String channel, int maxMessageCount) throws MactorException {
		ChannelConfig cf = config.getRequieredChannelConfig(channel);
		String filterPattern = cf.getValue("filter_patter", ".xml");
		File dir = new File(getDir(cf));
		List<File> candidates = new LinkedList<File>();
		for (File f : dir.listFiles()) {
			if (f.isFile() && f.getName().endsWith(filterPattern)) {
				File target = new File(f.getAbsolutePath() + "_seen");
				if (f.renameTo(target))
					candidates.add(target);
				else
					log.error("Failed to parse message received on channel '" + channel + "' to '" + target.getAbsolutePath() + "'");
			}
			if (candidates.size() >= maxMessageCount)
				break;
		}
		List<Message> messages = new LinkedList<Message>();
		for (File file : candidates) {
			try {
				messages.add(Message.createMessage(file));
				if (postActionDelete)
					if (!file.delete())
						log.error("Failed to delete file '" + file.getAbsolutePath() + "' received on channel '" + channel + "'");
			} catch (MactorException me) {
				log.error("Failed to parse message received on channel '" + channel + "'", me);
			}
		}
		return messages;
	}
	@Override
	protected synchronized void doPublishMessage(String channel, Message message) throws MactorException {
		ChannelConfig cf = config.getRequieredChannelConfig(channel);
		String dir = getDir(cf);
		String fn = dir + getNext() + cf.getValue("suffix", ".xml") + "__";
		try {
			File f = new File(fn);
			FileWriter fw = new FileWriter(fn);
			fw.write(message.getContent() + "");
			fw.close();
			f.renameTo(new File(fn.substring(0, fn.length() - 2)));
		} catch (IOException ioe) {
			throw new MactorException("Failed to write message to dir '" + dir + "'. File name: ''" + fn + "' . Error:" + ioe.getMessage());
		}
	}
	private String getDir(ChannelConfig cf) throws MactorException {
		String dir = cf.getRequieredValue("dir");
		File f = new File(dir);
		if (!f.exists())
			if (!f.mkdirs())
				throw new MactorException("Unable to create the dir '" + dir + "' specified in the channel config for channel: " + cf.getName());
		if (!dir.endsWith("\\") && !dir.endsWith("/"))
			dir = dir + "/";
		return dir;
	}
	private static long counter = System.currentTimeMillis();
	private static synchronized long getNext() {
		return counter++;
	}
	public void terminate() {
		super.terminate();
	}
}
