/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.brokers;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import org.apache.log4j.Logger;
import org.mactor.framework.MactorException;
import org.mactor.framework.extensioninterface.MessageSelectorCommand;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig;

/**
 * Abstract class that contains functinally common to most message broker
 * implementations (such as maintaining subscribers).
 * 
 * @author Lars Ivar Almli
 */
public abstract class AbstractMessageBroker implements MessageBroker {
	protected static Logger log = Logger.getLogger(AbstractMessageBroker.class);
	protected MessageBrokerConfig config;
	private Map<String, ChannelListener> channelListenerMap = new HashMap<String, ChannelListener>();
	private Object channelLock = new Object();
	public AbstractMessageBroker(MessageBrokerConfig config) {
		this.config = config;
	}
	public void terminate() {
		// initializedChannels.clear();
		channelListenerMap.clear();
	}
	public void subscribe(String channel, MessageSubscriber subscriber, MessageSelectorCommand messageSelector) throws MactorException {
		ChannelListener cl = null;
		synchronized (channelLock) {
			cl = channelListenerMap.get(channel);
			if (cl == null) {
				cl = new ChannelListener(channel);
				channelListenerMap.put(channel, cl);
				onFirstSubscribe(channel);
			}
		}
		cl.addSubscriber(subscriber, messageSelector);
	}
	public void unsubscribe(String channel, MessageSubscriber subscriber) throws MactorException {
		ChannelListener cl = null;
		synchronized (channelLock) {
			cl = channelListenerMap.get(channel);
			if (cl != null) {
				cl.removeSubscriber(subscriber);
				if (cl.getSubscriberCount() == 0) {
					channelListenerMap.remove(channel);
					onLastSubscribe(channel);
				}
			}
		}
	}
	/**
	 * This method shold be invoked message broker implementations when message
	 * is received. The method delivers the message to the subscribers of the
	 * channel
	 * 
	 * @param channel
	 *            the channel the message was recevied
	 * @param message
	 *            the message
	 * @param broadcast
	 *            a flag that indicates if the message should be distributed to
	 *            all subscribers that accepts the message, or just the first
	 *            (random) subscriber that accepets the message.
	 * @return a result message that might be used by message broker
	 *         implementation to return a synchrounous result to the source of
	 *         the incoming messages.
	 * @throws MactorException
	 */
	protected Message raiseOnMessage(String channel, Message message, boolean broadcast) throws MactorException {
		ChannelListener cl = null;
		synchronized (channelLock) {
			cl = channelListenerMap.get(channel);
		}
		if (cl == null)
			throw new MactorException("Unknown channel '" + channel + "'");
		Message resultMessage = null;
		LinkedList<SC> subs = cl.getSnapshotCopyOfSubscribersList();
		for (SC s : subs) {
			if (s.messageSelector.isAcceptableMessage(message)) {
				resultMessage = s.subscriber.onMessage(message);
				if (!broadcast && message.isConsumed()) {
					break;
				}
			}
		}
		return resultMessage;
	}
	protected abstract void onFirstSubscribe(String channel) throws MactorException;
	protected abstract void onLastSubscribe(String channel) throws MactorException;
	private static class ChannelListener {
		private HashMap<MessageSubscriber, SC> subscribers = new HashMap<MessageSubscriber, SC>();
		private Object lock = new Object();
		private String channel;
		public ChannelListener(String channel) {
			this.channel = channel;
		}
		public void addSubscriber(MessageSubscriber subscriber, MessageSelectorCommand messageSelector) {
			synchronized (lock) {
				subscribers.put(subscriber, new SC(subscriber, messageSelector));
			}
		}
		public boolean removeSubscriber(MessageSubscriber subscriber) {
			synchronized (lock) {
				return subscribers.remove(subscriber) != null;
			}
		}
		public int getSubscriberCount() {
			return subscribers.size();
		}
		public LinkedList<SC> getSnapshotCopyOfSubscribersList() {
			synchronized (lock) {
				return new LinkedList<SC>(subscribers.values());
			}
		}
	}
	private static class SC {
		MessageSubscriber subscriber;
		MessageSelectorCommand messageSelector;
		public SC(MessageSubscriber subscriber, MessageSelectorCommand messageSelector) {
			super();
			this.subscriber = subscriber;
			this.messageSelector = messageSelector;
		}
	}
}