/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.actions;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.dom4j.Element;
import org.mactor.brokers.soap.wsdl.Wsdl;
import org.mactor.brokers.soap.wsdl.Wsdl.OperationInfo;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ActionSpec;
import org.mactor.framework.spec.MessagePublishSpec;
import org.mactor.framework.spec.MessageReceiveSpec;
import org.mactor.framework.spec.MessageRespondSpec;
import org.mactor.framework.spec.MessageSubscribeSpec;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.ui.gui.AsyncAction;
import org.mactor.ui.gui.GuiUtil;
import org.mactor.ui.gui.project.GuiAction;
import org.mactor.ui.gui.project.ProjectController;
import org.mactor.ui.gui.project.ProjectNodeType;
import org.mactor.ui.gui.project.ProjectTreeNode;
import org.mactor.ui.gui.project.ProjectTreeNodeBuilder;
import org.mactor.ui.gui.project.editors.SimpleFormPanel;

public class CreateChannelsFromWsdlAction implements GuiAction {
	public boolean isPermitted(ProjectTreeNode selectedTreeNode, ProjectController projectController, String[] parameters) {
		return selectedTreeNode != null && (selectedTreeNode.getNodeType().equals(ProjectNodeType.MBC_CHANNEL) || selectedTreeNode.getNodeType().equals(ProjectNodeType.MBC_MESSAGE_BROKER));
	}
	public void perform(ProjectTreeNode selectedTreeNode, ProjectController projectController, String[] parameters) throws MactorException {
		// http://webservices.amazon.com/AWSECommerceService/AWSECommerceService.wsdl
		ProjectTreeNode targetNode = null;
		if (selectedTreeNode.getNodeType().equals(ProjectNodeType.MBC_CHANNEL))
			targetNode = selectedTreeNode.getParentNode();
		else if (selectedTreeNode.getNodeType().equals(ProjectNodeType.MBC_MESSAGE_BROKER))
			targetNode = selectedTreeNode;
		else
			throw new MactorException("Invalid request");
		new WsdlWizard(projectController.getControllerFrame(), targetNode, projectController).setVisible(true);
	}
	public class WsdlWizard extends JDialog {
		JCheckBox generateTestsButton = new JCheckBox("Generate Test Stubs");
		JCheckBox generateMockBatteryButton = new JCheckBox("Generate Mock Battery (only for incoming)");
		ProjectController projectController;
		SimpleFormPanel form = new SimpleFormPanel();
		JTextField url = new JTextField();
		ProjectTreeNode targetNode;
		JButton closeButton = new JButton(new AbstractAction("Close") {
			public void actionPerformed(java.awt.event.ActionEvent arg0) {
				dispose();
			};
		});
		JButton importIncomingButton = new JButton(new AsyncAction("Create Incoming Channels from WSDL (MActor working as a Server)", false, new AsyncAction.AsyncRunnable() {
			public void run() {
				generateChannels(true);
			}
		}));
		JButton importOutgoingButton = new JButton(new AsyncAction("Create Outgoing Channels from WSDL (MActor working as a Client)", false, new AsyncAction.AsyncRunnable() {
			public void run() {
				generateChannels(false);
			}
		}));
		String template;
		public void generateChannels(boolean incoming) {
			if (url.getText() == null || url.getText().trim().length() == 0) {
				GuiUtil.showInfo(this, "URL must be specifed!");
				return;
			}
			try {
				List<String> tests = new LinkedList<String>();
				File wsdlFile = null;
				URL wsdlUrl = null;
				Wsdl wsdl = null;
				try {
					wsdlUrl = new URL(url.getText().trim());
				} catch (Exception e) {
					wsdlFile = new File(url.getText().trim());
				}
				if (wsdlFile != null)
					wsdl = new Wsdl(wsdlFile);
				else
					wsdl = new Wsdl(wsdlUrl);
				String wsdlFileName = null;
				String name = null;
				if (incoming) {
					if (wsdl.getOperations().size() > 0)
						name = wsdl.getOperations().get(0).getService();
					else
						name = System.currentTimeMillis() + "";
					InputStream is = null;
					if (wsdlFile != null)
						is = new FileInputStream(wsdlFile);
					else
						is = new URL(url.getText()).openStream();
					wsdlFileName = writeToDisk(is, name);
				}
				template = CreateEntityAction.getTemplateContent("MBC_CHANNEL");
				for (Wsdl.OperationInfo oi : wsdl.getOperations()) {
					ProjectTreeNode node = ProjectTreeNodeBuilder.createNewNode(ProjectNodeType.MBC_CHANNEL, template);
					Element e = (Element) node.getModelObject();
					e.addAttribute("requires_response", true + "");
					String channel = null;
					String uri = null;
					if (incoming) {
						try {
							URL u = new URL(oi.getTargetURL());
							uri = "http://localhost:8877" + u.getPath();
							if (u.getQuery() != null)
								uri = uri + "?" + u.getQuery();
						} catch (MalformedURLException me) {
							uri = oi.getTargetURL();
						}
						channel = "Incoming" + oi.getTargetMethodName();
						addValue(e, "WsdlFile", wsdlFileName);
					} else {
						uri = oi.getTargetURL();
						channel = "Outgoing" + oi.getTargetMethodName();
					}
					addValue(e, "SoapAction", oi.getSoapActionURI());
					addValue(e, "SoapEndpoint", uri);
					e.attribute("name").setValue(channel);
					node = ProjectTreeNodeBuilder.createNewNode(ProjectNodeType.MBC_CHANNEL, e.asXML());
					projectController.insertNodeIntoNode(targetNode, node);
					if (generateTestsButton.isSelected()) {
						tests.add(createTest(incoming, channel, name, oi));
					}
				}
				if (incoming && generateMockBatteryButton.isSelected())
					createMockBattery(name, tests);
				projectController.reloadProject();
			} catch (Exception e) {
				e.printStackTrace();
				GuiUtil.showGuiError(WsdlWizard.this, e);
			}
		}
		private void addValue(Element e, String name, String value) {
			Element v = e.addElement("value");
			v.addAttribute("name", name);
			v.setText(value);
		}
		String testTemplate;
		private String createTest(boolean incoming, String channelName, String serviceName, OperationInfo oi) throws MactorException, IOException {
			if (testTemplate == null)
				testTemplate = CreateEntityAction.getTemplateContent("T_TEST");
			ProjectTreeNode test = ProjectTreeNodeBuilder.createNewNode(ProjectNodeType.T_TEST, testTemplate);
			String fn = ProjectContext.getGlobalInstance().getNextFilename("Test" + channelName + ".xml", false);
			test.rename(fn);
			Element testElement = (Element) test.getModelObject();
			if (incoming)
				initIncomingTest(testElement, channelName, oi);
			else
				initOutgoingTest(testElement, channelName, oi);
			test.save();
			return fn;
		}
		private void initIncomingTest(Element testElement, String channel, OperationInfo oi) throws MactorException, IOException {
			MessageSubscribeSpec msSpec = new MessageSubscribeSpec();
			msSpec.setChannel(channel);
			msSpec.setName("SubscribeTo" + channel);
			msSpec.getMessageSelector().setCommand("java:org.mactor.extensions.xml.XPathIgnoreNsRegExpMessageSelector");
			MessageRespondSpec mrespSpec = new MessageRespondSpec();
			mrespSpec.setName("RespondTo" + channel);
			mrespSpec.getMessageBuilder().setTemplatePath(createTemplateFile(oi.getService(), oi.getTargetMethodName(), "Response", oi.getNamespaceURI()));
			mrespSpec.getMessageBuilder().setCommand("java:org.mactor.extensions.xml.XPathTemplateMessageBuilder");
			MessageReceiveSpec mrSpec = new MessageReceiveSpec();
			mrSpec.setName("ReceiveFrom" + channel);
			mrSpec.setMinMessageCount(1);
			mrSpec.setMaxTimeoutSeconds(600000);
			mrSpec.setMessageSubscribeNodeName("SubscribeTo" + channel);
			mrSpec.addSpecNode(mrespSpec);
			ActionSpec aSpec = new ActionSpec();
			aSpec.setName("VerifyReceivedMessage");
			aSpec.setCommand("java:org.mactor.extensions.xml.XPathIgnoreNsRegExpValidator");
			msSpec.addToElement(testElement);
			mrSpec.addToElement(testElement);
			aSpec.addToElement(testElement);
		}
		private String createTemplateFile(String service, String messageName, String suffix, String targetNs) throws IOException {
			String dirName = service + "_templates";
			File dir = ProjectContext.getGlobalInstance().getAbsolutePath(dirName);
			if (!dir.exists())
				dir.mkdirs();
			String name = dirName + "/" + messageName + suffix + ".xml";
			File file = ProjectContext.getGlobalInstance().getAbsolutePath(name);
			FileWriter fw = new FileWriter(file);
			fw.write("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns=\"" + targetNs + "\">");
			fw.write("\n <soapenv:Body>");
			fw.write("\n  <" + messageName + ">");
			fw.write("\n\n  <!--insert the message body here -->");
			fw.write("\n\n  </" + messageName + ">");
			fw.write("\n </soapenv:Body>");
			fw.write("\n</soapenv:Envelope>");
			//
			fw.close();
			return name;
		}
		private void initOutgoingTest(Element testElement, String channel, OperationInfo oi) throws MactorException, IOException {
			MessagePublishSpec mpSpec = new MessagePublishSpec();
			mpSpec.setName("PublishTo" + channel);
			mpSpec.setChannel(channel);
			mpSpec.getMessageBuilder().setTemplatePath(createTemplateFile(oi.getService(), oi.getTargetMethodName(), "Request", oi.getNamespaceURI()));
			mpSpec.getMessageBuilder().setCommand("java:org.mactor.extensions.xml.XPathTemplateMessageBuilder");
			ActionSpec aSpec = new ActionSpec();
			aSpec.setName("VerifyReceivedMessage");
			aSpec.setCommand("java:org.mactor.extensions.xml.XPathIgnoreNsRegExpValidator");
			mpSpec.addToElement(testElement);
			aSpec.addToElement(testElement);
		}
		private void createMockBattery(String serviceName, List<String> tests) throws MactorException {
			String template = CreateEntityAction.getTemplateContent("TM_MOCK_BATTERY");
			ProjectTreeNode tm = ProjectTreeNodeBuilder.createNewNode(ProjectNodeType.TM_MOCK_BATTERY, template);
			Element e = (Element) tm.getModelObject();
			for (String t : tests)
				e.addElement("test").addAttribute("name", t);
			tm.save();
		}
		private String writeToDisk(InputStream is, String name) throws MactorException, IOException {
			File f = new File(ProjectContext.getGlobalInstance().getProjectConfigDir() + "/" + name + ".wsdl");
			FileWriter fw = new FileWriter(f);
			for (;;) {
				int val = is.read();
				if (val < 0)
					break;
				fw.write(val);
			}
			fw.close();
			return f.getName();
		}
		public WsdlWizard(Frame parentFrame, ProjectTreeNode targetNode, ProjectController projectController) {
			super(parentFrame, true);
			setTitle("Create SOAP Channels From WSDL");
			this.targetNode = targetNode;
			this.projectController = projectController;
			setLayout(new BorderLayout());
			form.add(new JLabel("WSDL URI:"));
			form.add(url);
			JPanel p1 = new JPanel(new FlowLayout());
			p1.add(importIncomingButton);
			JPanel p2 = new JPanel(new FlowLayout());
			p2.add(importOutgoingButton);
			form.add(generateTestsButton);
			form.add(generateMockBatteryButton);
			JPanel bottomPanel = new JPanel(new FlowLayout());
			form.add(p1);
			form.add(p2);
			bottomPanel.add(closeButton);
			add(form, BorderLayout.CENTER);
			add(bottomPanel, BorderLayout.SOUTH);
			pack();
		}
	}
}
