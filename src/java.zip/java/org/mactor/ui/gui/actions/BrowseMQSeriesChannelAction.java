/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.actions;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.dom4j.Element;
import org.mactor.brokers.Message;
import org.mactor.brokers.mqseries.MqSeriesQueueBrowser;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.MessageBrokersConfig.MessageBrokerConfig.ChannelConfig;
import org.mactor.ui.gui.AsyncAction;
import org.mactor.ui.gui.GuiUtil;
import org.mactor.ui.gui.project.GuiAction;
import org.mactor.ui.gui.project.ProjectController;
import org.mactor.ui.gui.project.ProjectNodeType;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class BrowseMQSeriesChannelAction implements GuiAction {
	public boolean isPermitted(ProjectTreeNode selectedTreeNode, ProjectController projectController, String[] parameters) {
		if (selectedTreeNode == null || !selectedTreeNode.getNodeType().equals(ProjectNodeType.MBC_CHANNEL))
			return false;
		String bc = ((Element) selectedTreeNode.getParentNode().getModelObject()).attributeValue("broker_class");
		if (bc != null && bc.endsWith("MqSeriesMessageBroker"))
			return true;
		return false;
	}
	public void perform(ProjectTreeNode selectedTreeNode, ProjectController projectController, String[] parameters) throws MactorException {
		try {
			new BrowseMQSeriesChannelDlg(ChannelConfig.loadConfig(((Element) selectedTreeNode.getModelObject()))).setVisible(true);
		} catch (Exception e) {
			GuiUtil.showGuiError(projectController.getControllerFrame(), e);
		}
	}
	private class BrowseMQSeriesChannelDlg extends JFrame {
		MqSeriesQueueBrowser browser;
		JTextArea messageText = new JTextArea(40, 80);
		JButton okButton = new JButton(new AsyncAction("Ok", false, new AsyncAction.AsyncRunnable() {
			public void run() throws MactorException {
				browser.close();
				dispose();
			}
		}));
		JButton firstButton = new JButton(new AsyncAction("First Message", false, new AsyncAction.AsyncRunnable() {
			public void run() throws MactorException {
				Message message = browser.browseFirstMessage();
				if (message == null)
					messageText.setText("The channel is empty");
				else
					messageText.setText(message.getContent());
				consumeButton.setEnabled(message != null);
			}
		}));
		JButton consumeButton = new JButton(new AsyncAction("Consume Message", false, new AsyncAction.AsyncRunnable() {
			public void run() throws MactorException {
				browser.consumeMessage();
				messageText.setText("The message was consumed");
			}
		}));
		JButton nextButton = new JButton(new AsyncAction("Next Message", false, new AsyncAction.AsyncRunnable() {
			public void run() throws MactorException {
				Message message = browser.browseNextMessage();
				if (message == null)
					messageText.setText("There is no more messages on the channel");
				else
					messageText.setText(message.getContent());
				consumeButton.setEnabled(message != null);
			}
		}));
		public BrowseMQSeriesChannelDlg(ChannelConfig cc) throws MactorException {
			super("MActor - Browse MQSeries Channel '" + cc.getName() + "'");
			setLayout(new BorderLayout());
			this.browser = new MqSeriesQueueBrowser(cc);
			JPanel topButtonPanel = new JPanel(new FlowLayout());
			topButtonPanel.add(firstButton);
			topButtonPanel.add(nextButton);
			// topButtonPanel.add(consumeButton);
			add(topButtonPanel, BorderLayout.NORTH);
			add(new JScrollPane(messageText), BorderLayout.CENTER);
			messageText.setEditable(false);
			JPanel bottomButtonPanel = new JPanel(new FlowLayout());
			bottomButtonPanel.add(okButton);
			add(bottomButtonPanel, BorderLayout.SOUTH);
			consumeButton.setEnabled(false);
			pack();
		}
	}
}