/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.actions;

import org.mactor.framework.MactorException;
import org.mactor.ui.gui.ResourceUtil;
import org.mactor.ui.gui.project.DropAcceptRules;
import org.mactor.ui.gui.project.GuiAction;
import org.mactor.ui.gui.project.ProjectController;
import org.mactor.ui.gui.project.ProjectNodeType;
import org.mactor.ui.gui.project.ProjectTreeNode;
import org.mactor.ui.gui.project.ProjectTreeNodeBuilder;
import org.mactor.ui.gui.project.DropAcceptRules.DropAcceptInfo;

public class CreateEntityAction implements GuiAction {
	public boolean isPermitted(ProjectTreeNode selectedTreeNode, ProjectController projectController, String[] parameters) {
		if (parameters == null || parameters.length == 0)
			return false;
		ProjectNodeType nodeType = ProjectNodeType.valueOf(parameters[0]);
		DropAcceptInfo dropAcceptInfo = DropAcceptRules.getDropAcceptInfo(selectedTreeNode, nodeType);
		return dropAcceptInfo.isCopyAccepted() || dropAcceptInfo.isCopyAsideAccepted();
	}
	public void perform(ProjectTreeNode selectedTreeNode, ProjectController projectController, String[] parameters) throws MactorException {
		if (parameters == null || parameters.length == 0)
			throw new MactorException("Node type not specified");
		ProjectNodeType nodeType = ProjectNodeType.valueOf(parameters[0]);
		if (nodeType == null)
			throw new MactorException("Unsupported node type '" + parameters[0] + "'");
		String template = null;
		if (parameters.length > 1)
			template = parameters[1];
		else
			template = parameters[0];
		ProjectTreeNode node = ProjectTreeNodeBuilder.createNewNode(nodeType, getTemplateContent(template));
		ProjectTreeNode targetNode = selectedTreeNode;
		DropAcceptInfo dropAcceptInfo = DropAcceptRules.getDropAcceptInfo(targetNode, node);
		if (dropAcceptInfo.isCopyIntoAccepted())
			projectController.insertNodeIntoNode(selectedTreeNode, node);
		else if (dropAcceptInfo.isCopyAsideAccepted())
			projectController.insertNodeAfterNode(selectedTreeNode, node);
		else
			throw new MactorException("Illegal request");
	}
	public static String getTemplateContent(String templateName) {
		try {
			return ResourceUtil.readResourceTextContent("entity_action_templates" + "/" + templateName);
		} catch (MactorException e) {
			e.printStackTrace();
		}
		return null;
	}
}
