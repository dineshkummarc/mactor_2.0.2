/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
/**
 * 
 */
package org.mactor.ui.gui.actions;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.ui.gui.AsyncAction;
import org.mactor.ui.gui.project.GuiAction;
import org.mactor.ui.gui.project.ProjectController;
import org.mactor.ui.gui.project.ProjectNodeType;
import org.mactor.ui.gui.project.ProjectTreeNode;
import org.mactor.ui.gui.project.ProjectTreeNodeBuilder;
import org.mactor.ui.gui.project.editors.SimpleFormPanel;
import org.mactor.ui.gui.project.editors.SimpleRowPanel;

public class NewProjectAction implements GuiAction {
	public boolean isPermitted(ProjectTreeNode selectedTreeNode, ProjectController projectController, String[] parameters) {
		return true;
	}
	public void perform(ProjectTreeNode selectedTreeNode, ProjectController projectController, String[] parameters) throws MactorException {
		new NewProjectDlg(projectController).setVisible(true);
	}
	static JFileChooser fc;
	private class NewProjectDlg extends JDialog {
		ProjectController projectController;
		JTextField nameText = new JTextField(20);
		JTextField dirText = new JTextField(20);
		JButton selectDir = new JButton(new AbstractAction("Select...") {
			public void actionPerformed(java.awt.event.ActionEvent arg0) {
				if (fc == null) {
					if (ProjectContext.getGlobalInstance().getProjectDir() != null)
						fc = new JFileChooser(ProjectContext.getGlobalInstance().getProjectDir());
					else
						fc = new JFileChooser(new File("."));
				}
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int returnVal = fc.showOpenDialog(projectController.getControllerFrame());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					dirText.setText(fc.getSelectedFile().getAbsolutePath());
				}
			};
		});
		JButton okButton = new JButton(new AsyncAction("Ok", false, new AsyncAction.AsyncRunnable() {
			public void run() throws MactorException {
				if (nameText.getText() == null || nameText.getText().trim().length() == 0)
					throw new MactorException("Project Name must be specified");
				if (dirText.getText() == null || dirText.getText().trim().length() == 0)
					throw new MactorException("Project Parent Directory must be specified");
				File pdir = new File(dirText.getText() + "/" + nameText.getText().trim());
				File f = new File(dirText.getText());
				if (!f.exists()) {
					if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(null, "The selected project parent directory '" + f.getAbsolutePath() + "' does not exist. Create it?"))
						return;
				}
				if (!pdir.mkdirs())
					throw new MactorException("Unable to create project directory '" + pdir.getAbsolutePath() + "'");
				projectController.openProject(pdir);
				ProjectTreeNode gc = ProjectTreeNodeBuilder.createNewNode(ProjectNodeType.G_GLOBAL_CONFIG, CreateEntityAction.getTemplateContent("G_GLOBAL_CONFIG"));
				ProjectTreeNode mbc = ProjectTreeNodeBuilder.createNewNode(ProjectNodeType.MBC_MESSAGE_BROKERS, CreateEntityAction.getTemplateContent("MBC_MESSAGE_BROKERS"));
				ProjectContext.getGlobalInstance().setGlobalConfigName(gc.getName());
				ProjectContext.getGlobalInstance().setMessageBrokerConfigName(mbc.getName());
				projectController.reloadProject();
				dispose();
			}
		}));
		JButton cancelButton = new JButton(new AbstractAction("Cancel") {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				dispose();
			};
		});
		public NewProjectDlg(ProjectController projectController) {
			super(projectController.getControllerFrame(), "MActor - New Project");
			setModal(true);
			setLayout(new BorderLayout());
			this.projectController = projectController;
			SimpleFormPanel form = new SimpleFormPanel();
			form.add(new JLabel("Project Name:"));
			form.add(nameText);
			form.add(new JLabel("Project Parent Directory:"));
			SimpleRowPanel row = new SimpleRowPanel();
			row.add(dirText);
			row.add(selectDir);
			form.add(row);
			JPanel bottomPanel = new JPanel(new FlowLayout());
			bottomPanel.add(okButton);
			bottomPanel.add(cancelButton);
			JPanel p = new JPanel(new BorderLayout());
			p.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			p.add(form, BorderLayout.CENTER);
			p.add(bottomPanel, BorderLayout.SOUTH);
			add(p, BorderLayout.CENTER);
			pack();
		}
	}
}
