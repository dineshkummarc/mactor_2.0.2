/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class AboutDlg extends JDialog {
	public AboutDlg(Frame parent) throws IOException {
		super(parent);
		setModal(true);
		setLayout(new BorderLayout());
		setTitle("MActor - About");
		JEditorPane aboutPane = new JEditorPane(Thread.currentThread().getContextClassLoader().getResource("ABOUT"));
		aboutPane.setEditable(false);
		aboutPane.addHyperlinkListener(BrowserUtil.createLinkListener());
		// aboutPane.setBackground(Color.LIGHT_GRAY);
		JScrollPane sp = new JScrollPane(aboutPane);
		sp.setPreferredSize(new Dimension(580, 400));
		sp.setBorder(BorderFactory.createRaisedBevelBorder());
		add(sp, BorderLayout.CENTER);
		JButton b = new JButton("Ok");
		JPanel bp = new JPanel();
		bp.add(b);
		add(bp, BorderLayout.SOUTH);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AboutDlg.this.setVisible(false);
			}
		});
		pack();
		setResizable(false);
	}
}
