/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.mactor.framework.MactorException;

public class ResourceUtil {
	public static String readResourceTextContent(String resource) throws MactorException {
		try {
			InputStreamReader ir = new InputStreamReader(Thread.currentThread().getContextClassLoader().getResourceAsStream(resource));
			char[] buffer = new char[4000];
			StringBuffer sb = new StringBuffer();
			while (true) {
				int count = ir.read(buffer);
				if (count <= 0)
					break;
				sb.append(buffer, 0, count);
			}
			return sb.toString();
		} catch (Exception e) {
			throw new MactorException("Failed to read the resoruces '" + resource + "'", e);
		}
	}
	public static String readFileContent(File path) throws MactorException {
		try {
			InputStreamReader ir = new InputStreamReader(new FileInputStream(path));
			char[] buffer = new char[4000];
			StringBuffer sb = new StringBuffer();
			while (true) {
				int count = ir.read(buffer);
				if (count <= 0)
					break;
				sb.append(buffer, 0, count);
			}
			return sb.toString();
		} catch (Exception e) {
			throw new MactorException("Failed to read the file '" + path.getAbsolutePath() + "'", e);
		}
	}
}
