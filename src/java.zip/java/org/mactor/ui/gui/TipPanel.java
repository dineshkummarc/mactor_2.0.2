/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
/**
 * 
 */
package org.mactor.ui.gui;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JPanel;
import javax.swing.JTextArea;

import org.mactor.ui.gui.project.editors.TipListener;

public class TipPanel extends JPanel implements TipListener {
	JTextArea tipText = new JTextArea(2, 40);
	String tip1;
	String tip2;
	String tip3;
	public TipPanel() {
		super(new BorderLayout());
		tipText.setBackground(getBackground());
		tipText.setEditable(false);
		tipText.setLineWrap(true);
		tipText.setFont(tipText.getFont().deriveFont(Font.ITALIC));
		add(tipText, BorderLayout.NORTH);
	}
	public void onTip(int tipLevel, String tip) {
		String text = "";
		if (tip == null)
			tip = "";
		if (tipLevel == 1) {
			tip2 = null;
			tip3 = null;
			tip1 = tip;
			text = tip;
		} else if (tipLevel == 2) {
			tip3 = null;
			tip2 = tip;
			if (tip1 != null && tip1.length() > 0)
				text = tip1 + "\n\n";
			text = text + tip;
		} else if (tipLevel == 3) {
			tip3 = tip;
			if (tip1 != null && tip1.length() > 0)
				text = tip1 + "\n\n";
			if (tip2 != null && tip2.length() > 0)
				text = text + tip2 + "\n\n";
			text = text + tip;
		}
		tipText.setText("\n\n\n" + text);
	}
}