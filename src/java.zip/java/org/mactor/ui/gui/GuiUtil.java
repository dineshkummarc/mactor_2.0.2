/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;
import org.mactor.framework.MactorException;

public class GuiUtil {
	protected static Logger log = Logger.getLogger(GuiUtil.class);
	private static final SimpleDateFormat sdf = new SimpleDateFormat("d MMM HH:mm:ss.SSS");
	public static final Icon loadIcon(String name) {
		return new ImageIcon(GuiUtil.class.getResource(name));
	}
	public static final String format(Calendar time) {
		if (time == null)
			return "";
		return sdf.format(time.getTime());
	}
	public static final void showGuiError(Component component, Exception e) {
		if (e instanceof MactorException)
			log.info(e.getMessage());
		else
			log.warn("Unexpected exception:" + e.getMessage());
		JOptionPane.showMessageDialog(component, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	}
	public static final void showInfo(Component component, String info) {
		JOptionPane.showMessageDialog(component, info);
	}
}
