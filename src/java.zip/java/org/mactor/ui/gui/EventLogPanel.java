/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.Icon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;

import org.apache.log4j.Appender;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.spi.LoggingEvent;
import org.mactor.brokers.MessageBrokerManager.MessageInfo;
import org.mactor.brokers.MessageBrokerManager.MessageInfoListener;
import org.mactor.framework.MactorException;

public class EventLogPanel extends JPanel {
	private JTable table;
	EventHistoryTableModel model = new EventHistoryTableModel();
	public EventLogPanel() throws MactorException {
		super(new BorderLayout());
		LogManager.getLogger("org.mactor").addAppender(a);
		LogManager.getLogger("MactorIncomingMessage").addAppender(new MessageLogAppender(INCOMING_ICON));
		LogManager.getLogger("MactorIncomingResponse").addAppender(new MessageLogAppender(INCOMING_RESP_ICON));
		LogManager.getLogger("MactorOutgingMessage").addAppender(new MessageLogAppender(OUTGOING_ICON));
		LogManager.getLogger("MactorOutgingResponse").addAppender(new MessageLogAppender(OUTGOING_RESP_ICON));
		table = new JTable(model);
		table.getColumnModel().getColumn(0).setCellRenderer(new MessageTableCellRendere());
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		// summaryTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(0).setMaxWidth(25);
		table.getColumnModel().getColumn(1).setMaxWidth(200);
		JScrollPane tableSp = new JScrollPane(table);
		tableSp.setPreferredSize(new Dimension(100, 100));
		add(tableSp, BorderLayout.CENTER);
	}
	MessageInfoListener miListener = new MessageInfoListener() {
		public void onMessageInfo(final MessageInfo messageInfo) {
			final Event event = new Event();
			event.message = messageInfo.getChannel() + (messageInfo.isResponse() ? " (response)" : "") + " : " + messageInfo.getArchivePath();
			event.time = GuiUtil.format(messageInfo.getCreatedTime());
			if (messageInfo.isIncoming()) {
				if (messageInfo.isResponse())
					event.icon = INCOMING_RESP_ICON;
				else
					event.icon = INCOMING_ICON;
			} else if (messageInfo.isResponse())
				event.icon = OUTGOING_RESP_ICON;
			else
				event.icon = OUTGOING_ICON;
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					model.addEvent(event);
				}
			});
		};
	};
	private class MessageLogAppender extends AppenderSkeleton {
		Icon icon;
		MessageLogAppender(Icon icon) {
			this.icon = icon;
		}
		@Override
		protected void append(LoggingEvent logEvent) {
			if (!logEvent.getLevel().isGreaterOrEqual(Level.INFO))
				return;
			final Event event = new Event();
			event.message = logEvent.getMessage() + "";
			Calendar t = Calendar.getInstance();
			t.setTimeInMillis(logEvent.timeStamp);
			event.time = GuiUtil.format(t);
			event.icon = icon;
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					model.addEvent(event);
				}
			});
		}
		@Override
		public void close() {
		}
		@Override
		public boolean requiresLayout() {
			return false;
		}
	}
	Appender a = new AppenderSkeleton() {
		@Override
		protected void append(LoggingEvent logEvent) {
			if (!logEvent.getLevel().isGreaterOrEqual(Level.INFO))
				return;
			final Event event = new Event();
			event.message = logEvent.getLocationInformation().getClassName() + " : " + logEvent.getMessage();
			Calendar t = Calendar.getInstance();
			t.setTimeInMillis(logEvent.getStartTime());
			event.time = GuiUtil.format(t);
			if (Level.INFO.equals(logEvent.getLevel()))
				event.icon = INFO_ICON;
			else if (Level.WARN.equals(logEvent.getLevel()))
				event.icon = WARN_ICON;
			else if (Level.ERROR.equals(logEvent.getLevel()))
				event.icon = ERROR_ICON;
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					model.addEvent(event);
				}
			});
		}
		@Override
		public void close() {
		}
		@Override
		public boolean requiresLayout() {
			return false;
		}
	};
	public void stop() throws MactorException {
		// MessageBrokerManager.getInstance().removeMessageInfoListener(channel,
		// miListener);
	}
	private static final Icon ERROR_ICON = GuiUtil.loadIcon("/error_16.PNG");
	private static final Icon INFO_ICON = GuiUtil.loadIcon("/info_16.PNG");
	private static final Icon WARN_ICON = GuiUtil.loadIcon("/warning_16.PNG");
	private static final Icon INCOMING_ICON = GuiUtil.loadIcon("/incoming_16.PNG");
	private static final Icon INCOMING_RESP_ICON = GuiUtil.loadIcon("/incoming_resp_16.PNG");
	private static final Icon OUTGOING_ICON = GuiUtil.loadIcon("/outgoing_16.PNG");
	private static final Icon OUTGOING_RESP_ICON = GuiUtil.loadIcon("/outgoing_resp_16.PNG");
	private class Event {
		Icon icon;
		String time;
		String message;
		public Event() {
		}
		public Event(Icon icon, String time, String message) {
			super();
			this.icon = icon;
			this.time = time;
			this.message = message;
		}
	}
	static final int MAX = 2000;
	static final int HYST = 500;
	private static class EventHistoryTableModel extends AbstractTableModel {
		ArrayList<Event> history = new ArrayList<Event>();
		String[] colums = new String[] { "", "Timestamp", "Message" };
		@Override
		public String getColumnName(int col) {
			return colums[col];
		}
		public void addEvent(Event event) {
			this.history.add(event);
			adjust();
			super.fireTableDataChanged();
		}
		final private void adjust() {
			if (this.history.size() > MAX)
				this.history = new ArrayList<Event>(this.history.subList((history.size() - MAX) + HYST, history.size() - 1));
		}
		public int getColumnCount() {
			return colums.length;
		}
		public int getRowCount() {
			if (history == null)
				return 0;
			return history.size();
		}
		public Object getValueAt(int row, int col) {
			if (history == null)
				return null;
			Event event = history.get(history.size() - 1 - row);
			if (col == 0)
				return event.icon;
			if (col == 1)
				return event.time;
			if (col == 2)
				return event.message;
			throw new RuntimeException("Invalid column '" + col + "'");
		}
	}
	public class MessageTableCellRendere extends DefaultTableCellRenderer {
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (value instanceof Icon)
				setIcon((Icon) value);
			else
				setIcon(null);
			setText(null);
			return this;
		}
	}
}
