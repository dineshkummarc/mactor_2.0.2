/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class VersionDlg extends JDialog {
	JLabel status = new JLabel();
	JLabel link = new JLabel("http://mactor.sourceforge.net");
	JButton b = new JButton("Ok");
	public VersionDlg(Frame parent) {
		super(parent);
		setModal(true);
		setLayout(new BorderLayout());
		setTitle("MActor - Check for new version");
		link.setForeground(Color.blue);
		status.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		link.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 10));
		add(status, BorderLayout.WEST);
		add(link, BorderLayout.EAST);
		// link.setFont(link.getFont().)
		JPanel bp = new JPanel();
		bp.add(b);
		add(bp, BorderLayout.SOUTH);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VersionDlg.this.setVisible(false);
			}
		});
		link.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					BrowserUtil.openURL(new URL(link.getText()));
				} catch (Exception e) {
					e.printStackTrace();// ignore
				}
			}
		});
		pack();
		setResizable(false);
	}
	public void performCheck() {
		link.setVisible(false);
		status.setText("Checking for new version..");
		b.setEnabled(false);
		this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		pack();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				String version = VersionUtil.getVersion();
				String newVersion = VersionUtil.getLatestVersion();
				if (newVersion == null) {
					status.setText("Unable to check if a new version is available");
				} else if (!version.equals(newVersion)) {
					status.setText("Version " + newVersion + " is available for download at: ");
					link.setVisible(true);
				} else {
					status.setText("Your version is up to date!");
				}
				b.setEnabled(true);
				setCursor(Cursor.getDefaultCursor());
				validate();
				pack();
			}
		});
	}
}
