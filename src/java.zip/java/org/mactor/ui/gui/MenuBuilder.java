/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.mactor.framework.MactorException;

public class MenuBuilder {
	Map<String, Element> menuElements = new HashMap<String, Element>();
	ActionsManager actionManager;
	public MenuBuilder(ActionsManager actionManager) throws MactorException {
		this.actionManager = actionManager;
		try {
			loadMenuDefs("project_menus.xml");
		} catch (Exception e) {
			throw new MactorException(e);
		}
		try {
			loadMenuDefs("project_menus_ex.xml");
			System.out.println("project_menus_ex.xml was loaded");
		} catch (Exception e) {
			System.out.println("project_menus_ex.xml was not loaded. Reason:" + e.getMessage());
		}
	}
	private void loadMenuDefs(String resource) throws Exception {
		URL u = Thread.currentThread().getContextClassLoader().getResource(resource);
		if (u == null)
			throw new RuntimeException("Resource '" + resource + "' was not found");
		Document doc = null;
		doc = new SAXReader().read(Thread.currentThread().getContextClassLoader().getResourceAsStream(resource));
		Iterator it = doc.getRootElement().elementIterator("menu");
		while (it.hasNext()) {
			Element e = (Element) it.next();
			menuElements.put(e.attributeValue("name"), e);
		}
	}
	private Element getMenuElement(String name) throws MactorException {
		Element e = menuElements.get(name);
		if (e == null)
			throw new MactorException("The menu '" + name + "' does not exist");
		return e;
	}
	public JPopupMenu buildPopuMenu(String name) throws MactorException {
		return createPopupMenu(menuElements.get(name));
	}
	public JMenu buildMenu(String name) throws MactorException {
		return createMenu(menuElements.get(name));
	}
	private JPopupMenu createPopupMenu(Element e) throws MactorException {
		JPopupMenu m = new JPopupMenu(e.attributeValue("name"));
		Iterator it = e.elementIterator();
		while (it.hasNext()) {
			Element child = (Element) it.next();
			if ("menu".equals(child.getName())) {
				m.add(createMenu(getMenuElement(child.attributeValue("name"))));
			} else if ("action".equals(child.getName())) {
				JMenuItem item = new JMenuItem(actionManager.getAction(child.attributeValue("name")));
				m.add(item);
			} else if ("seperator".equals(child.getName())) {
				m.add(new JSeparator());
			} else {
				throw new MactorException("Encountered unexpected node '" + child.getName() + "' while building menu");
			}
		}
		return m;
	}
	private JMenu createMenu(Element e) throws MactorException {
		JMenu m = new JMenu(e.attributeValue("name"));
		Iterator it = e.elementIterator();
		while (it.hasNext()) {
			Element child = (Element) it.next();
			if ("menu".equals(child.getName())) {
				m.add(createMenu(getMenuElement(child.attributeValue("name"))));
			} else if ("action".equals(child.getName())) {
				JMenuItem item = new JMenuItem(actionManager.getAction(child.attributeValue("name")));
				m.add(item);
			} else if ("seperator".equals(child.getName())) {
				m.add(new JSeparator());
			} else {
				throw new MactorException("Encountered unexpected node '" + child.getName() + "' while building menu");
			}
		}
		return m;
	}
}
