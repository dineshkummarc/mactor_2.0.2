/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JComboBox;

public class CommandTypeComboBox extends JComboBox {
	TipListener tipListener;
	public void setTipListener(TipListener tipListener) {
		this.tipListener = tipListener;
	}
	ActionListener tl = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			NodeEditorConfig.CommandType type = (NodeEditorConfig.CommandType) getSelectedItem();
			if (type != null && tipListener != null)
				tipListener.onTip(2, type.getTip());
			else if (tipListener != null)
				tipListener.onTip(2, null);
		}
	};
	public CommandTypeComboBox() {
		addItem(null);
		setAlignmentX(Component.LEFT_ALIGNMENT);
		addActionListener(tl);
	}
	public void setConfig(Collection<NodeEditorConfig.CommandType> types) {
		removeAllItems();
		addItem(null);
		for (NodeEditorConfig.CommandType type : types) {
			addItem(type);
		}
	}
	public String getSelectedType() {
		NodeEditorConfig.CommandType type = (NodeEditorConfig.CommandType) getSelectedItem();
		if (type == null)
			return "";
		return type.getName();
	}
	public void setSelectedType(String type) {
		int count = getItemCount();
		if (type == null || type.trim().length() == 0) {
			setSelectedIndex(0);
			return;
		}
		for (int i = 1; i < count; i++) {
			NodeEditorConfig.CommandType item = (NodeEditorConfig.CommandType) getItemAt(i);
			if (type.equalsIgnoreCase(item.getName())) {
				setSelectedIndex(i);
				return;
			}
		}
		setSelectedIndex(0);
	}
}
