/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.mactor.ui.gui.project.ProjectNodeType;

public class NodeEditorConfigManager {
	private static NodeEditorConfigManager instance;
	private static Object lock = new Object();
	private Map<String, NodeEditorConfig> nodeEditorConfigMap = new HashMap<String, NodeEditorConfig>();
	public static NodeEditorConfigManager getInstance() {
		if (instance == null) {
			synchronized (lock) {
				if (instance == null) {
					instance = new NodeEditorConfigManager();
				}
			}
		}
		return instance;
	}
	public NodeEditorConfig getNodeEditorConfig(ProjectNodeType nodeType) {
		if(nodeType==null)
			return null;
		return nodeEditorConfigMap.get(nodeType.name());
	}
	private NodeEditorConfigManager() {
		try {
			loadConfig("node_editors.xml");
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			loadConfig("node_editors_ex.xml");
			System.out.print("node_editors_ex.xml was loaded");
		} catch (Exception e) {
			System.out.print("node_editors_ex.xml was not loaded. Reason:" + e.getMessage());
		}
	}
	private void loadConfig(String fn) throws Exception {
		URL u = Thread.currentThread().getContextClassLoader().getResource(fn);
		if (u == null)
			throw new RuntimeException("Resource '" + fn + "' was not found");
		Document doc = new SAXReader().read(u);
		Iterator typeIt = doc.getRootElement().elementIterator("node_type");
		while (typeIt.hasNext()) {
			Element e = (Element) typeIt.next();
			String name = e.attributeValue("name");
			ProjectNodeType nodeType = ProjectNodeType.valueOf(name);
			if (nodeType == null) {
				System.out.println("Unsupported node type '" + name + "' ignoring...");
				continue;
			}
			NodeEditorConfig config = nodeEditorConfigMap.get(name);
			if (config == null) {
				config = new NodeEditorConfig(nodeType);
				nodeEditorConfigMap.put(name, config);
			}
			config.load(e);
		}
	}
}
