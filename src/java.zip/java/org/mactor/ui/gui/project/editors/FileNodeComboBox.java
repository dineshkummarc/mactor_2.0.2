/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JComboBox;

import org.mactor.ui.gui.project.ProjectNodeType;
import org.mactor.ui.gui.project.ProjectTreeNode;
import org.mactor.ui.gui.project.ProjectTreeUtil;

public class FileNodeComboBox extends JComboBox {
	private ProjectNodeType type;
	public FileNodeComboBox(ProjectNodeType type) {
		this.type = type;
		addItem(null);
		setAlignmentX(Component.LEFT_ALIGNMENT);
		super.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String newSel = (String) getSelectedItem();
				if (!isEqual(selectedName, newSel)) {
					selectedName = newSel;
					if (l != null)
						l.fileNodeChanged(newSel);
				}
			}
		});
	}
	public void setConfig(ProjectTreeNode anyNode) {
		removeAllItems();
		addItem(null);
		ProjectTreeNode mbcNode = ProjectTreeUtil.navigateToFirstFileNodeOfType(type, anyNode);
		if (mbcNode != null) {
			mbcNode = mbcNode.getParentNode();
			for (ProjectTreeNode node : mbcNode.getChildNodes()) {
				addItem(node.getCaption());
			}
		}
	}
	public String getSelectedName() {
		Object item = getSelectedItem();
		if (item == null)
			return "";
		return (String) item;
	}
	String selectedName;
	public void setSelectedName(String name) {
		this.selectedName = name;
		int count = getItemCount();
		if (name == null || name.trim().length() == 0) {
			setSelectedIndex(0);
			return;
		}
		for (int i = 1; i < count; i++) {
			String item = (String) getItemAt(i);
			if (item.equals(name)) {
				setSelectedIndex(i);
				return;
			}
		}
		setSelectedIndex(0);
	}
	FileNodeChangedListener l;
	public void setFileNodeChangedListener(FileNodeChangedListener l) {
		this.l = l;
	}
	public interface FileNodeChangedListener {
		void fileNodeChanged(String newName);
	}
	private static boolean isEqual(String s1, String s2) {
		if (s1 == s2)
			return true;
		if (s1 == null)
			return false;
		return s1.equals(s2);
	}
}
