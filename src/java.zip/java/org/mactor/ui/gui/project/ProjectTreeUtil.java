/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.util.Iterator;

public class ProjectTreeUtil {
	public static ProjectTreeNode navigateToFirstFileNodeOfType(ProjectNodeType type, ProjectTreeNode fromNode) {
		if (fromNode == null)
			return null;
		ProjectTreeNode root = navigateToRoot(fromNode);
		Iterator<ProjectTreeNode> orgNodeIt = root.getChildNodes().iterator();
		while (orgNodeIt.hasNext()) {
			ProjectTreeNode node = orgNodeIt.next();
			if (node.getChildCount() > 0) {
				if (node.getChildNode(0).getNodeType().equals(type))
					return node.getChildNode(0);
			}
		}
		return null;
	}
	public static ProjectTreeNode navigateToOrganizationNode(ProjectTreeNode fromNode) {
		if (fromNode == null)
			return null;
		if (fromNode instanceof OrganizationProjectTreeNode)
			return fromNode;
		ProjectTreeNode parent = fromNode.getParentNode();
		while (parent.getParentNode() != null) {
			if (parent instanceof OrganizationProjectTreeNode)
				return parent;
			parent = parent.getParentNode();
		}
		return null;
	}
	public static ProjectTreeNode navigateToRoot(ProjectTreeNode fromNode) {
		if (fromNode == null)
			return null;
		if (fromNode.getParentNode() == null)
			return fromNode;
		ProjectTreeNode parent = fromNode.getParentNode();
		while (parent.getParentNode() != null) {
			parent = parent.getParentNode();
		}
		return parent;
	}
}
