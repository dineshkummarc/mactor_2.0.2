/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;

import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.ui.gui.ActionsManager;
import org.mactor.ui.gui.MenuBuilder;

public class ProjectExplorerPanel extends JPanel {
	ActionsManager am;
	MenuBuilder mb;
	ProjectModel model;
	ProjectTree tree;
	JPopupMenu treePopupMessageBrokerConfig;
	JPopupMenu treePopupTest;
	JPopupMenu treePopupMockBattery;
	JPopupMenu treePopupTestRun;
	JPopupMenu treePopupGlobalConfig;
	ProjectControlListener projectControlListener;
	String nodeName;
	TreeSelectionListener tl = new TreeSelectionListener() {
		public void valueChanged(javax.swing.event.TreeSelectionEvent e) {
			ProjectTreeNode oldNode = null;
			ProjectTreeNode newNode = null;
			if (e.getNewLeadSelectionPath() != null && e.getNewLeadSelectionPath().getPathCount() > 0) {
				newNode = (ProjectTreeNode) e.getNewLeadSelectionPath().getLastPathComponent();
			}
			if (e.getOldLeadSelectionPath() != null && e.getOldLeadSelectionPath().getPathCount() > 0) {
				oldNode = (ProjectTreeNode) e.getOldLeadSelectionPath().getLastPathComponent();
			}
			projectControlListener.onProjectTreeSelectionChanged(newNode, oldNode);
			if (oldNode != null && nodeName != null) {
				if (!nodeName.equals(oldNode.getName()))
					model.notifyNodeNameChanged(oldNode);
			}
			if (newNode != null)
				nodeName = newNode.getName();
		};
	};
	public ProjectController getProjectController() {
		return projectController;
	}
	private ProjectContext.ProjectContextListener projectContextListener = new ProjectContext.ProjectContextListener() {
		public void onDirty() {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					projectControlListener.onProjectDirty();
				}
			});
		}
	};
	ProjectController projectController = new ProjectController() {
		public ProjectModel getProjectModel() {
			return model;
		}
		public void closeProject() throws MactorException {
			// TODO Auto-generated method stub
		}
		public Frame getControllerFrame() {
			return JOptionPane.getFrameForComponent(ProjectExplorerPanel.this);
		}
		public void startEditingNode(ProjectTreeNode node) {
			tree.startEditingAtPath(new TreePath(ProjectModel.getPath(node)));
		}
		public void insertNodeIntoNode(ProjectTreeNode destNode, ProjectTreeNode nodeToInsert) throws MactorException {
			model.insertInto(destNode, nodeToInsert);
			tree.expandPath(new TreePath(ProjectModel.getPath(destNode)));
			int row = tree.getRowForPath(new TreePath(ProjectModel.getPath(nodeToInsert)));
			tree.setSelectionRow(row);
		}
		public void insertNodeAfterNode(ProjectTreeNode destNode, ProjectTreeNode nodeToInsert) throws MactorException {
			model.insertAfter(destNode, nodeToInsert);
			tree.expandPath(new TreePath(ProjectModel.getPath(nodeToInsert)));
			tree.setSelectionRow(tree.getRowForPath(new TreePath(ProjectModel.getPath(nodeToInsert))));
		}
		public void openProject(File path) throws MactorException {
			ProjectContext.getGlobalInstance().setProjectDir(path);
			reloadProject();
			projectControlListener.onProjectLoaded();
		}
		public void reloadProject() throws MactorException {
			model.reload(ProjectContext.getGlobalInstance().getProjectDir());
			tree.setSelectionRow(0);
			projectControlListener.onProjectLoaded();
			ProjectContext.getGlobalInstance().setDirty(false);
			ProjectContext.getGlobalInstance().setListener(projectContextListener);
		}
		public void deleteNode(ProjectTreeNode node) throws MactorException {
			model.delete(node);
		}
		public void requestGuiAction(ProjectTreeNode node, String action) {
			projectControlListener.onRequestGuiAction(node, action);
		}
	};
	public MenuBuilder getMenuBuilder() {
		return mb;
	}
	public ProjectExplorerPanel(ProjectControlListener projectControlListener) throws MactorException {
		super(new BorderLayout());
		this.projectControlListener = projectControlListener;
		model = new ProjectModel(ProjectContext.getGlobalInstance().getProjectDir());
		tree = new ProjectTree(model);
		am = new ActionsManager(projectController, tree);
		mb = new MenuBuilder(am);
		setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
		JScrollPane treeSp = new JScrollPane(tree);
		add(treeSp, BorderLayout.CENTER);
		tree.setEditable(true);
		tree.addTreeSelectionListener(tl);
		treePopupGlobalConfig = mb.buildPopuMenu("Global Configuration");
		treePopupMessageBrokerConfig = mb.buildPopuMenu("Message Broker Configuration");
		treePopupTest = mb.buildPopuMenu("Test");
		treePopupMockBattery = mb.buildPopuMenu("Mock Battery");
		treePopupTestRun = mb.buildPopuMenu("Test Run");
		tree.setInvokesStopCellEditing(true);
		tree.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent evt) {
				int row = tree.getRowForLocation(evt.getX(), evt.getY());
				tree.setSelectionRow(row);
				showPopup(evt);
			}
			public void mouseReleased(MouseEvent evt) {
				if (evt.isPopupTrigger()) {
					showPopup(evt);
				}
			}
		});
		tree.setSelectionRow(0);
	}
	private void showPopup(final MouseEvent evt) {
		if (evt.isPopupTrigger()) {
			TreePath p = tree.getSelectionPath();
			if (p != null && p.getLastPathComponent() instanceof ProjectTreeNode) {
				ProjectTreeNode node = (ProjectTreeNode) p.getLastPathComponent();
				ProjectTreeNode orgNode = ProjectTreeUtil.navigateToOrganizationNode(node);
				if (orgNode != null) {
					if (ProjectNodeType.PROJECT_GLOBAL_CONFIG.equals(orgNode.getNodeType()))
						treePopupGlobalConfig.show(evt.getComponent(), evt.getX(), evt.getY());
					else if (ProjectNodeType.PROJECT_MESSAGE_BROKER_CONFIG.equals(orgNode.getNodeType()))
						treePopupMessageBrokerConfig.show(evt.getComponent(), evt.getX(), evt.getY());
					else if (ProjectNodeType.PROJECT_TEST.equals(orgNode.getNodeType()))
						treePopupTest.show(evt.getComponent(), evt.getX(), evt.getY());
					else if (ProjectNodeType.PROJECT_MOCK_BATTERY.equals(orgNode.getNodeType()))
						treePopupMockBattery.show(evt.getComponent(), evt.getX(), evt.getY());
					else if (ProjectNodeType.PROJECT_TEST_RUN.equals(orgNode.getNodeType()))
						treePopupTestRun.show(evt.getComponent(), evt.getX(), evt.getY());
				}
			}
		}
	}
}