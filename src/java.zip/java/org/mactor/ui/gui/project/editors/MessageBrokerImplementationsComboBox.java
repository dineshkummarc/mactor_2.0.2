/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.Component;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JComboBox;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class MessageBrokerImplementationsComboBox extends JComboBox {
	private static List<String> impls;
	public MessageBrokerImplementationsComboBox() {
		addItem(null);
		setAlignmentX(Component.LEFT_ALIGNMENT);
		if (impls == null) {
			impls = getImpls();
		}
		if (impls != null) {
			for (String impl : impls) {
				addItem(impl);
			}
		}
	}
	private List<String> getImpls() {
		List<String> l = new LinkedList<String>();
		try {
			Document doc = new SAXReader().read(Thread.currentThread().getContextClassLoader().getResource("message_broker_impls.xml"));
			Iterator typeIt = doc.getRootElement().elementIterator("impl");
			while (typeIt.hasNext()) {
				Element e = (Element) typeIt.next();
				l.add(e.attributeValue("class"));
			}
		} catch (DocumentException de) {
			de.printStackTrace();
		}
		return l;
	}
	public String getSelectedImplementation() {
		Object item = getSelectedItem();
		if (item == null)
			return "";
		return (String) item;
	}
	public void getSelectedImplementation(String impl) {
		int count = getItemCount();
		if (impl == null || impl.trim().length() == 0) {
			setSelectedIndex(0);
			return;
		}
		for (int i = 1; i < count; i++) {
			String item = (String) getItemAt(i);
			if (item.equals(impl)) {
				setSelectedIndex(i);
				return;
			}
		}
		setSelectedIndex(0);
	}
}
