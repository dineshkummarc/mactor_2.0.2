/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.FlowLayout;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class GlobalConfigNodeEditor extends AbstractNodeEditor {
	Element data;
	public GlobalConfigNodeEditor() {
		super(new FlowLayout());
	}
	public void applyChanges() {
	}
	public void setData(ProjectTreeNode node) throws MactorException {
		this.data = (Element) node.getModelObject();
	}
	public void setConfig(NodeEditorConfig config) {
	}
}
