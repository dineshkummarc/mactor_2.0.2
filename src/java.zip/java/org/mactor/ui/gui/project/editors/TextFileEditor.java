/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
/**
 * 
 */
package org.mactor.ui.gui.project.editors;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.ui.gui.GuiUtil;

class TextFileEditor extends JDialog {
	JTextArea text = new JTextArea(30, 50);
	JTextArea tipText = new JTextArea(2, 50);
	String name;
	JButton ok = new JButton(new AbstractAction("Ok") {
		public void actionPerformed(ActionEvent arg0) {
			try {
				ProjectContext.getGlobalInstance().writeStringToFile(name, text.getText(), false);
			} catch (MactorException me) {
				GuiUtil.showGuiError(TextFileEditor.this, me);
			}
			dispose();
		};
	});
	JButton cancel = new JButton(new AbstractAction("Cancel") {
		public void actionPerformed(ActionEvent arg0) {
			dispose();
		};
	});
	public TextFileEditor(String filename, String title, String tip) {
		setLayout(new BorderLayout());
		setTitle(title);
		this.name = filename;
		add(new JScrollPane(text), BorderLayout.CENTER);
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(ok);
		buttonPanel.add(cancel);
		tipText.setText(tip);
		tipText.setBackground(getBackground());
		tipText.setEditable(false);
		tipText.setLineWrap(true);
		tipText.setFont(tipText.getFont().deriveFont(Font.ITALIC));
		tipText.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
		JPanel bottomPanel = new JPanel(new BorderLayout());
		bottomPanel.add(tipText, BorderLayout.CENTER);
		bottomPanel.add(buttonPanel, BorderLayout.SOUTH);
		add(bottomPanel, BorderLayout.SOUTH);
		try {
			text.setText(ProjectContext.getGlobalInstance().readStringFromFile(name, false));
		} catch (MactorException me) {
			GuiUtil.showGuiError(TextFileEditor.this, me);
		}
		pack();
	}
}