/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.project.ProjectNodeType;

public class NodeEditorConfig {
	private String editor;
	private ProjectNodeType nodeType;
	private Map<String, CommandType> commandTypesMap = new TreeMap<String, CommandType>();
	private String tip;
	public NodeEditorConfig(ProjectNodeType nodeType) {
		this.nodeType = nodeType;
	}
	public Collection<CommandType> getCommandTypes() {
		return commandTypesMap.values();
	}
	public void load(Element element) {
		if (editor == null)
			editor = element.attributeValue("editor");
		if (tip == null)
			tip = element.attributeValue("tip");
		loadCommandTypes(element);
	}
	public NodeEditor createEditor() throws MactorException {
		if (editor == null)
			throw new MactorException("Editor not specified in config");
		try {
			NodeEditor ne = (NodeEditor) Class.forName(editor).newInstance();
			ne.setConfig(this);
			return ne;
		} catch (Exception e) {
			throw new MactorException("Unable to initiate editor '" + editor + "'", e);
		}
	}
	public void loadCommandTypes(Element nodeTypeElement) {
		Iterator typeIt = nodeTypeElement.elementIterator("command_type");
		while (typeIt.hasNext()) {
			Element e = (Element) typeIt.next();
			String name = e.attributeValue("name");
			CommandType config = commandTypesMap.get(name);
			if (config == null) {
				config = new CommandType();
				commandTypesMap.put(name, config);
			}
			config.load(e);
		}
	}
	public static class CommandType {
		private String name;
		private String tip;
		private boolean acceptParameters = true;
		private Set<CommandPrototype> prototypes = new TreeSet<CommandPrototype>();
		public void load(Element element) {
			name = element.attributeValue("name");
			tip = element.attributeValue("tip");
			if (element.attributeValue("accept_paramters") != null)
				acceptParameters = Boolean.parseBoolean(element.attributeValue("accept_paramters"));
			Iterator typeIt = element.elementIterator("command_prototype");
			while (typeIt.hasNext()) {
				prototypes.add(CommandPrototype.loadConfig((Element) typeIt.next()));
			}
		}
		public String getName() {
			return name;
		}
		public String getTip() {
			return tip;
		}
		@Override
		public String toString() {
			return getName();
		}
		public Set<CommandPrototype> getPrototypes() {
			return prototypes;
		}
		public boolean isAcceptParameters() {
			return acceptParameters;
		}
	}
	public static class CommandPrototype implements Comparable<CommandPrototype> {
		private String name;
		private String tip;
		private boolean acceptParameters;
		private List<String> params = new LinkedList<String>();
		public static CommandPrototype loadConfig(Element element) {
			CommandPrototype cp = new CommandPrototype();
			cp.name = element.attributeValue("name");
			cp.tip = element.attributeValue("tip");
			cp.acceptParameters = Boolean.parseBoolean(element.attributeValue("accept_paramters"));
			Iterator<Element> it = element.elementIterator("param");
			while (it.hasNext())
				cp.params.add(it.next().getText());
			return cp;
		}
		public int compareTo(CommandPrototype other) {
			if (this == other)
				return 0;
			return name.compareTo(other.name);
		}
		public String getName() {
			return name;
		}
		public String getTip() {
			return tip;
		}
		@Override
		public String toString() {
			return getName();
		}
		public List<String> getParams() {
			return params;
		}
	}
	public String getEditor() {
		return editor;
	}
	public ProjectNodeType getNodeType() {
		return nodeType;
	}
	public String getTip() {
		return tip;
	}
}
