/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.ui.gui.GuiUtil;
import org.mactor.ui.gui.project.editors.CommandPrototypeComboBox.ProtoListener;

public class CommandEditor extends SimpleFormPanel {
	CommandPrototypeComboBox protoCb = new CommandPrototypeComboBox();
	CommandTypeComboBox typeCb = new CommandTypeComboBox();
	GlobalConfigDBGroupComboBox gcDbGroup = new GlobalConfigDBGroupComboBox();
	ParamsPanel parameterPanel = new ParamsPanel();
	Element data;
	String commandAttributeName;
	SimpleRowPanel dbPanel = new SimpleRowPanel();
	BshPanel bshPanel = new BshPanel();
	JButton test = new JButton(new AbstractAction("Test...") {
		public void actionPerformed(ActionEvent e) {
			try {
				applyListener.onApply();
				new CommandTestDlg(JOptionPane.getFrameForComponent(CommandEditor.this), data).setVisible(true);
			} catch (MactorException me) {
				GuiUtil.showGuiError(CommandEditor.this, me);
			}
		}
	});
	ItemListener typeCbListener = new ItemListener() {
		public void itemStateChanged(java.awt.event.ItemEvent e) {
			NodeEditorConfig.CommandType type = (NodeEditorConfig.CommandType) typeCb.getSelectedItem();
			String proto = protoCb.getSelectedPrototype();
			if (type != null) {
				protoCb.setConfig(type.getPrototypes());
				boolean showDbPanel = "sql".equalsIgnoreCase(type.getName());
				dbPanel.setVisible(showDbPanel);
				if (showDbPanel)
					gcDbGroup.load();
				parameterPanel.setVisible(type.isAcceptParameters());
				bshPanel.setVisible("bsh".equalsIgnoreCase(type.getName()));
			} else {
				protoCb.setConfig(null);
				dbPanel.setVisible(false);
				bshPanel.setVisible(false);
			}
			protoCb.setSelectedPrototype(proto);
		};
	};
	ProtoListener pl = new ProtoListener() {
		public void protoSelected(org.mactor.ui.gui.project.editors.NodeEditorConfig.CommandPrototype proto) {
			parameterPanel.setExampleParamters(proto == null ? null : proto.getParams());
		};
	};
	public void setTipListener(TipListener tipListener) {
		protoCb.setTipListener(tipListener);
		typeCb.setTipListener(tipListener);
	}
	ApplyListener applyListener;
	public CommandEditor(String commandCaption, ApplyListener applyListener) {
		this.commandAttributeName = "command";
		this.applyListener = applyListener;
		add(new JLabel(commandCaption));
		SimpleRowPanel panel = new SimpleRowPanel();
		panel.add(typeCb);
		dbPanel.add(new JLabel(":"));
		dbPanel.add(gcDbGroup);
		panel.add(dbPanel);
		panel.add(new JLabel(":"));
		panel.add(protoCb);
		panel.add(bshPanel);
		panel.add(test);
		add(panel);
		add(parameterPanel);
		typeCb.addItemListener(typeCbListener);
		protoCb.setProtoListener(pl);
	}
	public void applyChanges() {
		if (data.attribute(commandAttributeName) == null)
			data.addAttribute(commandAttributeName, "");
		if (dbPanel.isVisible())
			data.attribute(commandAttributeName).setValue(typeCb.getSelectedType() + ":" + gcDbGroup.getSelectedGroup() + ":" + protoCb.getSelectedPrototype());
		else
			data.attribute(commandAttributeName).setValue(typeCb.getSelectedType() + ":" + protoCb.getSelectedPrototype());
		parameterPanel.applyChanges();
	}
	public void setData(Object data) throws MactorException {
		this.data = (Element) data;
		parameterPanel.setData(data);
		String command = this.data.attributeValue(commandAttributeName);
		String[] parts = null;
		if (command != null)
			parts = command.split(":");
		String type = null;
		String group = null;
		String proto = null;
		if (parts != null) {
			if (parts.length >= 1)
				type = parts[0];
			if (parts.length > 2) {
				proto = parts[2];
				group = parts[1];
			} else if (parts.length == 2)
				proto = parts[1];
		}
		typeCb.setSelectedType(type);
		gcDbGroup.setSelectedGroup(group);
		protoCb.setSelectedPrototype(proto);
		if (!"sql".equalsIgnoreCase(type))
			dbPanel.setVisible(false);
	}
	public void setConfig(NodeEditorConfig config) {
		typeCb.setConfig(config.getCommandTypes());
	}
	private class ParamsPanel extends SimpleFormPanel {
		List<RowPanel> rows = new LinkedList<RowPanel>();
		JButton addRowButton = new JButton("Add Parameter");
		JButton exampleParametersButton = new JButton("Load Example Parameters");
		Element rowsParentElement;
		public ParamsPanel() {
			add(new JLabel("Parameters:"));
			addRowButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					applyChanges();
					rowsParentElement.addElement("param");
					setData(rowsParentElement);
					applyListener.onApply();
				}
			});
			exampleParametersButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					loadExampleParameters();
				}
			});
		}
		public void applyChanges() {
			for (RowPanel row : rows)
				row.applyChanges();
		}
		public void removeRow(RowPanel row) {
			remove(row);
			rows.remove(row);
			rowsParentElement.remove(row.rowElement);
			applyChanges();
			revalidate();
			repaint();
		}
		public void setConfig(NodeEditorConfig config) {
		}
		public void setData(Object data) {
			rowsParentElement = (Element) data;
			rows.clear();
			removeAll();
			add(new JLabel("Command Parameters:"));
			Iterator it = rowsParentElement.elementIterator();
			while (it.hasNext()) {
				RowPanel panel = new RowPanel((Element) it.next());
				rows.add(panel);
				add(panel);
			}
			add(addRowButton);
			add(exampleParametersButton);
			revalidate();
			repaint();
		}
		List<String> examleParameters;
		public void setExampleParamters(List<String> examleParameters) {
			this.examleParameters = examleParameters;
			// exampleParametersButton.setEnabled(examleParameters!=null &&
			// examleParameters.size()>0);
		}
		private void loadExampleParameters() {
			if (examleParameters == null)
				examleParameters = Collections.emptyList();
			if (rowsParentElement != null) {
				Iterator<Element> it = rowsParentElement.elementIterator("param");
				while (it.hasNext()) {
					it.next().detach();
				}
				for (String p : examleParameters) {
					rowsParentElement.addElement("param").setText(p);
				}
				setData(rowsParentElement);
				applyChanges();
			}
		}
		private class RowPanel extends SimpleRowPanel {
			JTextField valueField = new JTextField(20);
			JButton removeButton = new JButton("X");
			Element rowElement;
			public RowPanel(Element rowElement) {
				add(valueField);
				add(removeButton);
				this.rowElement = rowElement;
				valueField.setText(rowElement.getText());
				removeButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						ParamsPanel.this.removeRow(RowPanel.this);
					}
				});
			}
			public void applyChanges() {
				rowElement.setText(valueField.getText());
			}
		}
	}
	private class BshPanel extends SimpleRowPanel {
		JButton bshEdit = new JButton(new AbstractAction("Edit...") {
			public void actionPerformed(ActionEvent e) {
				applyListener.onApply();
				String name = protoCb.getSelectedPrototype();
				if (name != null && name.length() > 0) {
					File path = ProjectContext.getGlobalInstance().getAbsolutePath(name);
					if (!path.exists()) {
						if (JOptionPane.OK_OPTION != JOptionPane
								.showConfirmDialog(BshPanel.this, "The script '" + name + "' does not exist. Create it?", "Create script", JOptionPane.OK_CANCEL_OPTION)) {
							return;
						}
					}
					new TextFileEditor(
							name,
							"Edit BeanShell Script",
							"Tip: BeanShell is an object scripting language for Java. Read more at: http://www.beanshell.org\n\n Note that the TestContext (containing the local variables and the received messages etc.) is made available as a variable named 'context'")
							.setVisible(true);
				}
			}
		});
		JFileChooser fc = new JFileChooser(ProjectContext.getGlobalInstance().getProjectDir());
		JButton selectButton = new JButton(new AbstractAction("Select..") {
			public void actionPerformed(ActionEvent e) {
				applyListener.onApply();
				try {
					if (protoCb.getSelectedPrototype() != null && protoCb.getSelectedPrototype().toLowerCase().endsWith(".bsh"))
						fc.setSelectedFile(ProjectContext.getGlobalInstance().getAbsolutePath(protoCb.getSelectedPrototype()));
					fc.setFileFilter(new FileFilter() {
						@Override
						public String getDescription() {
							return "*.bsh";
						}
						public boolean accept(File f) {
							return !f.isDirectory() && f.getName().endsWith(".bsh");
						}
					});
					int returnVal = fc.showOpenDialog(CommandEditor.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File f = fc.getSelectedFile();
						if (!f.getName().toLowerCase().endsWith(".bsh"))
							f = new File(f.getAbsolutePath() + ".bsh");
						f.createNewFile();
						protoCb.setSelectedPrototype(ProjectContext.getGlobalInstance().getRelativePath(f));
					}
				} catch (IOException ioe) {
					GuiUtil.showGuiError(CommandEditor.this, ioe);
				}
			}
		});
		public BshPanel() {
			add(selectButton);
			add(bshEdit);
		}
	}
}