/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import org.dom4j.Element;
import org.mactor.framework.spec.GlobalConfig.Group;

public class EditorUtil {
	public static void setAttributeValue(Element e, String attrName, String attrValue) {
		if (attrValue == null)
			attrValue = "";
		if (e == null)
			return;
		if (e.attribute(attrName) == null)
			e.addAttribute(attrName, attrValue);
		else
			e.attribute(attrName).setValue(attrValue);
	}
	public static String getAttributeValue(Element e, String attrName) {
		if (e == null)
			return "";
		String v = e.attributeValue(attrName);
		if (v == null)
			return "";
		return v.trim();
	}
	public static boolean isGlobalConfigDBGroupElement(Element e) {
		if (e == null)
			return false;
		try {
			return isGlobalConfigDBGroup(Group.loadGroup(e));
		} catch (Exception ex) {
			return false;
		}
	}
	public static boolean isGlobalConfigDBGroup(Group g) {
		try {
			g.getRequieredValue("url");
			g.getRequieredValue("driver");
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
}
