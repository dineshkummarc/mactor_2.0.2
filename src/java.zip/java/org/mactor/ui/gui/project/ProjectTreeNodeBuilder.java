/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.io.File;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;

public class ProjectTreeNodeBuilder {
	public static ProjectTreeNode buildProjectTree() throws MactorException {
		File projectDir = ProjectContext.getGlobalInstance().getProjectDir();
		OrganizationProjectTreeNode root = new OrganizationProjectTreeNode(ProjectNodeType.PROJECT_ROOT, projectDir.getName());
		OrganizationProjectTreeNode gcOrg = new OrganizationProjectTreeNode(ProjectNodeType.PROJECT_GLOBAL_CONFIG, "Global Config");
		OrganizationProjectTreeNode mbOrg = new OrganizationProjectTreeNode(ProjectNodeType.PROJECT_MESSAGE_BROKER_CONFIG, "Message Broker Config");
		OrganizationProjectTreeNode testOrg = new OrganizationProjectTreeNode(ProjectNodeType.PROJECT_TEST, "Tests");
		OrganizationProjectTreeNode mockBatteryOrg = new OrganizationProjectTreeNode(ProjectNodeType.PROJECT_MOCK_BATTERY, "Mock Batteries");
		OrganizationProjectTreeNode testRunOrg = new OrganizationProjectTreeNode(ProjectNodeType.PROJECT_TEST_RUN, "Test Runs");
		root.addChild(mockBatteryOrg);
		root.addChild(testRunOrg);
		root.addChild(testOrg);
		root.addChild(mbOrg);
		root.addChild(gcOrg);
		File[] files = projectDir.listFiles();
		boolean seperateConfigDir = !projectDir.equals(ProjectContext.getGlobalInstance().getProjectConfigDir());
		if (files != null) {
			for (int i = 0; i < files.length; i++) {
				if (files[i].isDirectory())
					continue;
				try {
					if (files[i].getName().toLowerCase().endsWith(".xml")) {
						Document doc = ProjectContext.getGlobalInstance().readFromFile(files[i]);
						String rootEl = doc.getRootElement().getName();
						if ("test".equalsIgnoreCase(rootEl))
							testOrg.addChild(XmlFileProjectTreeNode.buildFromDocument(files[i], doc, testNodeDictionary, false));
						else if ("mock_battery".equalsIgnoreCase(rootEl))
							mockBatteryOrg.addChild(XmlFileProjectTreeNode.buildFromDocument(files[i], doc, mockbatteryNodeDictionary, false));
						else if (!seperateConfigDir && "message_broker_config".equalsIgnoreCase(rootEl))
							mbOrg.addChild(XmlFileProjectTreeNode.buildFromDocument(files[i], doc, messageBrokerNodeDictionary, true));
						else if (!seperateConfigDir && "global_config".equalsIgnoreCase(rootEl))
							gcOrg.addChild(XmlFileProjectTreeNode.buildFromDocument(files[i], doc, globalConfigNodeDictionary, true));
						else if ("test_run".equalsIgnoreCase(rootEl))
							testRunOrg.addChild(XmlFileProjectTreeNode.buildFromDocument(files[i], doc, testRunNodeDictionary, true));
					}
				} catch (MactorException me) {
					me.printStackTrace();
				}
			}
		}
		if (seperateConfigDir) {
			files = ProjectContext.getGlobalInstance().getProjectConfigDir().listFiles();
			if (files != null) {
				for (int i = 0; i < files.length; i++) {
					if (files[i].isDirectory())
						continue;
					try {
						if (files[i].getName().toLowerCase().endsWith(".xml")) {
							Document doc = ProjectContext.getGlobalInstance().readFromFile(files[i]);
							String rootEl = doc.getRootElement().getName();
							if ("message_broker_config".equalsIgnoreCase(rootEl))
								mbOrg.addChild(XmlFileProjectTreeNode.buildFromDocument(files[i], doc, messageBrokerNodeDictionary, true));
							else if ("global_config".equalsIgnoreCase(rootEl))
								gcOrg.addChild(XmlFileProjectTreeNode.buildFromDocument(files[i], doc, globalConfigNodeDictionary, true));
						}
					} catch (MactorException me) {
						me.printStackTrace();
					}
				}
			}
		}
		return root;
	}
	public static ProjectTreeNode createNewNode(ProjectNodeType nodeType, String templateContent) throws MactorException {
		if (nodeType.equals(ProjectNodeType.G_GLOBAL_CONFIG)) {
			File f = createFile("new-global_config.xml", templateContent, true);
			return XmlFileProjectTreeNode.buildFromFile(f, globalConfigNodeDictionary, true);
		} else if (nodeType.equals(ProjectNodeType.MBC_MESSAGE_BROKERS)) {
			File f = createFile("new-message_broker_config.xml", templateContent, true);
			return XmlFileProjectTreeNode.buildFromFile(f, messageBrokerNodeDictionary, true);
		} else if (nodeType.equals(ProjectNodeType.T_TEST)) {
			File f = createFile("new-test.xml", templateContent, false);
			return XmlFileProjectTreeNode.buildFromFile(f, testNodeDictionary, false);
		} else if (nodeType.equals(ProjectNodeType.TM_MOCK_BATTERY)) {
			File f = createFile("new-mock_battery.xml", templateContent, false);
			return XmlFileProjectTreeNode.buildFromFile(f, mockbatteryNodeDictionary, false);
		} else if (nodeType.equals(ProjectNodeType.TR_TEST_RUN)) {
			File f = createFile("new-test_run.xml", templateContent, false);
			return XmlFileProjectTreeNode.buildFromFile(f, testRunNodeDictionary, false);
		} else {
			Element data = createElementFromString(templateContent);
			if (reversedMessageBrokerNodeDictionary.containsKey(nodeType))
				return new XmlProjectTreeNode(nodeType, data, messageBrokerNodeDictionary);
			else if (reversedGlobalConfigNodeDictionary.containsKey(nodeType))
				return new XmlProjectTreeNode(nodeType, data, globalConfigNodeDictionary);
			else if (reversedMockBatteryNodeDictionary.containsKey(nodeType))
				return new XmlProjectTreeNode(nodeType, data, mockbatteryNodeDictionary);
			else if (reversedTestNodeDictionary.containsKey(nodeType))
				return new XmlProjectTreeNode(nodeType, data, testNodeDictionary);
			else if (reversedTestRunNodeDictionary.containsKey(nodeType))
				return new XmlProjectTreeNode(nodeType, data, testRunNodeDictionary);
		}
		throw new MactorException("Unsupported node type '" + nodeType.name() + "'");
	}
	private static File createFile(String nameSeed, String content, boolean isConfigFile) throws MactorException {
		String name = ProjectContext.getGlobalInstance().getNextFilename(nameSeed, isConfigFile);
		return ProjectContext.getGlobalInstance().writeStringToFile(name, content, isConfigFile);
	}
	private static Element createElementFromString(String elementStr) {
		if (elementStr == null)
			return null;
		try {
			Element e = (Element) new SAXReader().read(new StringReader(elementStr)).getRootElement().detach();
			return e;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	private static Map<String, ProjectNodeType> messageBrokerNodeDictionary = buildMessageBrokerNodeDictionary();
	private static Map<String, ProjectNodeType> globalConfigNodeDictionary = buildGlobalConfigNodeDictionary();
	private static Map<String, ProjectNodeType> mockbatteryNodeDictionary = buildMockBatteryNodeDictionary();
	private static Map<String, ProjectNodeType> testRunNodeDictionary = buildTestRunNodeDictionary();
	private static Map<String, ProjectNodeType> testNodeDictionary = buildTestNodeDictionary();
	private static Map<ProjectNodeType, String> reversedMessageBrokerNodeDictionary = reverse(messageBrokerNodeDictionary);
	private static Map<ProjectNodeType, String> reversedGlobalConfigNodeDictionary = reverse(globalConfigNodeDictionary);
	private static Map<ProjectNodeType, String> reversedMockBatteryNodeDictionary = reverse(mockbatteryNodeDictionary);
	private static Map<ProjectNodeType, String> reversedTestRunNodeDictionary = reverse(testRunNodeDictionary);
	private static Map<ProjectNodeType, String> reversedTestNodeDictionary = reverse(testNodeDictionary);
	private static Map<ProjectNodeType, String> reverse(Map<String, ProjectNodeType> map) {
		Map<ProjectNodeType, String> rm = new HashMap<ProjectNodeType, String>();
		for (Entry<String, ProjectNodeType> e : map.entrySet())
			rm.put(e.getValue(), e.getKey());
		return rm;
	}
	private static Map<String, ProjectNodeType> buildMessageBrokerNodeDictionary() {
		Map<String, ProjectNodeType> dic = new HashMap<String, ProjectNodeType>();
		dic.put("message_broker_config", ProjectNodeType.MBC_MESSAGE_BROKERS);
		dic.put("message_broker", ProjectNodeType.MBC_MESSAGE_BROKER);
		dic.put("channel", ProjectNodeType.MBC_CHANNEL);
		dic.put("value", ProjectNodeType.VALUE);
		return dic;
	}
	private static Map<String, ProjectNodeType> buildGlobalConfigNodeDictionary() {
		Map<String, ProjectNodeType> dic = new HashMap<String, ProjectNodeType>();
		dic.put("global_config", ProjectNodeType.G_GLOBAL_CONFIG);
		dic.put("group", ProjectNodeType.G_GROUP);
		dic.put("value", ProjectNodeType.VALUE);
		return dic;
	}
	private static Map<String, ProjectNodeType> buildMockBatteryNodeDictionary() {
		Map<String, ProjectNodeType> dic = new HashMap<String, ProjectNodeType>();
		dic.put("mock_battery", ProjectNodeType.TM_MOCK_BATTERY);
		dic.put("test", ProjectNodeType.TM_TEST);
		return dic;
	}
	private static Map<String, ProjectNodeType> buildTestRunNodeDictionary() {
		Map<String, ProjectNodeType> dic = new HashMap<String, ProjectNodeType>();
		dic.put("test_run", ProjectNodeType.TR_TEST_RUN);
		return dic;
	}
	private static Map<String, ProjectNodeType> buildTestNodeDictionary() {
		Map<String, ProjectNodeType> dic = new HashMap<String, ProjectNodeType>();
		dic.put("test", ProjectNodeType.T_TEST);
		dic.put("action", ProjectNodeType.T_ACTION);
		dic.put("condition", ProjectNodeType.T_CONDITION);
		dic.put("event_choice", ProjectNodeType.T_EVENT_CHOICE);
		dic.put("event_choice_branch", ProjectNodeType.T_EVENT_CHOICE_BRANCH);
		dic.put("loop", ProjectNodeType.T_LOOP);
		dic.put("message_publish", ProjectNodeType.T_MESSAGE_PUBLISH);
		dic.put("message_receive", ProjectNodeType.T_MESSAGE_RECEIVE);
		dic.put("message_respond", ProjectNodeType.T_MESSAGE_RESPOND);
		dic.put("message_subscribe", ProjectNodeType.T_MESSAGE_SUBSCRIBE);
		dic.put("value", ProjectNodeType.T_VALUE);
		return dic;
	}
}
