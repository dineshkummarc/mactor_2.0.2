/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.util.HashMap;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.dom4j.Element;
import org.mactor.brokers.Message;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestContextImpl;
import org.mactor.framework.commandexecutors.ActionCommandExecutor;
import org.mactor.framework.commandexecutors.ActionCommandExecutorFactory;
import org.mactor.framework.commandexecutors.MessageBuilderCommandExecutor;
import org.mactor.framework.commandexecutors.MessageBuilderCommandExecutorFactory;
import org.mactor.framework.commandexecutors.MessageSelectorCommandExecutor;
import org.mactor.framework.commandexecutors.MessageSelectorCommandExecutorFactory;
import org.mactor.framework.commandexecutors.ValueCommandExecutor;
import org.mactor.framework.commandexecutors.ValueCommandExecutorFactory;
import org.mactor.framework.spec.ActionSpec;
import org.mactor.framework.spec.MessageBuilderSpec;
import org.mactor.framework.spec.MessageSelectorSpec;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.framework.spec.TestSpec;
import org.mactor.framework.spec.ValueSpec;
import org.mactor.framework.spec.XmlUtil;
import org.mactor.ui.gui.AsyncAction;
import org.mactor.ui.gui.GuiUtil;

public class CommandTestDlg extends JDialog {
	JTextArea resultText = new JTextArea(10, 60);
	ContextPanel contextPanel = new ContextPanel();
	Element commandElement;
	TestContextImpl context;
	JButton okButton = new JButton(new AbstractAction("Ok") {
		public void actionPerformed(ActionEvent arg0) {
			dispose();
		};
	});
	JButton evaluateButton = new JButton(new AsyncAction("Evaluate Command", false, new AsyncAction.AsyncRunnable() {
		public void run() {
			context.setValues(contextPanel.getContextValues());
			resultText.setText(evaluateCommand());
		};
	}));
	private String evaluateCommand() {
		String elementName = commandElement.getName();
		String prefix = "The evaluation of:\n" + XmlUtil.getPrettyXML(commandElement) + "\n\nResultet in:\n";
		try {
			if ("value".equals(elementName))
				return prefix + evaluateValueCommand();
			if ("action".equals(elementName))
				return prefix + evaluateActionCommand();
			if ("message_selector".equals(elementName))
				return prefix + evaluateMessageSelectorCommand();
			if ("message_builder".equals(elementName))
				return prefix + evaluateMessageBuilderCommand();
			throw new MactorException("Unsupported command container: '" + elementName + "'");
		} catch (Exception e) {
			e.printStackTrace();
			return prefix + e;
		}
	}
	private String evaluateValueCommand() throws MactorException {
		ValueSpec spec = ValueSpec.loadSpec(commandElement);
		ValueCommandExecutor executor = ValueCommandExecutorFactory.createExecutor(context, spec);
		return executor.extractValue(context);
	}
	private String evaluateActionCommand() throws MactorException {
		ActionSpec spec = ActionSpec.loadSpec(commandElement);
		ActionCommandExecutor executor = ActionCommandExecutorFactory.createExecutor(context, spec);
		executor.perform(context);
		return "Success";
	}
	private String evaluateMessageSelectorCommand() throws MactorException {
		MessageSelectorSpec spec = MessageSelectorSpec.loadSpec(commandElement);
		MessageSelectorCommandExecutor executor = MessageSelectorCommandExecutorFactory.createExecutor(context, spec);
		Message m = context.getLastIncomingMessage();
		if (m == null)
			throw new MactorException("There is no incoming message to validate!");
		if (executor.isAcceptableMessage(m))
			return "The Message was accepted";
		else
			return "The Message was NOT accepted";
	}
	private String evaluateMessageBuilderCommand() throws MactorException {
		MessageBuilderSpec spec = MessageBuilderSpec.loadSpec(commandElement);
		MessageBuilderCommandExecutor executor = MessageBuilderCommandExecutorFactory.createExecutor(context, spec);
		return executor.buildMessage(context).getContent();
	}
	public CommandTestDlg(Frame parent, Element commandElement) throws MactorException {
		super(parent);
		setLayout(new BorderLayout());
		setModal(true);
		setTitle("Test " + commandElement.getName() + " Command");
		this.commandElement = commandElement;
		contextPanel.clearContext();
		SimpleFormPanel form = new SimpleFormPanel();
		form.add(contextPanel);
		JPanel bp = new JPanel(new FlowLayout());
		bp.add(evaluateButton);
		form.add(bp);
		SimpleFormPanel resultForm = new SimpleFormPanel();
		resultForm.add(new JScrollPane(resultText));
		resultForm.setBorder(BorderFactory.createTitledBorder("Evaluation Result"));
		form.add(resultForm);
		add(form, BorderLayout.CENTER);
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(okButton);
		add(buttonPanel, BorderLayout.SOUTH);
		pack();
	}
	private class ContextPanel extends SimpleFormPanel {
		ParamsPanel paramsPanel = new ParamsPanel();
		JTextArea messageText = new JTextArea(10, 40);
		JButton clearContextButton = new JButton(new AbstractAction("Remove All Messages from Context") {
			public void actionPerformed(ActionEvent arg0) {
				try {
					clearContext();
				} catch (MactorException me) {
					GuiUtil.showGuiError(ContextPanel.this, me);
				}
			};
		});
		JButton addParamButton = new JButton(new AbstractAction("Add Variable to Context") {
			public void actionPerformed(ActionEvent arg0) {
				paramsPanel.addNewRow();
			}
		});
		JButton addMessageButton = new JButton(new AbstractAction("Add Message to Context") {
			public void actionPerformed(ActionEvent arg0) {
				try {
					context.addReceivedMessage("dummy", Message.createMessage(messageText.getText()));
				} catch (MactorException me) {
					GuiUtil.showGuiError(ContextPanel.this, me);
				}
			};
		});
		public ContextPanel() {
			setBorder(BorderFactory.createTitledBorder("Test Context"));
			add(new JLabel("Incoming Message:"));
			add(new JScrollPane(messageText));
			JPanel bp = new JPanel(new FlowLayout());
			bp.add(addMessageButton);
			bp.add(clearContextButton);
			bp.add(addParamButton);
			add(bp);
			add(new JLabel("Context Variables:"));
			add(paramsPanel);
		}
		public HashMap<String, String> getContextValues() {
			HashMap<String, String> m = new HashMap<String, String>();
			for (ParamsPanel.RowPanel row : paramsPanel.rows)
				m.put(row.nameField.getText(), row.valueField.getText());
			return m;
		}
		private void clearContext() throws MactorException {
			context = new TestContextImpl(ProjectContext.getGlobalInstance().loadGlobalConfig(), TestSpec.loadFromDocument(commandElement.getDocument(), "dummy"));
		}
	}
}
