/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.FlowLayout;

import javax.swing.JLabel;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class MessagePublishNodeEditor extends AbstractNodeEditor {
	MessageBrokerChannelsComboBox channelsCb = new MessageBrokerChannelsComboBox();
	CommandEditor commandEditor = new CommandEditor("Message Builder Command:", new ApplyListener() {
		public void onApply() {
			applyChanges();
		}
	});
	ProjectInternalFileSelector templatePath = new ProjectInternalFileSelector();
	Element data;
	public void setTipListener(TipListener tipListener) {
		commandEditor.setTipListener(tipListener);
	}
	public MessagePublishNodeEditor() {
		super(new FlowLayout());
		SimpleFormPanel box = new SimpleFormPanel();
		box.add(new JLabel("Channel:"));
		box.add(channelsCb);
		box.add(new JLabel("Template Path:"));
		box.add(templatePath);
		box.add(commandEditor);
		add(box);
	}
	public void applyChanges() {
		commandEditor.applyChanges();
		EditorUtil.setAttributeValue(data, "channel", channelsCb.getSelectedChannel());
		EditorUtil.setAttributeValue(this.data.element("message_builder"), "template_path", templatePath.getPath());
	}
	public void setData(ProjectTreeNode node) throws MactorException {
		this.data = (Element) node.getModelObject();
		if (this.data.element("message_builder") == null)
			this.data.addElement("message_builder");
		commandEditor.setData(this.data.element("message_builder"));
		templatePath.setPath(this.data.element("message_builder").attributeValue("template_path"));
		channelsCb.setSelectedChannel(EditorUtil.getAttributeValue(this.data, "channel"));
	}
	public void setConfig(NodeEditorConfig config) {
		commandEditor.setConfig(config);
	}
}
