/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.zip.CRC32;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;

public class XmlFileProjectTreeNode extends XmlProjectTreeNode {
	File sourceFile;
	boolean isConfigFile;
	long checksum;
	private XmlFileProjectTreeNode(ProjectNodeType nodeType, Element modelElement, Map<String, ProjectNodeType> nodeTypeDictionary) {
		super(nodeType, modelElement, nodeTypeDictionary);
		checksum = computeChecksum(modelElement.getDocument());
	}
	public static XmlProjectTreeNode buildFromFile(File sourceFile, Map<String, ProjectNodeType> nodeTypeDictionary, boolean isConfigFile) throws MactorException {
		try {
			return buildFromDocument(sourceFile, new SAXReader().read(new FileReader(sourceFile)), nodeTypeDictionary, isConfigFile);
		} catch (IOException ioe) {
			throw new MactorException(ioe);
		} catch (DocumentException de) {
			throw new MactorException(de);
		}
	}
	public static XmlProjectTreeNode buildFromDocument(File sourceFile, Document doc, Map<String, ProjectNodeType> nodeTypeDictionary, boolean isConfigFile) {
		Element element = doc.getRootElement();
		ProjectNodeType type = nodeTypeDictionary.get(element.getName());
		if (type == null)
			return null;
		XmlFileProjectTreeNode node = new XmlFileProjectTreeNode(type, element, nodeTypeDictionary);
		node.sourceFile = sourceFile;
		node.isConfigFile = isConfigFile;
		return node;
	}
	@Override
	protected void model_delete() throws MactorException {
		ProjectContext.getGlobalInstance().deleteFile(sourceFile);
		if (ProjectNodeType.MBC_MESSAGE_BROKERS.equals(getNodeType()))
			ProjectContext.getGlobalInstance().setDirty(true);
	}
	@Override
	protected boolean model_rename(String newName) throws MactorException {
		if (!newName.endsWith(".xml"))
			newName = newName + ".xml";
		this.sourceFile = ProjectContext.getGlobalInstance().renameFile(sourceFile, newName);
		return true;
	}
	@Override
	protected String model_getName() {
		return sourceFile.getName();
	}
	@Override
	protected ProjectTreeNode copy() throws MactorException {
		try {
			File newFile = ProjectContext.getGlobalInstance().duplicateFile(sourceFile);
			XmlProjectTreeNode newNode = buildFromDocument(newFile, new SAXReader().read(new FileReader(newFile)), super.nodeTypeDictionary, isConfigFile);
			if (ProjectNodeType.MBC_MESSAGE_BROKERS.equals(getNodeType()))
				ProjectContext.getGlobalInstance().setDirty(true);
			return newNode;
		} catch (IOException ioe) {
			throw new MactorException(ioe);
		} catch (DocumentException de) {
			throw new MactorException(de);
		}
	}
	@Override
	protected void model_save() throws MactorException {
		long newChecksum = computeChecksum(getModelElement().getDocument());
		if (newChecksum != checksum) {
			checksum = newChecksum;
			ProjectContext.getGlobalInstance().writeDocumentToFile(sourceFile, getModelElement().getDocument());
			if (ProjectNodeType.MBC_MESSAGE_BROKERS.equals(getNodeType()))
				ProjectContext.getGlobalInstance().setDirty(true);
		}
	}
	@Override
	protected void model_detatch() throws MactorException {
		ProjectContext.getGlobalInstance().deleteFile(sourceFile);
		if (ProjectNodeType.MBC_MESSAGE_BROKERS.equals(getNodeType()))
			ProjectContext.getGlobalInstance().setDirty(true);
	}
	private static long computeChecksum(Document doc) {
		CRC32 c = new CRC32();
		c.update(doc.asXML().getBytes());
		return c.getValue();
	}
}
