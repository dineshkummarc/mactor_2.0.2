/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import org.mactor.framework.MactorException;

public class ProjectModel implements TreeModel {
	ProjectTreeNode root;// = new
	// OrganizationProjectTreeNode(ProjectNodeType.PROJECT_ROOT);
	public ProjectModel(File projectPath) throws MactorException {
		if (projectPath == null)
			root = null;
		else
			root = ProjectTreeNodeBuilder.buildProjectTree();
	}
	public void reload(File projectPath) throws MactorException {
		root = ProjectTreeNodeBuilder.buildProjectTree();
		notifyTreeStructureChanged();
	}
	public Object getChild(Object node, int index) {
		return ((ProjectTreeNode) node).getChildNode(index);
	}
	public int getChildCount(Object node) {
		return ((ProjectTreeNode) node).getChildCount();
	}
	public int getIndexOfChild(Object node, Object child) {
		return ((ProjectTreeNode) node).getIndexOfChild((ProjectTreeNode) child);
	}
	public ProjectTreeNode getRoot() {
		return root;
	}
	public boolean isLeaf(Object node) {
		return ((ProjectTreeNode) node).getChildCount() == 0;
	}
	private void notifyTreeStructureChanged() {
		TreeModelEvent e = new TreeModelEvent(this, new Object[] { root });
		for (TreeModelListener l : listeners)
			l.treeStructureChanged(e);
	}
	public void notifyTreeStructureChanged(ProjectTreeNode node) {
		TreeModelEvent e = new TreeModelEvent(this, new Object[] { getPath(node) });
		for (TreeModelListener l : listeners)
			l.treeStructureChanged(e);
	}
	private void notifyTreeNodesChanged(Object[] path, int index, Object changedNode) {
		TreeModelEvent e = new TreeModelEvent(this, path, new int[] { index }, new Object[] { changedNode });
		for (TreeModelListener l : listeners)
			l.treeNodesChanged(e);
	}
	public void notifyNodeNameChanged(ProjectTreeNode tn) {
		int index = tn.getParentNode().getIndexOfChild(tn);
		notifyTreeNodesChanged(getPath(tn), index, tn);
	}
	/*
	 * private void notifyTreeNodeRemoved(Object[] path, int index, Object
	 * removedNode) { TreeModelEvent e = new TreeModelEvent(this, path, new
	 * int[] { index }, new Object[] { removedNode }); for (TreeModelListener l :
	 * listeners) l.treeNodesRemoved(e); }
	 */
	private void notifyTreeNodeInserted(Object[] path, int index, Object insertedNode) {
		TreeModelEvent e = new TreeModelEvent(this, path, new int[] { index }, new Object[] { insertedNode });
		for (TreeModelListener l : listeners)
			l.treeNodesInserted(e);
	}
	private void notifyTreeNodesRemoved(Object[] path, int index) {
		TreeModelEvent e = new TreeModelEvent(this, path, new int[] { index }, new Object[] { path[path.length - 1] });
		for (TreeModelListener l : listeners)
			l.treeNodesRemoved(e);
	}
	public static Object[] getPath(ProjectTreeNode node) {
		LinkedList<ProjectTreeNode> path = new LinkedList<ProjectTreeNode>();
		while (node != null) {
			path.addFirst(node);
			node = node.getParentNode();
		}
		return path.toArray();
	}
	public void moveAfter(ProjectTreeNode destNode, ProjectTreeNode nodeToMove) throws MactorException {
		Object[] path = getPath(nodeToMove.getParentNode());
		int index = nodeToMove.getParentNode().getIndexOfChild(nodeToMove);
		nodeToMove.getParentNode().removeChild(nodeToMove);
		notifyTreeNodesRemoved(path, index);
		ProjectTreeNode copyOfNodeToMove = nodeToMove.copy();
		destNode.getParentNode().addChildAfter(destNode, copyOfNodeToMove);
		index = copyOfNodeToMove.getParentNode().getIndexOfChild(copyOfNodeToMove);
		notifyTreeNodeInserted(getPath(destNode.getParentNode()), index, copyOfNodeToMove);
	}
	public void delete(ProjectTreeNode node) throws MactorException {
		int index = node.getParentNode().getIndexOfChild(node);
		node.getParentNode().removeChild(node);
		notifyTreeNodesRemoved(getPath(node.getParentNode()), index);
	}
	public void insertAfter(ProjectTreeNode destNode, ProjectTreeNode nodeToInsert) throws MactorException {
		destNode.getParentNode().addChildAfter(destNode, nodeToInsert);
		int index = nodeToInsert.getParentNode().getIndexOfChild(nodeToInsert);
		notifyTreeNodeInserted(getPath(destNode.getParentNode()), index, nodeToInsert);
	}
	public void copyAfter(ProjectTreeNode destNode, ProjectTreeNode nodeToCopy) throws MactorException {
		nodeToCopy = nodeToCopy.copy();
		destNode.getParentNode().addChildAfter(destNode, nodeToCopy);
		int index = nodeToCopy.getParentNode().getIndexOfChild(nodeToCopy);
		notifyTreeNodeInserted(getPath(destNode.getParentNode()), index, nodeToCopy);
	}
	public void moveInto(ProjectTreeNode destNode, ProjectTreeNode nodeToMove) throws MactorException {
		Object[] path = getPath(nodeToMove.getParentNode());
		int index = nodeToMove.getParentNode().getIndexOfChild(nodeToMove);
		nodeToMove.getParentNode().removeChild(nodeToMove);
		notifyTreeNodesRemoved(path, index);
		ProjectTreeNode copyOfNodeToMove = nodeToMove.copy();
		destNode.addChild(copyOfNodeToMove);
		index = copyOfNodeToMove.getParentNode().getIndexOfChild(copyOfNodeToMove);
		notifyTreeNodeInserted(getPath(destNode), index, copyOfNodeToMove);
	}
	public void insertInto(ProjectTreeNode destNode, ProjectTreeNode nodeToInsert) throws MactorException {
		destNode.addChild(nodeToInsert);
		int index = nodeToInsert.getParentNode().getIndexOfChild(nodeToInsert);
		notifyTreeNodeInserted(getPath(destNode), index, nodeToInsert);
	}
	public void copyInto(ProjectTreeNode destNode, ProjectTreeNode nodeToCopy) throws MactorException {
		nodeToCopy = nodeToCopy.copy();
		destNode.addChildAfter(destNode, nodeToCopy);
		int index = nodeToCopy.getParentNode().getIndexOfChild(nodeToCopy);
		notifyTreeNodeInserted(getPath(destNode), index, nodeToCopy);
	}
	List<TreeModelListener> listeners = new LinkedList<TreeModelListener>();
	public void addTreeModelListener(TreeModelListener listener) {
		listeners.add(listener);
	}
	public void removeTreeModelListener(TreeModelListener listener) {
		listeners.remove(listener);
	}
	public void valueForPathChanged(TreePath path, Object node) {
		if (path != null) {
			ProjectTreeNode tn = (ProjectTreeNode) path.getLastPathComponent();
			try {
				if (tn.rename((String) node)) {
					int index = tn.getParentNode().getIndexOfChild(tn);
					notifyTreeNodesChanged(getPath(tn), index, tn);
				}
			} catch (MactorException me) {
				me.printStackTrace();
			}
		}
	}
}
