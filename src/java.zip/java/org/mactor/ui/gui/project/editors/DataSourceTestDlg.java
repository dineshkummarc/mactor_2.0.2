/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.framework.data.DataProviderFactory;
import org.mactor.framework.data.DataTable;
import org.mactor.ui.gui.GuiUtil;

public class DataSourceTestDlg extends JDialog {
	JTable table = new JTable();
	JLabel messageLabel = new JLabel("Press \"Load Data\" to verif that data can be read from the specified data source");
	Element commandElement;
	JButton okButton = new JButton(new AbstractAction("Ok") {
		public void actionPerformed(ActionEvent arg0) {
			dispose();
		};
	});
	JButton loadButton = new JButton(new AbstractAction("Load Data") {
		public void actionPerformed(ActionEvent arg0) {
			try {
				DataTable data = DataProviderFactory.getDataProvider(commandElement.attributeValue("data_source")).loadData();
				if (data == null) {
					table.setModel(new DefaultTableModel());
					messageLabel.setVisible(true);
					messageLabel.setText("The data source specification is OK, but no data was found");
				} else {
					table.setVisible(true);
					messageLabel.setVisible(false);
					table.setModel(new TestResultTableModel(data));
				}
			} catch (MactorException me) {
				GuiUtil.showGuiError(DataSourceTestDlg.this, me);
			}
		};
	});
	private String evaluateCommand() {
		return null;
	}
	public DataSourceTestDlg(Frame parent, Element commandElement) throws MactorException {
		super(parent);
		setLayout(new BorderLayout());
		setModal(true);
		setTitle("Test Data Source");
		this.commandElement = commandElement;
		SimpleFormPanel form = new SimpleFormPanel();
		JPanel bp = new JPanel(new FlowLayout());
		bp.add(loadButton);
		form.add(bp);
		SimpleFormPanel resultForm = new SimpleFormPanel();
		resultForm.add(new JLabel("Data:"));
		resultForm.add(new JScrollPane(table));
		resultForm.add(messageLabel);
		form.add(resultForm);
		add(form, BorderLayout.CENTER);
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(okButton);
		add(buttonPanel, BorderLayout.SOUTH);
		pack();
	}
	private class TestResultTableModel extends AbstractTableModel {
		private int columnCount = 0;
		private DataTable data;
		public TestResultTableModel(DataTable data) {
			this.columnCount = data.getColumnCount();
			this.data = data;
		}
		@Override
		public String getColumnName(int index) {
			return data.getColumn(index);
		}
		public int getColumnCount() {
			return columnCount;
		}
		public int getRowCount() {
			return data.getRowCount();
		}
		@Override
		public Class<?> getColumnClass(int arg0) {
			return String.class;
		}
		public Object getValueAt(int row, int col) {
			return data.getValue(row, col);
		}
	}
}
