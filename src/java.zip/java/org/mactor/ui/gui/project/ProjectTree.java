/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.awt.Color;
import java.awt.Component;
import java.awt.Point;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceAdapter;
import java.awt.dnd.DragSourceContext;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.TransferHandler;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreePath;

import org.mactor.framework.MactorException;
import org.mactor.ui.gui.GuiUtil;

public class ProjectTree extends JTree {
	DragSource dragSource;
	DragSourceContext dragSourceContext;
	ProjectTreeNode draggedNode;
	ProjectTreeNode currentDragOverNode;
	int currentDragRow = -1;
	boolean dropUnder;
	boolean dropInto;
	Point currentDragLocation;
	private static Transferable dummy = new StringSelection("");
	private DragSourceListener dragSourceListener = new DragSourceAdapter() {
		public void dragEnter(DragSourceDragEvent event) {
			dragSourceContext = event.getDragSourceContext();
		}
		@Override
		public void dragDropEnd(DragSourceDropEvent arg0) {
			super.dragDropEnd(arg0);
			clearDragInfo();
		}
	};
	private void clearDragInfo() {
		draggedNode = null;
		dragSourceContext = null;
		currentDragRow = -1;
		currentDragLocation = null;
		currentDragOverNode = null;
		dropInto = false;
		dropUnder = false;
		repaint();
	}
	DragGestureListener dragGestureListener = new DragGestureListener() {
		public void dragGestureRecognized(DragGestureEvent event) {
			TreePath path = getSelectionPath();
			if (path != null) {
				draggedNode = (ProjectTreeNode) path.getLastPathComponent();
				dragSource.startDrag(event, DragSource.DefaultMoveDrop, dummy, dragSourceListener);
			}
		}
	};
	public ProjectTree(ProjectModel model) {
		super(model);
		setDropTarget(new DropTarget(this, new ProjectTreeDropListener()));
		setCellRenderer(new ProjectTreeCellRenderer());
		dragSource = DragSource.getDefaultDragSource();
		dragSource.createDefaultDragGestureRecognizer(this, DnDConstants.ACTION_COPY_OR_MOVE, dragGestureListener);
	}
	class ProjectTreeCellRenderer extends DefaultTreeCellRenderer {
		private final Icon INCOMING_ICON = GuiUtil.loadIcon("/incoming_16.PNG");
		private final Icon SUBSCR_ICON = GuiUtil.loadIcon("/subscribe_16.PNG");
		private final Icon CONDITION_ICON = GuiUtil.loadIcon("/condition_16.PNG");
		private final Icon LOOP_ICON = GuiUtil.loadIcon("/loop_16.PNG");
		private final Icon ACTION_ICON = GuiUtil.loadIcon("/action_16.PNG");
		private final Icon VALUE_EXTRACT_ICON = GuiUtil.loadIcon("/value_extract_16.PNG");
		private final Icon OUTGOING_ICON = GuiUtil.loadIcon("/outgoing_16.PNG");
		private final Icon OUTGOING_RESP_ICON = GuiUtil.loadIcon("/outgoing_resp_16.PNG");
		private Border dropUnderBorder = BorderFactory.createMatteBorder(0, 0, 2, 0, Color.BLUE);
		private Border dropInsideBorder = new LineBorder(Color.BLUE, 2);
		private Border noDrop = BorderFactory.createEmptyBorder(0, 0, 2, 0);
		public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean focus) {
			Component com = super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, focus);
			if (row == currentDragRow) {
				if ((dropUnder)) {
					((JLabel) com).setBorder(dropUnderBorder);
				} else if (dropInto) {
					((JLabel) com).setBorder(dropInsideBorder);
				} else {
					((JLabel) com).setBorder(noDrop);
				}
			} else {
				((JLabel) com).setBorder(noDrop);
			}
			ProjectTreeNode node = (ProjectTreeNode) value;
			if (node != null) {
				if (ProjectNodeType.T_MESSAGE_PUBLISH.equals(node.getNodeType()))
					setIcon(OUTGOING_ICON);
				else if (ProjectNodeType.T_MESSAGE_RECEIVE.equals(node.getNodeType()))
					setIcon(INCOMING_ICON);
				else if (ProjectNodeType.T_MESSAGE_RESPOND.equals(node.getNodeType()))
					setIcon(OUTGOING_RESP_ICON);
				else if (ProjectNodeType.T_MESSAGE_SUBSCRIBE.equals(node.getNodeType()))
					setIcon(SUBSCR_ICON);
				else if (ProjectNodeType.T_CONDITION.equals(node.getNodeType()))
					setIcon(CONDITION_ICON);
				else if (ProjectNodeType.T_LOOP.equals(node.getNodeType()))
					setIcon(LOOP_ICON);
				else if (ProjectNodeType.T_ACTION.equals(node.getNodeType()))
					setIcon(ACTION_ICON);
				else if (ProjectNodeType.T_VALUE.equals(node.getNodeType()))
					setIcon(VALUE_EXTRACT_ICON);
			}
			return com;
		}
	}
	class ProjectTreeDropListener extends DropTargetAdapter {
		@Override
		public void dragOver(DropTargetDragEvent event) {
			dropInto = false;
			dropUnder = false;
			currentDragOverNode = null;
			DropAcceptRules.DropAcceptInfo dropAcceptInfo = null;
			boolean move = true;
			if (dragSourceContext != null) {
				if (event.getDropAction() == TransferHandler.MOVE)
					dragSourceContext.setCursor(DragSource.DefaultMoveDrop);
				else {
					move = false;
					dragSourceContext.setCursor(DragSource.DefaultCopyDrop);
				}
			}
			TreePath path = getPathForLocation(event.getLocation().x, event.getLocation().y);
			if (path != null) {
				currentDragOverNode = (ProjectTreeNode) path.getLastPathComponent();
				currentDragLocation = event.getLocation();
				currentDragRow = getRowForLocation(currentDragLocation.x, currentDragLocation.y);
				dropUnder = getRowForLocation(currentDragLocation.x, currentDragLocation.y + 6) != currentDragRow;
				dropAcceptInfo = DropAcceptRules.getDropAcceptInfo(currentDragOverNode, draggedNode);
				if (dropUnder) {
					if (move)
						dropUnder = dropAcceptInfo.isMoveAsideAccepted();
					else
						dropUnder = dropAcceptInfo.isCopyAsideAccepted();
				} else {
					if (move)
						dropInto = dropAcceptInfo.isMoveIntoAccepted();
					else
						dropInto = dropAcceptInfo.isCopyIntoAccepted();
				}
				if (dragSourceContext != null) {
					if (!dropInto && !dropUnder)
						dragSourceContext.setCursor(DragSource.DefaultLinkNoDrop);
				}
			} else {
				dropAcceptInfo = null;
				event.rejectDrag();
			}
			repaint();
		}
		public void drop(DropTargetDropEvent event) {
			try {
				if (currentDragOverNode != null && draggedNode != null && dragSourceContext != null) {
					boolean move = (event.getDropAction() == TransferHandler.MOVE);
					if (dropUnder) {
						if (move) {
							((ProjectModel) getModel()).moveAfter(currentDragOverNode, draggedNode);
						} else {
							((ProjectModel) getModel()).copyAfter(currentDragOverNode, draggedNode);
						}
					} else if (dropInto) {
						if (move) {
							((ProjectModel) getModel()).moveInto(currentDragOverNode, draggedNode);
						} else {
							((ProjectModel) getModel()).copyInto(currentDragOverNode, draggedNode);
						}
					}
				}
			} catch (MactorException me) {
				me.printStackTrace();
			}
		}
	}
}
