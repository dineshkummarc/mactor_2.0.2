/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.ui.gui.AsyncAction;
import org.mactor.ui.gui.project.editors.FileNodeComboBox;
import org.mactor.ui.gui.project.editors.ProjectInternalDirSelector;
import org.mactor.ui.gui.project.editors.SimpleFormPanel;

public class ProjectSettingsDlg extends JDialog {
	ProjectSettingsPanel pp;
	JButton okButton = new JButton(new AsyncAction("Ok", false, new AsyncAction.AsyncRunnable() {
		public void run() throws MactorException {
			pp.saveSettings();
			dispose();
		}
	}));
	JButton cancelButton = new JButton(new AbstractAction("Cancel") {
		public void actionPerformed(ActionEvent arg0) {
			dispose();
		};
	});
	public ProjectSettingsDlg(ProjectController projectController) throws IOException {
		super(projectController.getControllerFrame());
		setModal(true);
		setLayout(new BorderLayout());
		setTitle("Project Settings");
		this.pp = new ProjectSettingsPanel(projectController);
		add(pp, BorderLayout.CENTER);
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(okButton);
		buttonPanel.add(cancelButton);
		add(buttonPanel, BorderLayout.SOUTH);
		pack();
		setResizable(false);
	}
	static class ProjectSettingsPanel extends JPanel {
		File configDir;
		ProjectInternalDirSelector configDirSel = new ProjectInternalDirSelector();
		FileNodeComboBox gcList = new FileNodeComboBox(ProjectNodeType.G_GLOBAL_CONFIG);
		FileNodeComboBox mbList = new FileNodeComboBox(ProjectNodeType.MBC_MESSAGE_BROKERS);
		private boolean settingChanged = false;
		ProjectController projectController;
		public ProjectSettingsPanel(ProjectController projectController) {
			super(new BorderLayout());
			setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			this.projectController = projectController;
			SimpleFormPanel form = new SimpleFormPanel();
			form.add(new JLabel("Project Config Directory:"));
			form.add(configDirSel);
			form.add(new JLabel("Current Global Config:"));
			form.add(gcList);
			form.add(new JLabel("Current Message Broker Config:"));
			form.add(mbList);
			add(form, BorderLayout.WEST);
			configDir = ProjectContext.getGlobalInstance().getProjectConfigDir();
			loadSettings();
		}
		public void loadSettings() {
			gcList.setConfig(projectController.getProjectModel().getRoot());
			gcList.setSelectedName(ProjectContext.getGlobalInstance().getGlobalConfigName());
			mbList.setConfig(projectController.getProjectModel().getRoot());
			mbList.setSelectedName(ProjectContext.getGlobalInstance().getMessageBrokerConfigName());
			configDirSel.setPath(ProjectContext.getGlobalInstance().getProjectConfigDir());
		}
		public void saveSettings() throws MactorException {
			ProjectContext.getGlobalInstance().setProjectConfigDir(ProjectContext.getGlobalInstance().getAbsolutePath(configDirSel.getPath()));
			ProjectContext.getGlobalInstance().setMessageBrokerConfigName(mbList.getSelectedName());
			ProjectContext.getGlobalInstance().setGlobalConfigName(gcList.getSelectedName());
			// if
			// (!configDir.equals(ProjectContext.getGlobalInstance().getProjectConfigDir()))
			projectController.reloadProject();
		}
	}
}
