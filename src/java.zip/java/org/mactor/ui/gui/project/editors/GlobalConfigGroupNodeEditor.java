/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.framework.data.jdbc.JdbcUtil;
import org.mactor.framework.spec.GlobalConfig.Group;
import org.mactor.ui.gui.AsyncAction;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class GlobalConfigGroupNodeEditor extends AbstractNodeEditor {
	Element data;
	JTextField sql = new JTextField("select 1 from dual", 30);
	JTextArea out = new JTextArea(10, 60);
	SimpleRowPanel dbTestPanel = new SimpleRowPanel();
	JButton testDBConnection = new JButton(new AsyncAction("Test DB Connection", false, new AsyncAction.AsyncRunnable() {
		public void run() {
			try {
				Group g = Group.loadGroup(data);
				JdbcUtil util = new JdbcUtil(g.getRequieredValue("driver"), g.getRequieredValue("url"), g.getRequieredValue("username"), g.getRequieredValue("password"));
				util.execSingleCellQuerySql(sql.getText());
				out.setText("OK");
			} catch (Exception e) {
				out.setText("Failed with:" + e.getMessage());
			}
		};
	}));
	public GlobalConfigGroupNodeEditor() {
		super(new BorderLayout());
		JPanel bp = new JPanel(new BorderLayout());
		dbTestPanel.add(new JLabel("Test SQL:"));
		dbTestPanel.add(sql);
		dbTestPanel.add(testDBConnection);
		bp.add(dbTestPanel, BorderLayout.WEST);
		add(bp, BorderLayout.NORTH);
		out.setEditable(false);
		out.setBackground(getBackground());
		out.setBorder(BorderFactory.createEmptyBorder());
		out.setWrapStyleWord(true);
		add(out, BorderLayout.CENTER);
	}
	public void applyChanges() {
	}
	public void setConfig(NodeEditorConfig config) throws MactorException {
	}
	public void setData(ProjectTreeNode node) throws MactorException {
		this.data = (Element) node.getModelObject();
		boolean isDbG = EditorUtil.isGlobalConfigDBGroupElement(data);
		out.setVisible(isDbG);
		dbTestPanel.setVisible(isDbG);
	}
}
