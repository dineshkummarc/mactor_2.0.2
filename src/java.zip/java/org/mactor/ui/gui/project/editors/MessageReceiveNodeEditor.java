/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.FlowLayout;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class MessageReceiveNodeEditor extends AbstractNodeEditor {
	JTextField minMessageCountText = new JTextField(5);
	JTextField maxMessageCountText = new JTextField(5);
	JTextField maxTimeoutSecondsText = new JTextField(5);
	JCheckBox blockUntilTimeout = new JCheckBox("Block Until Timeout");
	MessageSubscribersComboBox msCb = new MessageSubscribersComboBox();
	Element data;
	public MessageReceiveNodeEditor() {
		super(new FlowLayout());
		SimpleFormPanel box = new SimpleFormPanel();
		box.add(new JLabel("Message Subscriber:"));
		box.add(msCb);
		box.add(new JLabel("Min Message Count:"));
		box.add(minMessageCountText);
		box.add(new JLabel("Max Message Count:"));
		box.add(maxMessageCountText);
		box.add(new JLabel("Timeout (seconds):"));
		box.add(maxTimeoutSecondsText);
		box.add(blockUntilTimeout);
		add(box);
	}
	public void applyChanges() {
		EditorUtil.setAttributeValue(data, "message_subscribe_node_name", msCb.getSelectedMessageSubscriber());
		EditorUtil.setAttributeValue(data, "min_message_count", minMessageCountText.getText());
		EditorUtil.setAttributeValue(data, "max_message_count", maxMessageCountText.getText());
		EditorUtil.setAttributeValue(data, "max_timeout_seconds", maxTimeoutSecondsText.getText());
		EditorUtil.setAttributeValue(data, "block_until_timeout", blockUntilTimeout.isSelected() + "");
	}
	public void setData(ProjectTreeNode node) throws MactorException {
		this.data = (Element) node.getModelObject();
		msCb.setConfig(this.data);
		minMessageCountText.setText(EditorUtil.getAttributeValue(this.data, "min_message_count"));
		maxMessageCountText.setText(EditorUtil.getAttributeValue(this.data, "max_message_count"));
		maxTimeoutSecondsText.setText(EditorUtil.getAttributeValue(this.data, "max_timeout_seconds"));
		blockUntilTimeout.setSelected(Boolean.parseBoolean(EditorUtil.getAttributeValue(this.data, "block_until_timeout")));
		msCb.setSelectedMessageSubscriber(this.data.attributeValue("message_subscribe_node_name"));
	}
	public void setConfig(NodeEditorConfig config) {
	}
}
