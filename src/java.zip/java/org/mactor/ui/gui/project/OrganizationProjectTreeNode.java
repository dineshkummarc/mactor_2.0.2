/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import org.mactor.framework.MactorException;

public class OrganizationProjectTreeNode extends ProjectTreeNode {
	String name;
	public OrganizationProjectTreeNode(ProjectNodeType type, String name) {
		super(type);
		this.name = name;
	}
	public OrganizationProjectTreeNode(ProjectNodeType type) {
		super(type);
		this.name = type.name();
	}
	@Override
	public String getCaption() {
		return name;
	}
	@Override
	protected String model_getName() {
		return name;
	}
	// Throw UnsupportedOperationException for the rest
	@Override
	protected ProjectTreeNode copy() throws MactorException {
		throw new UnsupportedOperationException();
	}
	@Override
	protected void model_delete() throws MactorException {
		// nothing todo
	}
	@Override
	protected void model_detatch() {
		throw new UnsupportedOperationException();
	}
	@Override
	protected void model_insert_child(int index, Object newChild) {
		// nothing todo
	}
	@Override
	protected void model_remove_child(int index) {
		// nothing todo
	}
	@Override
	protected boolean model_rename(String newName) throws MactorException {
		return false;
	}
	@Override
	protected void model_save() throws MactorException {
		// nothing todo
	}
}
