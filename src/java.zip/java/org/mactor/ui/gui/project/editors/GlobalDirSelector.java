/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JTextField;

import org.mactor.framework.spec.ProjectContext;

public class GlobalDirSelector extends SimpleRowPanel {
	JTextField path = new JTextField(30);
	static JFileChooser fc = new JFileChooser(ProjectContext.getGlobalInstance().getProjectDir());
	JButton selectButton = new JButton(new AbstractAction("Select..") {
		public void actionPerformed(ActionEvent e) {
			int returnVal = fc.showOpenDialog(GlobalDirSelector.this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File f = fc.getSelectedFile();
				path.setText(f.getAbsolutePath());
			}
		}
	});
	public GlobalDirSelector() {
		add(path);
		add(selectButton);
		fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	}
	public String getPath() {
		return path.getText();
	}
	public void setPath(String path) {
		if (path != null && path.length() > 0)
			fc.setSelectedFile(new File(path).getAbsoluteFile());
		this.path.setText(path);
	}
}
