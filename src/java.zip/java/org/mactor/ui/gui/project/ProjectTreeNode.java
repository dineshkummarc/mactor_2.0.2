/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.util.ArrayList;
import java.util.List;

import org.mactor.framework.MactorException;

public abstract class ProjectTreeNode {
	protected ProjectNodeType nodeType;
	protected ArrayList<ProjectTreeNode> childNodes = new ArrayList<ProjectTreeNode>();
	protected ProjectTreeNode parentNode;
	protected Object modelObject;
	protected ProjectTreeNode(ProjectNodeType nodeType) {
		this.nodeType = nodeType;
	}
	public ProjectTreeNode(ProjectNodeType nodeType, Object modelObject) {
		this.nodeType = nodeType;
		this.modelObject = modelObject;
	}
	public String getName() {
		if (modelObject == null)
			return nodeType.name();
		return model_getName();
	}
	public String getCaption() {
		return getName();
	}
	public List<ProjectTreeNode> getChildNodes() {
		return childNodes;
	}
	public Object getModelObject() {
		return modelObject;
	}
	public ProjectNodeType getNodeType() {
		return nodeType;
	}
	public ProjectTreeNode getParentNode() {
		return parentNode;
	}
	public ProjectTreeNode getChildNode(int index) {
		return childNodes.get(index);
	}
	public void detach() throws MactorException {
		model_detatch();
	}
	public void removeChild(ProjectTreeNode child) throws MactorException {
		int index = childNodes.indexOf(child);
		childNodes.remove(child);
		model_remove_child(index);
		child.model_detatch();
		model_save();
	}
	public void addChild(ProjectTreeNode newChild) throws MactorException {
		newChild.setParentNode(this);
		childNodes.add(0, newChild);
		model_insert_child(0, newChild.getModelObject());
		model_save();
	}
	public void addChildAfter(ProjectTreeNode node, ProjectTreeNode newChild) throws MactorException {
		newChild.setParentNode(this);
		int index = childNodes.indexOf(node);
		childNodes.add(index + 1, newChild);
		model_insert_child(index + 1, newChild.getModelObject());
		model_save();
	}
	public boolean rename(String newName) throws MactorException {
		if (model_rename(newName)) {
			model_save();
			return true;
		}
		return false;
	}
	public void save() throws MactorException {
		model_save();
	}
	public int getIndexOfChild(ProjectTreeNode child) {
		return childNodes.indexOf(child);
	}
	public int getChildCount() {
		return childNodes.size();
	}
	private void setParentNode(ProjectTreeNode parentNode) {
		this.parentNode = parentNode;
	}
	@Override
	public String toString() {
		return getCaption();
	}
	protected abstract ProjectTreeNode copy() throws MactorException;
	protected abstract void model_remove_child(int index);
	protected abstract void model_insert_child(int index, Object newChild);
	protected abstract void model_delete() throws MactorException;
	protected abstract void model_detatch() throws MactorException;
	protected abstract boolean model_rename(String newName) throws MactorException;
	protected abstract String model_getName();
	protected abstract void model_save() throws MactorException;
}
