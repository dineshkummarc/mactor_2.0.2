/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;

import org.mactor.extensions.xml.ParamUtil;

public class CommandPrototypeComboBox extends MactorComboBox {
	ArrayList<NodeEditorConfig.CommandPrototype> protos;
	TipListener tipListener;
	ProtoListener protoListener;
	public void setTipListener(TipListener tipListener) {
		this.tipListener = tipListener;
	}
	ActionListener tl = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			int index = getSelectedIndex();
			if (protos != null && index > 0 && index - 1 < protos.size()) {
				if (tipListener != null)
					tipListener.onTip(3, protos.get(index - 1).getTip());
				if (protoListener != null && e.getSource() == CommandPrototypeComboBox.this) {
					protoListener.protoSelected(protos.get(index - 1));
				}
			} else {
				if (tipListener != null)
					tipListener.onTip(3, null);
				if (protoListener != null)
					protoListener.protoSelected(null);
			}
		}
	};
	public CommandPrototypeComboBox() {
		addItem(null);
		setAlignmentX(Component.LEFT_ALIGNMENT);
		addActionListener(tl);
		// addItemListener(il);
	}
	public void setConfig(Collection<NodeEditorConfig.CommandPrototype> protos) {
		if (protos != null)
			this.protos = new ArrayList<NodeEditorConfig.CommandPrototype>(protos);
		else
			this.protos = new ArrayList<NodeEditorConfig.CommandPrototype>();
		removeAllItems();
		addItem(null);
		setEditable(true);
		if (protos == null)
			return;
		for (NodeEditorConfig.CommandPrototype proto : protos) {
			addItem(proto.getName());
		}
	}
	public String getSelectedPrototype() {
		return getText();
	}
	public void setSelectedPrototype(String proto) {
		if (ParamUtil.isEqual(proto, getText()))
			return;
		int count = getItemCount();
		if (proto == null || proto.trim().length() == 0) {
			setSelectedIndex(0);
			return;
		}
		for (int i = 1; i < count; i++) {
			String item = (String) getItemAt(i);
			if (item.equals(proto)) {
				setSelectedIndex(i);
				return;
			}
		}
		addItem(proto);
		setSelectedIndex(count);
	}
	public interface ProtoListener {
		void protoSelected(NodeEditorConfig.CommandPrototype proto);
	}
	public void setProtoListener(ProtoListener protoListener) {
		this.protoListener = protoListener;
	}
}
