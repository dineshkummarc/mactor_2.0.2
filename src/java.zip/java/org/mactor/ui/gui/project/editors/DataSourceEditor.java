/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.ui.gui.GuiUtil;

public class DataSourceEditor extends SimpleFormPanel {
	CommandPrototypeComboBox protoCb = new CommandPrototypeComboBox();
	CommandTypeComboBox typeCb = new CommandTypeComboBox();
	GlobalConfigDBGroupComboBox gcDbGroup = new GlobalConfigDBGroupComboBox();
	Element data;
	SimpleRowPanel dbPanel = new SimpleRowPanel();
	CsvPanel csvPanel = new CsvPanel();
	JButton test = new JButton(new AbstractAction("Test...") {
		public void actionPerformed(ActionEvent e) {
			try {
				applyListener.onApply();
				new DataSourceTestDlg(JOptionPane.getFrameForComponent(DataSourceEditor.this), data).setVisible(true);
			} catch (MactorException me) {
				GuiUtil.showGuiError(DataSourceEditor.this, me);
			}
		}
	});
	ItemListener typeCbListener = new ItemListener() {
		public void itemStateChanged(java.awt.event.ItemEvent e) {
			NodeEditorConfig.CommandType type = (NodeEditorConfig.CommandType) typeCb.getSelectedItem();
			String proto = protoCb.getSelectedPrototype();
			if (type != null) {
				protoCb.setConfig(type.getPrototypes());
				boolean showDbPanel = "sql".equalsIgnoreCase(type.getName());
				dbPanel.setVisible(showDbPanel);
				if (showDbPanel)
					gcDbGroup.load();
				csvPanel.setVisible("file".equalsIgnoreCase(type.getName()));
			} else {
				protoCb.setConfig(null);
				dbPanel.setVisible(false);
				csvPanel.setVisible(false);
			}
			protoCb.setSelectedPrototype(proto);
		};
	};
	public void setTipListener(TipListener tipListener) {
		protoCb.setTipListener(tipListener);
		typeCb.setTipListener(tipListener);
	}
	ApplyListener applyListener;
	public DataSourceEditor(String dataSourceCaption, ApplyListener applyListener) {
		this.applyListener = applyListener;
		add(new JLabel(dataSourceCaption));
		SimpleRowPanel panel = new SimpleRowPanel();
		panel.add(typeCb);
		dbPanel.add(new JLabel(":"));
		dbPanel.add(gcDbGroup);
		panel.add(dbPanel);
		panel.add(new JLabel(":"));
		panel.add(protoCb);
		panel.add(csvPanel);
		panel.add(test);
		add(panel);
		typeCb.addItemListener(typeCbListener);
	}
	public void applyChanges() {
		if (data.attribute("data_source") == null)
			data.addAttribute("data_source", "");
		if (dbPanel.isVisible())
			data.attribute("data_source").setValue(typeCb.getSelectedType() + ":" + gcDbGroup.getSelectedGroup() + ":" + protoCb.getSelectedPrototype());
		else
			data.attribute("data_source").setValue(typeCb.getSelectedType() + ":" + protoCb.getSelectedPrototype());
	}
	public void setData(Object data) throws MactorException {
		this.data = (Element) data;
		String command = this.data.attributeValue("data_source");
		String[] parts = null;
		if (command != null)
			parts = command.split(":");
		String type = null;
		String group = null;
		String proto = null;
		if (parts != null) {
			if (parts.length >= 1)
				type = parts[0];
			if (parts.length > 2) {
				proto = parts[2];
				group = parts[1];
			} else if (parts.length == 2)
				proto = parts[1];
		}
		typeCb.setSelectedType(type);
		gcDbGroup.setSelectedGroup(group);
		protoCb.setSelectedPrototype(proto);
		if (!"sql".equalsIgnoreCase(type))
			dbPanel.setVisible(false);
		;
	}
	public void setConfig(NodeEditorConfig config) {
		typeCb.setConfig(config.getCommandTypes());
	}
	private class CsvPanel extends SimpleRowPanel {
		JButton csvEdit = new JButton(new AbstractAction("Edit...") {
			public void actionPerformed(ActionEvent e) {
				applyListener.onApply();
				String name = protoCb.getSelectedPrototype();
				if (name != null && name.length() > 0) {
					File path = ProjectContext.getGlobalInstance().getAbsolutePath(name);
					if (!path.exists()) {
						if (JOptionPane.OK_OPTION != JOptionPane.showConfirmDialog(CsvPanel.this, "The file '" + name + "' does not exist. Create it?", "Create file", JOptionPane.OK_CANCEL_OPTION)) {
							return;
						}
						try {
							FileWriter fw = new FileWriter(path);
							fw.write("MyParam1;MyParam2\nval01;val02\nval11;val12");
							fw.close();
						} catch (IOException ioe) {
							GuiUtil.showGuiError(DataSourceEditor.this, ioe);
							return;
						}
					}
					new TextFileEditor(name, "Edit CSV File", "Tip: use a real editor").setVisible(true);
				}
			}
		});
		JFileChooser fc = new JFileChooser(ProjectContext.getGlobalInstance().getProjectDir());
		JButton selectButton = new JButton(new AbstractAction("Select..") {
			public void actionPerformed(ActionEvent e) {
				try {
					if (protoCb.getSelectedPrototype() != null && protoCb.getSelectedPrototype().toLowerCase().endsWith(".csv"))
						fc.setSelectedFile(ProjectContext.getGlobalInstance().getAbsolutePath(protoCb.getSelectedPrototype()));
					fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
					int returnVal = fc.showOpenDialog(DataSourceEditor.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File f = fc.getSelectedFile();
						if (!f.getName().toLowerCase().endsWith(".csv"))
							f = new File(f.getAbsolutePath() + ".csv");
						f.createNewFile();
						protoCb.setSelectedPrototype(ProjectContext.getGlobalInstance().getRelativePath(f));
					}
				} catch (IOException ioe) {
					GuiUtil.showGuiError(DataSourceEditor.this, ioe);
				}
			}
		});
		public CsvPanel() {
			add(selectButton);
			add(csvEdit);
		}
	}
}