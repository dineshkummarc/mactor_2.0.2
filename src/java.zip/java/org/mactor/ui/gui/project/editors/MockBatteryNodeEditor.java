/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JTextField;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class MockBatteryNodeEditor extends AbstractNodeEditor {
	Element data;
	JTextField threadText = new JTextField(5);
	public MockBatteryNodeEditor() {
		super(new FlowLayout());
		SimpleFormPanel form = new SimpleFormPanel();
		form.add(new JLabel("Number of Test Threads:"));
		form.add(threadText);
		add(form);
	}
	public void applyChanges() {
		int tc = 20;
		try {
			tc = Integer.parseInt(threadText.getText());
		} catch (Exception e) {
		}
		EditorUtil.setAttributeValue(data, "test_threads", tc + "");
	}
	public void setData(ProjectTreeNode node) throws MactorException {
		this.data = (Element) node.getModelObject();
		threadText.setText(EditorUtil.getAttributeValue(data, "test_threads"));
	}
	public void setConfig(NodeEditorConfig config) {
	}
}
