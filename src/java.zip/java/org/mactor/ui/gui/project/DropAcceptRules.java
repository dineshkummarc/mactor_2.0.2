/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class DropAcceptRules {
	private static Map<ProjectNodeType, Set<ProjectNodeType>> rulesMap = buildAcceptInfoMap();
	private static Map<ProjectNodeType, Set<ProjectNodeType>> buildAcceptInfoMap() {
		Map<ProjectNodeType, Set<ProjectNodeType>> map = new HashMap<ProjectNodeType, Set<ProjectNodeType>>();
		// Global config
		map.put(ProjectNodeType.PROJECT_GLOBAL_CONFIG, toSet(new ProjectNodeType[] { ProjectNodeType.G_GLOBAL_CONFIG }));
		map.put(ProjectNodeType.G_GLOBAL_CONFIG, toSet(new ProjectNodeType[] { ProjectNodeType.G_GROUP, ProjectNodeType.VALUE }));
		map.put(ProjectNodeType.G_GROUP, toSet(new ProjectNodeType[] { ProjectNodeType.VALUE }));
		// Message broker config
		map.put(ProjectNodeType.PROJECT_MESSAGE_BROKER_CONFIG, toSet(new ProjectNodeType[] { ProjectNodeType.MBC_MESSAGE_BROKERS }));
		map.put(ProjectNodeType.MBC_MESSAGE_BROKERS, toSet(new ProjectNodeType[] { ProjectNodeType.MBC_MESSAGE_BROKER }));
		map.put(ProjectNodeType.MBC_MESSAGE_BROKER, toSet(new ProjectNodeType[] { ProjectNodeType.MBC_CHANNEL, ProjectNodeType.VALUE }));
		map.put(ProjectNodeType.MBC_CHANNEL, toSet(new ProjectNodeType[] { ProjectNodeType.VALUE }));
		// Test
		map.put(ProjectNodeType.PROJECT_TEST, toSet(new ProjectNodeType[] { ProjectNodeType.T_TEST }));
		Set<ProjectNodeType> testContainerNode = toSet(new ProjectNodeType[] { ProjectNodeType.T_ACTION, ProjectNodeType.T_CONDITION, ProjectNodeType.T_EVENT_CHOICE, ProjectNodeType.T_LOOP,
				ProjectNodeType.T_MESSAGE_PUBLISH, ProjectNodeType.T_MESSAGE_RECEIVE, ProjectNodeType.T_MESSAGE_SUBSCRIBE, ProjectNodeType.T_VALUE });
		map.put(ProjectNodeType.T_TEST, testContainerNode);
		map.put(ProjectNodeType.T_CONDITION, testContainerNode);
		// map.put(ProjectNodeType.T_EVENT_CHOICE_BRANCH, testContainerNode);
		map.put(ProjectNodeType.T_LOOP, testContainerNode);
		Set<ProjectNodeType> mrSet = new HashSet<ProjectNodeType>(testContainerNode);
		mrSet.add(ProjectNodeType.T_MESSAGE_RESPOND);
		map.put(ProjectNodeType.T_MESSAGE_RECEIVE, mrSet);
		// map.put(ProjectNodeType.T_EVENT_CHOICE, toSet(new ProjectNodeType[] {
		// ProjectNodeType.T_EVENT_CHOICE_BRANCH }));
		// Mock Battery
		map.put(ProjectNodeType.PROJECT_MOCK_BATTERY, toSet(new ProjectNodeType[] { ProjectNodeType.TM_MOCK_BATTERY }));
		map.put(ProjectNodeType.TM_MOCK_BATTERY, toSet(new ProjectNodeType[] { ProjectNodeType.TM_TEST }));
		// Test Data
		map.put(ProjectNodeType.PROJECT_TEST_RUN, toSet(new ProjectNodeType[] { ProjectNodeType.TR_TEST_RUN }));
		map.put(ProjectNodeType.TR_TEST_RUN, toSet(new ProjectNodeType[] {}));
		return map;
	}
	private static Set<ProjectNodeType> toSet(ProjectNodeType[] types) {
		Set<ProjectNodeType> s = new HashSet<ProjectNodeType>();
		for (ProjectNodeType t : types)
			s.add(t);
		return s;
	}
	public static DropAcceptInfo getDropAcceptInfo(ProjectTreeNode node, ProjectNodeType nodeTypeToDrop) {
		DropAcceptInfo dai = new DropAcceptInfo();
		if (nodeTypeToDrop != null && node != null) {
			if (node.getParentNode() != null) {
				dai.acceptCopyAside = rulesMap.containsKey(node.getParentNode().getNodeType()) && rulesMap.get(node.getParentNode().getNodeType()).contains(nodeTypeToDrop);
				// special rule for file nodes:
				dai.acceptMoveAside = dai.acceptCopyAside && !(node.getParentNode() instanceof OrganizationProjectTreeNode);
			}
			dai.acceptCopyInto = rulesMap.containsKey(node.getNodeType()) && rulesMap.get(node.getNodeType()).contains(nodeTypeToDrop);
			dai.acceptMoveInto = dai.acceptCopyInto && !(node instanceof OrganizationProjectTreeNode);
		}
		return dai;
	}
	public static DropAcceptInfo getDropAcceptInfo(ProjectTreeNode node, ProjectTreeNode nodeToDrop) {
		DropAcceptInfo dai = new DropAcceptInfo();
		if (nodeToDrop != null && node != null) {
			if (node.getParentNode() != null) {
				dai.acceptCopyAside = rulesMap.containsKey(node.getParentNode().getNodeType()) && rulesMap.get(node.getParentNode().getNodeType()).contains(nodeToDrop.getNodeType());
				// special rule for file nodes:
				dai.acceptMoveAside = dai.acceptCopyAside && !(node.getParentNode() instanceof OrganizationProjectTreeNode);
			}
			dai.acceptCopyInto = rulesMap.containsKey(node.getNodeType()) && rulesMap.get(node.getNodeType()).contains(nodeToDrop.getNodeType());
			dai.acceptMoveInto = dai.acceptCopyInto && !(node instanceof OrganizationProjectTreeNode);
			if (dai.acceptCopyInto || dai.acceptCopyAside) {
				if (isRecursive(node, nodeToDrop)) {
					dai.acceptCopyInto = false;
					dai.acceptCopyAside = false;
					dai.acceptMoveInto = false;
					dai.acceptMoveAside = false;
				}
			}
		}
		return dai;
	}
	private static boolean isRecursive(ProjectTreeNode node, ProjectTreeNode nodeToDrop) {
		if (node == nodeToDrop)
			return true;
		ProjectTreeNode parent = node.parentNode;
		while (parent != null && !(parent instanceof OrganizationProjectTreeNode)) {
			if (parent == nodeToDrop)
				return true;
			parent = parent.getParentNode();
		}
		return false;
	}
	public static class DropAcceptInfo {
		private boolean acceptCopyInto;
		private boolean acceptCopyAside;
		private boolean acceptMoveInto;
		private boolean acceptMoveAside;
		public boolean isSomethingAccepted() {
			return acceptCopyInto || acceptCopyAside || acceptMoveInto || acceptMoveAside;
		}
		public boolean isCopyAccepted() {
			return acceptCopyAside || acceptCopyInto;
		}
		public boolean isMoveAccepted() {
			return acceptMoveAside || acceptMoveInto;
		}
		public boolean isCopyIntoAccepted() {
			return acceptCopyInto;
		}
		public boolean isMoveIntoAccepted() {
			return acceptMoveInto;
		}
		public boolean isCopyAsideAccepted() {
			return acceptCopyAside;
		}
		public boolean isMoveAsideAccepted() {
			return acceptMoveAside;
		}
	}
}
