/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
/**
 * 
 */
package org.mactor.ui.gui.project.editors;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ParamsPanel extends SimpleFormPanel {
	List<RowPanel> rows = new LinkedList<RowPanel>();
	public ParamsPanel() {
		refreshRows();
	}
	public void removeRow(RowPanel row) {
		remove(row);
		rows.remove(row);
		revalidate();
		repaint();
	}
	public void addNewRow() {
		rows.add(new ParamsPanel.RowPanel());
		refreshRows();
	}
	public void refreshRows() {
		removeAll();
		Iterator it = rows.iterator();
		while (it.hasNext()) {
			add((RowPanel) it.next());
		}
		revalidate();
		repaint();
	}
	public Map<String, String> getParams() {
		HashMap<String, String> m = new HashMap<String, String>();
		for (RowPanel row : rows) {
			String n = trim(row.nameField.getText());
			if (n != null)
				m.put(n, trim(row.valueField.getText()));
		}
		return m;
	}
	private String trim(String s) {
		if (s == null)
			return null;
		s = s.trim();
		if (s.length() == 0)
			return null;
		return s;
	}
	class RowPanel extends SimpleRowPanel {
		JTextField nameField = new JTextField(10);
		JTextField valueField = new JTextField(10);
		JButton removeButton = new JButton("X");
		public RowPanel() {
			add(nameField);
			add(new JLabel(":"));
			add(valueField);
			add(removeButton);
			removeButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					removeRow(RowPanel.this);
				}
			});
		}
	}
}