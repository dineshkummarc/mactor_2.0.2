/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JTextField;

import org.dom4j.Element;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class MessageBrokerNodeEditor extends AbstractNodeEditor {
	MessageBrokerImplementationsComboBox mbcImplCb = new MessageBrokerImplementationsComboBox();
	BooleanComboBox archiveDlCb = new BooleanComboBox();
	BooleanComboBox archiveCmCb = new BooleanComboBox();
	JTextField messageReadInterval = new JTextField(5);
	JTextField messageReadLimit = new JTextField(5);
	GlobalDirSelector archivePathPanel = new GlobalDirSelector();
	Element data;
	public MessageBrokerNodeEditor() {
		super(new FlowLayout());
		SimpleFormPanel box = new SimpleFormPanel();
		box.add(new JLabel("Message Broker Class:"));
		box.add(mbcImplCb);
		box.add(new JLabel("Archive Path:"));
		box.add(archivePathPanel);
		box.add(new JLabel("Archive Consumed Messages:"));
		box.add(archiveCmCb);
		box.add(new JLabel("Archive Consumed Messages:"));
		box.add(archiveDlCb);
		box.add(new JLabel("Message Read Interval (seconds):"));
		box.add(messageReadInterval);
		box.add(new JLabel("Message Read Limit (number of messages):"));
		box.add(messageReadLimit);
		add(box);
	}
	public void applyChanges() {
		EditorUtil.setAttributeValue(data, "broker_class", mbcImplCb.getSelectedImplementation());
		EditorUtil.setAttributeValue(data, "archive_path", archivePathPanel.getPath());
		EditorUtil.setAttributeValue(data, "archive_dead_letter_messages", archiveDlCb.getSelectedValue());
		EditorUtil.setAttributeValue(data, "archive_consumed_messages", archiveCmCb.getSelectedValue());
		EditorUtil.setAttributeValue(data, "message_read_interval_seconds", messageReadInterval.getText());
		EditorUtil.setAttributeValue(data, "message_read_limit", messageReadLimit.getText());
	}
	public void setData(ProjectTreeNode node) throws MactorException {
		this.data = (Element) node.getModelObject();
		mbcImplCb.getSelectedImplementation(EditorUtil.getAttributeValue(data, "broker_class"));
		archivePathPanel.setPath(EditorUtil.getAttributeValue(data, "archive_path"));
		archiveDlCb.setSelectedValue(EditorUtil.getAttributeValue(data, "archive_dead_letter_messages"));
		archiveCmCb.setSelectedValue(EditorUtil.getAttributeValue(data, "archive_consumed_messages"));
		messageReadInterval.setText(EditorUtil.getAttributeValue(data, "message_read_interval_seconds"));
		messageReadLimit.setText(EditorUtil.getAttributeValue(data, "message_read_limit"));
	}
	public void setConfig(NodeEditorConfig config) {
	}
}
