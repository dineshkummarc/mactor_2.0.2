/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

public enum ProjectNodeType {
	// general node types
	VALUE,
	// Test node types
	T_TEST, T_MESSAGE_PUBLISH, T_MESSAGE_SUBSCRIBE, T_MESSAGE_RECEIVE, T_MESSAGE_RESPOND, T_ACTION, T_VALUE, T_EVENT_CHOICE, T_EVENT_CHOICE_BRANCH, T_LOOP, T_CONDITION,
	// Test data node types
	TR_TEST_RUN,
	// Message broker config node types
	MBC_MESSAGE_BROKERS, MBC_MESSAGE_BROKER, MBC_CHANNEL,
	// Global config node types
	G_GLOBAL_CONFIG, G_GROUP,
	// Test battery node types
	TM_MOCK_BATTERY, TM_TEST,
	// Project organization node types
	PROJECT_ROOT, PROJECT_GLOBAL_CONFIG, PROJECT_MESSAGE_BROKER_CONFIG, PROJECT_TEST, PROJECT_TEST_RUN, PROJECT_MOCK_BATTERY
}
