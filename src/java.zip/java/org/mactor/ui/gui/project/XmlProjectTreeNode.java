/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.dom4j.Attribute;
import org.dom4j.Element;
import org.mactor.framework.MactorException;

public class XmlProjectTreeNode extends ProjectTreeNode {
	protected Map<String, ProjectNodeType> nodeTypeDictionary;
	public XmlProjectTreeNode(ProjectNodeType nodeType, Element modelElement, Map<String, ProjectNodeType> nodeTypeDictionary) {
		super(nodeType, modelElement);
		this.nodeTypeDictionary = nodeTypeDictionary;
		Iterator it = modelElement.elementIterator();
		while (it.hasNext()) {
			Element el = (Element) it.next();
			ProjectNodeType elType = nodeTypeDictionary.get(el.getName());
			if (elType == null)
				continue;
			XmlProjectTreeNode child = new XmlProjectTreeNode(elType, el, nodeTypeDictionary);
			if (child != null) {
				child.parentNode = this;
				childNodes.add(child);
			}
		}
	}
	protected Element getModelElement() {
		return (Element) super.getModelObject();
	}
	@Override
	protected ProjectTreeNode copy() throws MactorException {
		return new XmlProjectTreeNode(getNodeType(), (getModelElement().createCopy()), nodeTypeDictionary);
	}
	@Override
	protected void model_delete() throws MactorException {
		getModelElement().detach();
	}
	@Override
	protected void model_detatch() throws MactorException {
		getModelElement().detach();
	}
	@Override
	protected String model_getName() {
		return getModelElement().attributeValue("name");
	}
	@Override
	protected void model_insert_child(int index, Object modelObject) {
		if (index == getModelElement().elements().size()) {
			getModelElement().add((Element) modelObject);
		} else {
			List elemements = getModelElement().elements();
			List newElements = new LinkedList();
			Iterator it = elemements.iterator();
			while (it.hasNext()) {
				newElements.add(((Element) it.next()).detach());
			}
			newElements.add(index, modelObject);
			it = newElements.iterator();
			while (it.hasNext()) {
				getModelElement().add((Element) it.next());
			}
		}
	}
	@Override
	protected void model_remove_child(int index) {
		Iterator it = getModelElement().elementIterator();
		Element el = (Element) it.next();
		for (int i = 0; i < index; i++)
			el = (Element) it.next();
		el.detach();
	}
	@Override
	protected boolean model_rename(String newName) throws MactorException {
		Attribute a = getModelElement().attribute("name");
		if (a == null)
			return false;
		a.setValue(newName);
		return true;
	}
	@Override
	protected void model_save() throws MactorException {
		parentNode.model_save();
	}
}
