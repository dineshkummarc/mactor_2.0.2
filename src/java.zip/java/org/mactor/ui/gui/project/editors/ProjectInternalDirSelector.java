/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JTextField;

import org.mactor.framework.spec.ProjectContext;

public class ProjectInternalDirSelector extends SimpleRowPanel {
	JTextField path = new JTextField(20);
	static JFileChooser fc = new JFileChooser(ProjectContext.getGlobalInstance().getProjectDir());
	String relativePath;
	JButton selectButton = new JButton(new AbstractAction("Select..") {
		public void actionPerformed(ActionEvent e) {
			int returnVal = fc.showOpenDialog(ProjectInternalDirSelector.this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File f = fc.getSelectedFile();
				try {
					f = new File(f.getCanonicalFile().getAbsolutePath());
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
				setPath(f);
				if (l != null)
					l.dirChanged(f);
			}
		}
	});
	public ProjectInternalDirSelector() {
		add(path);
		add(selectButton);
		fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		path.setEditable(false);
	}
	public String getPath() {
		return relativePath;
	}
	public void setPath(File path) {
		relativePath = ProjectContext.getGlobalInstance().getRelativePath(path);
		if (relativePath != null && relativePath.length() > 0) {
			fc.setSelectedFile(path);
			this.path.setText(relativePath);
		} else {
			fc.setSelectedFile(ProjectContext.getGlobalInstance().getProjectDir());
			this.path.setText("[project directory]");
		}
	}
	DirChangedListener l;
	public void setDirChangedListener(DirChangedListener l) {
		this.l = l;
	}
	public interface DirChangedListener {
		void dirChanged(File newConfigDir);
	}
}
