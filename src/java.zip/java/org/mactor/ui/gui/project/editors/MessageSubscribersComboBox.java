/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.project.editors;

import java.awt.Component;
import java.util.Iterator;

import javax.swing.JComboBox;

import org.dom4j.Element;

public class MessageSubscribersComboBox extends JComboBox {
	public MessageSubscribersComboBox() {
		addItem(null);
		setAlignmentX(Component.LEFT_ALIGNMENT);
	}
	public void setConfig(Element messageReceiverNode) {
		removeAllItems();
		addItem(null);
		Element parent = messageReceiverNode.getParent();
		while (parent != null) {
			Iterator it = parent.elementIterator();
			while (it.hasNext()) {
				Element child = (Element) it.next();
				if (child == messageReceiverNode)
					break;
				if (child.getName().equals("message_subscribe"))
					addItem(child.attributeValue("name"));
			}
			parent = parent.getParent();
		}
	}
	public String getSelectedMessageSubscriber() {
		Object item = getSelectedItem();
		if (item == null)
			return "";
		return (String) item;
	}
	public void setSelectedMessageSubscriber(String subscriber) {
		int count = getItemCount();
		if (subscriber == null || subscriber.trim().length() == 0) {
			setSelectedIndex(0);
			return;
		}
		for (int i = 1; i < count; i++) {
			String item = (String) getItemAt(i);
			if (item.equals(subscriber)) {
				setSelectedIndex(i);
				return;
			}
		}
		setSelectedIndex(0);
	}
}
