/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JOptionPane;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.project.GuiAction;
import org.mactor.ui.gui.project.ProjectController;
import org.mactor.ui.gui.project.ProjectTree;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class ActionsManager {
	private ProjectTreeNode selectedNode;
	private ProjectTree tree;
	private ProjectController projectController;
	private Map<String, ProjectActionInvoker> actions = new HashMap<String, ProjectActionInvoker>();
	public ActionsManager(ProjectController projectController, ProjectTree tree) throws MactorException {
		this.tree = tree;
		this.projectController = projectController;
		try {
			loadActionsDefs("project_actions.xml");
		} catch (Exception e) {
			throw new MactorException(e);
		}
		try {
			loadActionsDefs("project_actions_ex.xml");
			System.out.println("project_actions_ex.xml was loaded");
		} catch (Exception e) {
			System.out.println("project_actions_ex.xml was not loaded. Reason:" + e.getMessage());
		}
	}
	private void loadActionsDefs(String resource) throws Exception {
		URL u = Thread.currentThread().getContextClassLoader().getResource(resource);
		if (u == null)
			throw new RuntimeException("Resource '" + resource + "' was not found");
		Document doc = null;
		doc = new SAXReader().read(Thread.currentThread().getContextClassLoader().getResourceAsStream(resource));
		Iterator it = doc.getRootElement().elementIterator("action");
		while (it.hasNext()) {
			Element e = (Element) it.next();
			ProjectActionInvoker invoker = createAction(e.attributeValue("name"), e.attributeValue("class"), Boolean.parseBoolean(e.attributeValue("confirm")), getParams(e));
			actions.put(invoker.getName(), invoker);
		}
	}
	public Action getAction(String action) {
		Action a = actions.get(action);
		if (a == null)
			System.out.println("action '" + action + "' not found");
		return a;
	}
	private String[] getParams(Element e) {
		List<String> tmp = new LinkedList<String>();
		Iterator it = e.elementIterator("param");
		while (it.hasNext())
			tmp.add(((Element) it.next()).getText());
		return (String[]) tmp.toArray(new String[tmp.size()]);
	}
	private ProjectActionInvoker createAction(String name, String actionClass, boolean confirm, String[] params) throws MactorException {
		try {
			GuiAction action = (GuiAction) Class.forName(actionClass).newInstance();
			ProjectActionInvoker pa = new ProjectActionInvoker(name, confirm, action, params);
			return pa;
		} catch (Exception e) {
			e.printStackTrace();
			throw new MactorException("Unable to create instance of specifed action '" + actionClass + "'", e);
		}
	}
	private class ProjectActionInvoker extends AbstractAction {
		final private GuiAction action;
		final private String[] parameters;
		final private boolean confirm;
		final private String name;
		public ProjectActionInvoker(String name, boolean confirm, GuiAction action, String[] params) {
			super(name);
			this.action = action;
			this.parameters = params;
			this.name = name;
			this.confirm = confirm;
			tree.addTreeSelectionListener(new TreeSelectionListener() {
				public void valueChanged(TreeSelectionEvent e) {
					TreePath treePath = e.getNewLeadSelectionPath();
					if (treePath == null || treePath.getPathCount() == 0)
						selectedNode = null;
					else
						selectedNode = (ProjectTreeNode) treePath.getLastPathComponent();
					boolean p = ProjectActionInvoker.this.action.isPermitted(selectedNode, projectController, parameters);
					setEnabled(p);
				}
			});
			setEnabled(action.isPermitted(selectedNode, projectController, parameters));
		}
		public String getName() {
			return name;
		}
		public void actionPerformed(ActionEvent event) {
			if (confirm) {
				if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(tree.getParent(), "Are you sure you want to perfom '" + getName() + "' on the selected node?"))
					return;
			}
			try {
				action.perform(getSelectedTreeNode(), projectController, parameters);
			} catch (MactorException me) {
				GuiUtil.showGuiError(projectController.getControllerFrame(), me);
			}
		}
		private ProjectTreeNode getSelectedTreeNode() {
			TreePath p = tree.getSelectionPath();
			if (p == null || p.getPathCount() == 0)
				return null;
			return (ProjectTreeNode) p.getLastPathComponent();
		}
	}
}
