/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.testrunner;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.Timer;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import org.mactor.framework.MactorException;
import org.mactor.framework.TestEvent;
import org.mactor.ui.gui.GuiUtil;
import org.mactor.ui.gui.project.ProjectNodeType;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class RunningTestTreePanel extends JPanel {
	JTree tree = new JTree();
	JTextArea messageText = new JTextArea(10, 50);
	Timer timer = new Timer(400, new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if (runningColor.equals(runningColor1))
				runningColor = runningColor2;
			else
				runningColor = runningColor1;
			tree.validate();
			tree.repaint();
		}
	});
	public RunningTestTreePanel(ProjectTreeNode node) throws MactorException {
		super(new BorderLayout());
		tree.setModel(new ProjectModel(node));
		tree.setCellRenderer(new ProjectTreeCellRenderer());
		expandAll(tree, true);
		JScrollPane sp = new JScrollPane(tree);
		// sp.setPreferredSize(new Dimension(300, 300));
		add(sp, BorderLayout.CENTER);
		messageText.setEditable(false);
		messageText.setFont(messageText.getFont().deriveFont(Font.ITALIC));
		add(messageText, BorderLayout.SOUTH);
	}
	public void expandAll(JTree tree, boolean expand) {
		ProjectTreeNode root = (ProjectTreeNode) tree.getModel().getRoot();
		// Traverse tree from root
		expandAll(tree, new TreePath(root), expand);
	}
	private void expandAll(JTree tree, TreePath parent, boolean expand) {
		// Traverse children
		ProjectTreeNode node = (ProjectTreeNode) parent.getLastPathComponent();
		if (node.getChildCount() >= 0) {
			for (ProjectTreeNode n : node.getChildNodes()) {
				TreePath path = parent.pathByAddingChild(n);
				expandAll(tree, path, expand);
			}
		}
		if (expand) {
			tree.expandPath(parent);
		} else {
			tree.collapsePath(parent);
		}
	}
	public static class RunningTestModel {
		String last = null;
		boolean complete = false;
		boolean success;
		HashSet<String> executed = new HashSet<String>();
		String message;
		boolean running = false;
		public void reset() {
			last = null;
			complete = false;
			executed.clear();
		}
		public void addEvent(TestEvent event) {
			if (event.isStartEventType()) {
				String name = event.getNode().getName();
				executed.add(name);
				last = name;
				running = true;
			} else if (event.isTestCompleteEvent()) {
				success = event.isSuccessful();
				complete = true;
				running = false;
			}
			if (event.getCause() != null)
				message = event.getCause().getMessage();
			else
				message = event.getOutputText();
		}
		public boolean hasBeenExecuted(String nodeName) {
			return executed.contains(nodeName);
		}
		public boolean isComplete() {
			return complete;
		}
		public String getLast() {
			return last;
		}
		public String getMessage() {
			return message;
		}
		public boolean isRunning() {
			return running;
		}
		public boolean isSuccess() {
			return success;
		}
	}
	RunningTestModel rtModel = new RunningTestModel();
	public void setModel(RunningTestModel rtModel) {
		if (rtModel == null)
			throw new RuntimeException("RunningTestModel can not be null!");
		this.rtModel = rtModel;
		if (rtModel.isRunning() && !timer.isRunning())
			timer.start();
		else if (rtModel.isComplete() && timer.isRunning())
			timer.stop();
		messageText.setText(rtModel.getMessage());
		tree.validate();
		tree.repaint();
	}
	public class ProjectModel implements TreeModel {
		ProjectTreeNode root;// = new
		public ProjectModel(ProjectTreeNode root) throws MactorException {
			this.root = root;
		}
		public Object getChild(Object node, int index) {
			return ((ProjectTreeNode) node).getChildNode(index);
		}
		public int getChildCount(Object node) {
			return ((ProjectTreeNode) node).getChildCount();
		}
		public int getIndexOfChild(Object node, Object child) {
			return ((ProjectTreeNode) node).getIndexOfChild((ProjectTreeNode) child);
		}
		public ProjectTreeNode getRoot() {
			return root;
		}
		public boolean isLeaf(Object node) {
			return ((ProjectTreeNode) node).getChildCount() == 0;
		}
		public void valueForPathChanged(TreePath path, Object newValue) {
		}
		public void addTreeModelListener(TreeModelListener l) {
		}
		public void removeTreeModelListener(TreeModelListener l) {
		}
	}
	JLabel ref = new JLabel();
	Font runningFont = ref.getFont().deriveFont(Font.ITALIC);
	Font normalFont = ref.getFont();
	Font doneFont = ref.getFont();
	Color runningColor1 = Color.WHITE;
	Color runningColor2 = ref.getForeground();
	Color runningColor = runningColor1;
	Color doneColor = Color.GREEN;
	Color failedColor = Color.RED.darker();
	Color notDoneColor = ref.getForeground().brighter().brighter().brighter().brighter();
	class ProjectTreeCellRenderer extends DefaultTreeCellRenderer {
		private final Icon INCOMING_ICON = GuiUtil.loadIcon("/incoming_16.PNG");
		private final Icon SUBSCR_ICON = GuiUtil.loadIcon("/subscribe_16.PNG");
		private final Icon CONDITION_ICON = GuiUtil.loadIcon("/condition_16.PNG");
		private final Icon LOOP_ICON = GuiUtil.loadIcon("/loop_16.PNG");
		private final Icon ACTION_ICON = GuiUtil.loadIcon("/action_16.PNG");
		private final Icon VALUE_EXTRACT_ICON = GuiUtil.loadIcon("/value_extract_16.PNG");
		private final Icon OUTGOING_ICON = GuiUtil.loadIcon("/outgoing_16.PNG");
		private final Icon OUTGOING_RESP_ICON = GuiUtil.loadIcon("/outgoing_resp_16.PNG");
		public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean focus) {
			Component com = super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, focus);
			ProjectTreeNode node = (ProjectTreeNode) value;
			if (node != null) {
				if (ProjectNodeType.T_MESSAGE_PUBLISH.equals(node.getNodeType()))
					setIcon(OUTGOING_ICON);
				else if (ProjectNodeType.T_MESSAGE_RECEIVE.equals(node.getNodeType()))
					setIcon(INCOMING_ICON);
				else if (ProjectNodeType.T_MESSAGE_RESPOND.equals(node.getNodeType()))
					setIcon(OUTGOING_RESP_ICON);
				else if (ProjectNodeType.T_MESSAGE_SUBSCRIBE.equals(node.getNodeType()))
					setIcon(SUBSCR_ICON);
				else if (ProjectNodeType.T_CONDITION.equals(node.getNodeType()))
					setIcon(CONDITION_ICON);
				else if (ProjectNodeType.T_LOOP.equals(node.getNodeType()))
					setIcon(LOOP_ICON);
				else if (ProjectNodeType.T_ACTION.equals(node.getNodeType()))
					setIcon(ACTION_ICON);
				else if (ProjectNodeType.T_VALUE.equals(node.getNodeType()))
					setIcon(VALUE_EXTRACT_ICON);
				if (rtModel.isComplete() && node.getName().equals(rtModel.getLast())) {
					if (rtModel.isSuccess()) {
						setFont(doneFont);
						setForeground(doneColor);
					} else {
						setFont(doneFont);
						setForeground(failedColor);
					}
				} else if (node.getName().equals(rtModel.getLast())) {
					setFont(runningFont);
					setForeground(runningColor);
				} else if (rtModel.hasBeenExecuted(node.getName())) {
					setFont(doneFont);
					setForeground(doneColor);
				} else {
					setFont(normalFont);
					setForeground(notDoneColor);
				}
			}
			return com;
		}
	}
}
