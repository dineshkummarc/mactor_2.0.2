/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.testrunner;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.SwingUtilities;

import org.mactor.framework.MactorException;
import org.mactor.framework.TestFeedbackListener;
import org.mactor.framework.TestRunner;
import org.mactor.framework.data.DataTable;
import org.mactor.framework.spec.TestSpec;
import org.mactor.ui.gui.GuiUtil;
import org.mactor.ui.gui.Stoppable;
import org.mactor.ui.gui.project.ProjectTreeNode;
import org.mactor.ui.gui.project.editors.ParamsPanel;
import org.mactor.ui.gui.project.editors.SimpleFormPanel;
import org.mactor.ui.gui.testrunner.RunningTestTreePanel.RunningTestModel;

public class SingelTestPanel extends JPanel implements Stoppable {
	RunningTestTreePanel rtPanel;
	TestRunner tr;
	ParamsPanel pPanel = new ParamsPanel();
	RunningTestModel rtModel = new RunningTestModel();
	TestFeedbackListener tfl = new TestFeedbackListener() {
		public void onNodeEvent(final org.mactor.framework.TestEvent event, org.mactor.framework.TestContext context) {
			if (event.isStartEventType() || event.isTestCompleteEvent()) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						if (event.isTestCompleteEvent()) {
							runTest.setEnabled(true);
							stopTest.setEnabled(false);
						}
						rtModel.addEvent(event);
						rtPanel.setModel(rtModel);
					};
				});
			}
		};
		public void onTestRunCompleted(String testRunInstanceId, int succededCount, int failedCount) {
			// TODO Auto-generated method stub
		}
	};
	JButton runTest = new JButton(new AbstractAction("Run Test") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			rtModel.reset();
			rtPanel.setModel(rtModel);
			try {
				tr = new TestRunner(1, test, getDataTable(), tfl);
				tr.start();
				runTest.setEnabled(false);
				stopTest.setEnabled(true);
			} catch (MactorException me) {
				GuiUtil.showGuiError(SingelTestPanel.this, me);
			}
		};
	});
	JButton stopTest = new JButton(new AbstractAction("Stop Test") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			stop();
		};
	});
	JButton addRowButton = new JButton(new AbstractAction("Add Param") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			pPanel.addNewRow();
		};
	});
	DataTable getDataTable() {
		DataTable dt = new DataTable();
		Map<String, String> params = pPanel.getParams();
		if (params.size() == 0) {
			dt.addColumn("dummy_");
			dt.addRow(new String[] { "" });
		} else {
			List<String> values = new LinkedList<String>();
			for (Entry<String, String> e : params.entrySet()) {
				dt.addColumn(e.getKey());
				values.add(e.getValue());
			}
			dt.addRow(values);
		}
		return dt;
	}
	TestSpec test;
	public SingelTestPanel(ProjectTreeNode node) throws MactorException {
		super(new BorderLayout());
		this.test = TestSpec.loadFromFile(node.getName());
		SimpleFormPanel sf = new SimpleFormPanel();
		rtPanel = new RunningTestTreePanel(node);
		sf.add(new JLabel("Params:"));
		sf.add(pPanel);
		sf.add(addRowButton);
		JPanel p1 = new JPanel(new BorderLayout());
		p1.add(sf, BorderLayout.NORTH);
		JScrollPane sp1 = new JScrollPane(p1);
		JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sp1, rtPanel);
		sp.setDividerLocation(400);
		add(sp, BorderLayout.CENTER);
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(runTest);
		buttonPanel.add(stopTest);
		stopTest.setEnabled(false);
		add(buttonPanel, BorderLayout.NORTH);
	}
	public void stop() {
		if (tr != null) {
			tr.stop();
			tr = null;
		}
		runTest.setEnabled(false);
		stopTest.setEnabled(true);
	}
}
