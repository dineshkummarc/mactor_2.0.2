/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.testrunner;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;

import org.mactor.framework.MactorException;
import org.mactor.framework.TestEvent;
import org.mactor.framework.TestFeedbackListener;
import org.mactor.framework.TestRunner;
import org.mactor.framework.TestEvent.EventType;
import org.mactor.framework.data.DataProviderFactory;
import org.mactor.framework.data.DataTable;
import org.mactor.framework.spec.SpecNode;
import org.mactor.framework.spec.TestRunSpec;
import org.mactor.framework.spec.TestSpec;
import org.mactor.ui.gui.AsyncAction;
import org.mactor.ui.gui.GuiUtil;
import org.mactor.ui.gui.Stoppable;
import org.mactor.ui.gui.project.ProjectNodeType;
import org.mactor.ui.gui.project.ProjectTreeNode;
import org.mactor.ui.gui.project.ProjectTreeUtil;
import org.mactor.ui.gui.project.editors.SimpleFormPanel;
import org.mactor.ui.gui.testrunner.RunningTestTreePanel.RunningTestModel;

public class TestRunPanel extends JPanel implements Stoppable {
	RunningTestTreePanel rtPanel;
	TestRunner tr;
	TestResultTableModel tableModel = new TestResultTableModel(new DataTable());
	JTable table = new JTable(tableModel);
	Map<String, RunningTestModel> modelMap = new HashMap<String, RunningTestModel>();
	TestFeedbackListener tfl = new TestFeedbackListener() {
		public void onNodeEvent(final org.mactor.framework.TestEvent event, org.mactor.framework.TestContext context) {
			if (event.isStartEventType() || event.isTestCompleteEvent()) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						RunningTestModel rtModel = modelMap.get(event.getDataId() + "");
						if (rtModel != null) {
							rtModel.addEvent(event);
							tableModel.setLastEvent(event);
						} else {
							System.out.println("Receivned unexpected event with data id " + event.getDataId());
						}
					};
				});
			}
		};
		public void onTestRunCompleted(String testRunInstanceId, int succededCount, int failedCount) {
			runTest.setEnabled(true);
			loadDataButton.setEnabled(true);
			stopTest.setEnabled(false);
		}
	};
	JButton runTest = new JButton(new AsyncAction("Run Test", false, new AsyncAction.AsyncRunnable() {
		public void run() {
			try {
				tr = new TestRunner(testRun.getThreadCount(), test, loadData(), tfl);
				tr.start();
				data = null;
				runTest.setEnabled(false);
				loadDataButton.setEnabled(false);
				stopTest.setEnabled(true);
			} catch (MactorException me) {
				GuiUtil.showGuiError(TestRunPanel.this, me);
			}
		}
	}));
	JButton stopTest = new JButton(new AsyncAction("Stop Test", true, new AsyncAction.AsyncRunnable() {
		public void run() {
			stop();
		}
	}));
	JButton loadDataButton = new JButton(new AsyncAction("Load Data", false, new AsyncAction.AsyncRunnable() {
		public void run() {
			try {
				data = null;
				loadData();
			} catch (MactorException me) {
				GuiUtil.showGuiError(TestRunPanel.this, me);
			}
		}
	}));
	DataTable data;
	DataTable loadData() throws MactorException {
		if (data == null) {
			System.out.println("loading");
			data = DataProviderFactory.getDataProvider(testRun.getDataSource()).loadData();
			int rowCount = data.getRowCount();
			for (int i = 0; i < rowCount; i++) { // init models
				modelMap.put(i + "", new RunningTestModel());
			}
			tableModel = new TestResultTableModel(data);
			table.setModel(tableModel);
		}
		return data;
	}
	private ProjectTreeNode findTestNode(ProjectTreeNode node, String testName) throws MactorException {
		ProjectTreeNode testRoot = ProjectTreeUtil.navigateToFirstFileNodeOfType(ProjectNodeType.T_TEST, node).getParentNode();
		if (testRoot == null)
			throw new MactorException("Test node not found:" + testName);
		for (ProjectTreeNode test : testRoot.getChildNodes())
			if (test.getName().equals(testName))
				return test;
		throw new MactorException("Test node not found:" + testName);
	}
	TestSpec test;
	TestRunSpec testRun;
	int numberOfTestThreads;
	public TestRunPanel(ProjectTreeNode node) throws MactorException {
		super(new BorderLayout());
		this.testRun = TestRunSpec.loadFromFile(node.getName());
		this.test = TestSpec.loadFromFile(this.testRun.getTest());
		ProjectTreeNode testNode = findTestNode(node, test.getName());
		rtPanel = new RunningTestTreePanel(testNode);
		JPanel bp = new JPanel(new FlowLayout());
		bp.add(loadDataButton);
		SimpleFormPanel sf = new SimpleFormPanel();
		sf.add(bp);
		sf.add(new JLabel("Test Data:"));
		JPanel leftPanel = new JPanel(new BorderLayout());
		leftPanel.add(sf, BorderLayout.NORTH);
		leftPanel.add(new JScrollPane(table), BorderLayout.CENTER);
		JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rtPanel);
		sp.setDividerLocation(400);
		add(sp, BorderLayout.CENTER);
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(runTest);
		buttonPanel.add(stopTest);
		stopTest.setEnabled(false);
		add(buttonPanel, BorderLayout.NORTH);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		// table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setDefaultRenderer(String.class, new TestResultTableRenderer());
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent event) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						int row = table.getSelectedRow();
						RunningTestModel rtModel = modelMap.get(row + "");
						if (rtModel != null) {
							rtPanel.setModel(rtModel);
						} else {
							System.out.println("Model does not exist. Row:" + row);
						}
					}
				});
			}
		});
	}
	public void stop() {
		if (tr != null) {
			tr.stop();
			tr = null;
		}
		stopTest.setEnabled(false);
		runTest.setEnabled(true);
	}
	private class TestResultTableModel extends AbstractTableModel {
		private int columnCount = 0;
		private DataTable data;
		private TestEvent[] lastEventArray;
		public TestResultTableModel(DataTable data) {
			this.columnCount = data.getColumnCount() + 2;
			this.data = data;
			this.lastEventArray = new TestEvent[data.getRowCount()];
		}
		@Override
		public String getColumnName(int index) {
			if (index == columnCount - 2)
				return "Status";
			if (index == columnCount - 1)
				return "Last event";
			return data.getColumn(index);
		}
		public int getColumnCount() {
			return columnCount;
		}
		public int getRowCount() {
			return data.getRowCount();
		}
		@Override
		public Class<?> getColumnClass(int arg0) {
			return String.class;
		}
		public Object getValueAt(int row, int col) {
			if (col == columnCount - 2)
				return getStatus(row);
			if (col == columnCount - 1)
				return getEventInfo(row);
			return data.getValue(row, col);
		}
		public void setLastEvent(TestEvent event) {
			lastEventArray[event.getDataId()] = event;
			super.fireTableRowsUpdated(event.getDataId(), event.getDataId());
		}
		private String getStatus(int row) {
			if (lastEventArray[row] == null)
				return "Not started";
			SpecNode node = lastEventArray[row].getNode();
			if ((node instanceof TestSpec) && lastEventArray[row].getEventType() == EventType.End) {
				if (lastEventArray[row].isSuccessful())
					return "Successful";
				return "Failed";
			}
			return "Running";
		}
		private String getEventInfo(int row) {
			if (lastEventArray[row] == null)
				return "";
			SpecNode node = lastEventArray[row].getNode();
			if (lastEventArray[row].isStartEventType())
				return "Performing:" + node.getShortDescription();
			else if (lastEventArray[row].isSuccessful()) {
				if (node instanceof TestSpec)
					return "Test successfully completed";
				return "Succesfully completed:" + node.getShortDescription();
			} else
				return "Test completed with failure";
		}
		public void clearResults() {
			this.lastEventArray = new TestEvent[data.getRowCount()];
			super.fireTableDataChanged();
		}
	}
	public class TestResultTableRenderer extends JLabel implements TableCellRenderer {
		boolean isBordered = true;
		Font RUNNING_FONT;
		Font NOT_STARTED_FONT;
		Font COMPLETED_FONT;
		public TestResultTableRenderer() {
			setOpaque(true);
			RUNNING_FONT = getFont().deriveFont(Font.BOLD | Font.ITALIC);
			NOT_STARTED_FONT = getFont().deriveFont(Font.PLAIN);
			COMPLETED_FONT = getFont().deriveFont(Font.PLAIN);
		}
		public Component getTableCellRendererComponent(JTable table, Object object, boolean isSelected, boolean hasFocus, int row, int column) {
			setText(object + "");
			setForeground(Color.BLACK);
			TestEvent te = ((TestResultTableModel) table.getModel()).lastEventArray[row];
			if (te == null) {
				setFont(NOT_STARTED_FONT);
				setBackground(Color.WHITE);
			} else if (te.isSuccessfulTestCompleteEvent()) {
				setFont(COMPLETED_FONT);
				setBackground(Color.GREEN);
			} else if (te.isFaultTestCompleteEvent()) {
				setFont(COMPLETED_FONT);
				setBackground(Color.RED);
			} else {
				setFont(RUNNING_FONT);
				setBackground(Color.WHITE);
			}
			if (isSelected) {
				setBackground(Color.BLUE);
				setForeground(Color.WHITE);
			}
			return this;
		}
	}
}
