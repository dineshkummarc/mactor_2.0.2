/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.testrunner;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import org.mactor.brokers.Message;
import org.mactor.brokers.MessageBrokerManager;
import org.mactor.brokers.MessageSubscriber;
import org.mactor.extensions.GreedyMessageSelector;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.GuiUtil;
import org.mactor.ui.gui.ResourceUtil;
import org.mactor.ui.gui.Stoppable;

public class ChannelRuntimePanel extends JPanel implements Stoppable {
	String channel;
	Object lock = new Object();
	Object pendingMessageLock = new Object();
	boolean requiresResponse;
	boolean pendingResponse = false;
	Message pendingResponseMessage;
	JTextArea messageText = new JTextArea(20, 40);
	ChannelMessageLogPanel cmlPanel;
	Timer timer = new Timer(1000, new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if (sendButton.getBackground().equals(Color.RED))
				sendButton.setBackground(subscribeButton.getBackground());
			else
				sendButton.setBackground(Color.RED);
		}
	});
	private boolean busy = false;
	private Object busyLock = new Object();
	MessageSubscriber ms = new MessageSubscriber() {
		public org.mactor.brokers.Message onMessage(final Message message) {
			if (requiresResponse)
				return handleIncomingWithResponse(message);
			return null;
		};
	};
	JButton subscribeButton = new JButton(new AbstractAction("Start Subscriber") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			try {
				MessageBrokerManager.getInstance().subscribe(channel, ms, new GreedyMessageSelector());
				subscribeButton.setEnabled(false);
				unsubscribeButton.setEnabled(true);
				sendButton.setEnabled(false);
			} catch (MactorException me) {
				GuiUtil.showGuiError(ChannelRuntimePanel.this, me);
			}
		};
	});
	JButton unsubscribeButton = new JButton(new AbstractAction("Stop Subscriber") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			try {
				MessageBrokerManager.getInstance().unsubscribe(channel, ms);
				timer.stop();
				sendButton.setBackground(subscribeButton.getBackground());
				subscribeButton.setEnabled(true);
				unsubscribeButton.setEnabled(false);
				sendButton.setEnabled(true);
			} catch (MactorException me) {
				GuiUtil.showGuiError(ChannelRuntimePanel.this, me);
			}
		};
	});
	JButton sendButton = new JButton(new AbstractAction("Publish Message") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			try {
				if (pendingResponse) {
					pendingResponseMessage = Message.createMessage(messageText.getText());
					synchronized (pendingMessageLock) {
						pendingMessageLock.notifyAll();
					}
				} else {
					/*
					 * if(!subscribeButton.isEnabled()) {
					 * GuiUtil.showInfo(ChannelRuntimePanel.this, "Sorry, it is
					 * not possible to subscribe and published to the same
					 * channel in the same 'tab' \n(only response messages can
					 * be published )"); return; }
					 */
					final Message outgoingMessage = Message.createMessage(messageText.getText());
					sendButton.setEnabled(false);
					new Thread(new Runnable() {
						public void run() {
							try {
								MessageBrokerManager.getInstance().publish(channel, outgoingMessage);
								SwingUtilities.invokeLater(new Runnable() {
									public void run() {
										sendButton.setEnabled(true);
									}
								});
							} catch (final MactorException me) {
								SwingUtilities.invokeLater(new Runnable() {
									public void run() {
										sendButton.setEnabled(true);
										GuiUtil.showGuiError(ChannelRuntimePanel.this, me);
									}
								});
							}
						};
					}).start();
				}
			} catch (MactorException me) {
				GuiUtil.showGuiError(ChannelRuntimePanel.this, me);
			}
		};
	});
	JButton clearButton = new JButton(new AbstractAction("Clear") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			messageText.setText("");
		};
	});
	private Message handleIncomingWithResponse(final Message message) {
		try {
			synchronized (busyLock) {
				if (busy)
					busyLock.wait();
				busy = true;
			}
		} catch (InterruptedException ie) {
		}
		pendingResponse = true;
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				sendButton.setEnabled(true);
				timer.start();
			}
		});
		try {
			synchronized (pendingMessageLock) {
				pendingMessageLock.wait();
			}
		} catch (InterruptedException ie) {
		}
		pendingResponse = false;
		final Message response = pendingResponseMessage;
		response.getMessageContextInfo().setResponseToMessage(message);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				timer.stop();
				sendButton.setBackground(subscribeButton.getBackground());
				synchronized (busyLock) {
					busy = false;
					busyLock.notify();
				}
			}
		});
		return response;
	}
	public void stop() {
		try {
			MessageBrokerManager.getInstance().unsubscribe(channel, ms);
		} catch (MactorException me) {
			me.printStackTrace();
		}
	}
	public ChannelRuntimePanel(String channel, boolean requiresResponse) throws MactorException {
		super(new BorderLayout());
		this.channel = channel;
		cmlPanel = new ChannelMessageLogPanel(channel);
		this.requiresResponse = requiresResponse;
		unsubscribeButton.setEnabled(false);
		JPanel topPanel = new JPanel(new FlowLayout());
		topPanel.add(subscribeButton);
		topPanel.add(unsubscribeButton);
		JPanel messagePanel = new JPanel(new BorderLayout());
		messagePanel.add(new JLabel("Message:"), BorderLayout.NORTH);
		messagePanel.add(new JScrollPane(messageText), BorderLayout.CENTER);
		JPanel messageButtonPanel = new JPanel(new FlowLayout());
		messageButtonPanel.add(sendButton);
		messageButtonPanel.add(clearButton);
		messagePanel.add(messageButtonPanel, BorderLayout.SOUTH);
		JPanel logPanel = new JPanel(new BorderLayout());
		logPanel.add(new JLabel("Message Log:"), BorderLayout.NORTH);
		logPanel.add(cmlPanel, BorderLayout.CENTER);
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, logPanel, messagePanel);
		splitPane.setDividerLocation(400);
		add(topPanel, BorderLayout.NORTH);
		add(splitPane, BorderLayout.CENTER);
		cmlPanel.setMessageSelectionChangedListener(new ChannelMessageLogPanel.MessageSelectionChangedListener() {
			public void onChange(File archivedFile) {
				try {
					messageText.setText(ResourceUtil.readFileContent(archivedFile));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
