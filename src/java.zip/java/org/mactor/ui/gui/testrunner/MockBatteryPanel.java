/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.testrunner;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

import org.mactor.framework.MactorException;
import org.mactor.framework.MockRunner;
import org.mactor.framework.TestEvent;
import org.mactor.framework.TestFeedbackListener;
import org.mactor.framework.spec.MockBatterySpec;
import org.mactor.framework.spec.TestSpec;
import org.mactor.ui.gui.GuiUtil;
import org.mactor.ui.gui.Stoppable;
import org.mactor.ui.gui.project.ProjectTreeNode;

public class MockBatteryPanel extends JPanel implements Stoppable {
	JTable table;
	MockRunner mr;
	int testThreadCount;
	MockStatusTableModel model;
	List<TestSpec> tests = new LinkedList<TestSpec>();
	TestFeedbackListener tfl = new TestFeedbackListener() {
		public void onNodeEvent(final org.mactor.framework.TestEvent event, org.mactor.framework.TestContext context) {
			if (event.isStartEventType() || event.isTestCompleteEvent()) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						model.setLastEvent(event);
					};
				});
			}
		};
		public void onTestRunCompleted(String testRunInstanceId, int succededCount, int failedCount) {
			// TODO Auto-generated method stub
		}
	};
	JButton startButton = new JButton(new AbstractAction("Start Mock") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			try {
				mr = new MockRunner(testThreadCount, tests, tfl);
				mr.start();
				startButton.setEnabled(false);
				stopButton.setEnabled(true);
			} catch (MactorException me) {
				GuiUtil.showGuiError(MockBatteryPanel.this, me);
			}
		};
	});
	JButton stopButton = new JButton(new AbstractAction("Stop Mock") {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			mr.stop();
			startButton.setEnabled(true);
			stopButton.setEnabled(false);
		};
	});
	public MockBatteryPanel(ProjectTreeNode node) throws MactorException {
		super(new BorderLayout());
		MockBatterySpec spec = MockBatterySpec.loadFromFile(node.getName());
		testThreadCount = spec.getThreadCount();
		for (String t : spec.getTests())
			tests.add(TestSpec.loadFromFile(t));
		model = new MockStatusTableModel(tests);
		table = new JTable(model);
		stopButton.setEnabled(false);
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(startButton);
		buttonPanel.add(stopButton);
		add(buttonPanel, BorderLayout.NORTH);
		JScrollPane sp = new JScrollPane(table);
		sp.setPreferredSize(new Dimension(800, 200));
		add(sp, BorderLayout.CENTER);
	}
	public void stop() {
		if (mr != null)
			mr.stop();
	}
	private class MockStatusTableModel extends AbstractTableModel {
		final String[] cols = new String[] { "Test Name", "Last Event Time", "Last Node", "Last Message" };
		TestSnapshotInfo[] ts;
		HashMap<TestSpec, TestSnapshotInfo> dic = new HashMap<TestSpec, TestSnapshotInfo>();
		public MockStatusTableModel(List<TestSpec> tests) {
			int i = 0;
			ts = new TestSnapshotInfo[tests.size()];
			for (TestSpec t : tests) {
				ts[i] = new TestSnapshotInfo(i, t.getName());
				dic.put(t, ts[i]);
				i++;
			}
			System.out.println(ts.length);
		}
		@Override
		public String getColumnName(int index) {
			return cols[index];
		}
		public int getColumnCount() {
			return cols.length;
		}
		public int getRowCount() {
			return ts.length;
		}
		@Override
		public Class<?> getColumnClass(int arg0) {
			return String.class;
		}
		public Object getValueAt(int row, int col) {
			if (col == 0)
				return ts[row].getTestName();
			else if (col == 1)
				return ts[row].getLastEventTime() + "";
			else if (col == 2)
				return ts[row].getLastNodeName();
			else if (col == 3)
				return ts[row].getLastMessage();
			throw new RuntimeException("No such row!");
		}
		public void setLastEvent(TestEvent event) {
			TestSnapshotInfo t = dic.get(event.getTestSpec());
			if (t != null) {
				if (event.isStartEventType()) {
					t.setEventInfo(event.getTime(), event.getNode().getName(), event.getOutputText());
					super.fireTableRowsUpdated(t.getIndex(), t.getIndex());
				}
				if (event.isTestCompleteEvent()) {
					t.setEventInfo(event.getTime(), "Test Completed", event.getOutputText());
				}
				super.fireTableRowsUpdated(t.getIndex(), t.getIndex());
			} else {
				System.out.println("test not found:" + event.getTestSpec());
			}
		}
		public void clearResults() {
			for (TestSnapshotInfo t : ts)
				t.setEventInfo(null, null, null);
			super.fireTableDataChanged();
		}
	}
	private class TestSnapshotInfo {
		private String testName;
		private Calendar lastEventTime;
		private String lastNodeName;
		private String lastMessage;
		private int index;
		public TestSnapshotInfo(int index, String testName) {
			this.testName = testName;
			this.index = index;
		}
		public void setEventInfo(Calendar eventTime, String nodeName, String message) {
			this.lastEventTime = eventTime;
			this.lastNodeName = nodeName;
			this.lastMessage = message;
		}
		public String getLastEventTime() {
			return GuiUtil.format(lastEventTime);
		}
		public String getLastMessage() {
			return lastMessage;
		}
		public String getLastNodeName() {
			return lastNodeName;
		}
		public String getTestName() {
			return testName;
		}
		public int getIndex() {
			return index;
		}
	}
}
