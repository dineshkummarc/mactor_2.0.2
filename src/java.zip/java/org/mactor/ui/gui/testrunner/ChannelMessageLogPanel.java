/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.testrunner;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;

import org.mactor.brokers.MessageBrokerManager;
import org.mactor.brokers.MessageBrokerManager.MessageInfo;
import org.mactor.brokers.MessageBrokerManager.MessageInfoListener;
import org.mactor.framework.MactorException;
import org.mactor.ui.gui.AsyncAction;
import org.mactor.ui.gui.GuiUtil;

public class ChannelMessageLogPanel extends JPanel {
	private JTable table;
	MessageHistoryTableModel model = new MessageHistoryTableModel();
	JButton loadButton = new JButton(new AsyncAction("Load Log from Archive", false, new AsyncAction.AsyncRunnable() {
		public void run() {
			try {
				model.setMessageHistory(MessageBrokerManager.getInstance().loadMessageInfoFromArchive(channel));
			} catch (MactorException e) {
				GuiUtil.showGuiError(ChannelMessageLogPanel.this, e);
			}
		}
	}));
	JButton clearButton = new JButton(new AsyncAction("Clear GUI", false, new AsyncAction.AsyncRunnable() {
		public void run() {
			model.setMessageHistory(new ArrayList<MessageInfo>());
		}
	}));
	JButton clearDiskButton = new JButton(new AsyncAction("Clear Archive", true, new AsyncAction.AsyncRunnable() {
		public void run() {
			try {
				MessageBrokerManager.getInstance().clearArchive(channel);
				model.setMessageHistory(new ArrayList<MessageInfo>());
			} catch (MactorException e) {
				GuiUtil.showGuiError(ChannelMessageLogPanel.this, e);
			}
		}
	}));
	String channel;
	public ChannelMessageLogPanel(String channel) throws MactorException {
		super(new BorderLayout());
		this.channel = channel;
		table = new JTable(model);
		table.getColumnModel().getColumn(0).setCellRenderer(new MessageTableCellRendere());
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent event) {
				if (listener != null) {
					int row = table.getSelectedRow();
					if (row >= 0) {
						Object name = model.getValueAt(row, 2);
						if (name != null) {
							listener.onChange(new File(name.toString()));
						}
					}
				}
			}
		});
		// summaryTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(0).setMaxWidth(25);
		JScrollPane tableSp = new JScrollPane(table);
		add(tableSp, BorderLayout.CENTER);
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(clearButton);
		buttonPanel.add(clearDiskButton);
		buttonPanel.add(loadButton);
		add(buttonPanel, BorderLayout.SOUTH);
		MessageBrokerManager.getInstance().addMessageInfoListener(channel, miListener);
	}
	MessageSelectionChangedListener listener;
	public void setMessageSelectionChangedListener(MessageSelectionChangedListener listener) {
		this.listener = listener;
	}
	public static interface MessageSelectionChangedListener {
		void onChange(File archivedFile);
	}
	MessageInfoListener miListener = new MessageInfoListener() {
		public void onMessageInfo(final MessageInfo messageInfo) {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					model.addMessage(messageInfo);
				}
			});
		};
	};
	public void stop() throws MactorException {
		MessageBrokerManager.getInstance().removeMessageInfoListener(channel, miListener);
	}
	static final int MAX = 2000;
	static final int HYST = 300;
	private static class MessageHistoryTableModel extends AbstractTableModel {
		private static final Icon INCOMING_ICON = GuiUtil.loadIcon("/incoming_16.PNG");
		private static final Icon INCOMING_RESP_ICON = GuiUtil.loadIcon("/incoming_resp_16.PNG");
		private static final Icon OUTGOING_ICON = GuiUtil.loadIcon("/outgoing_16.PNG");
		private static final Icon OUTGOING_RESP_ICON = GuiUtil.loadIcon("/outgoing_resp_16.PNG");
		ArrayList<MessageInfo> history = new ArrayList<MessageInfo>();
		String[] colums = new String[] { "", "Timestamp", "Path" };
		@Override
		public String getColumnName(int col) {
			return colums[col];
		}
		public void setMessageHistory(List<MessageInfo> history) {
			this.history = new ArrayList<MessageInfo>(history);
			adjust();
			super.fireTableDataChanged();
		}
		public void addMessage(MessageInfo messageInfo) {
			this.history.add(messageInfo);
			adjust();
			super.fireTableDataChanged();
		}
		final private void adjust() {
			if (this.history.size() > MAX)
				this.history = new ArrayList<MessageInfo>(this.history.subList((history.size() - MAX) + HYST, history.size() - 1));
		}
		public int getColumnCount() {
			return colums.length;
		}
		public int getRowCount() {
			if (history == null)
				return 0;
			return history.size();
		}
		public MessageInfo getMessageInfo(int row) {
			if (history == null || row < 0 || row >= history.size())
				return null;
			return history.get(history.size() - 1 - row);
		}
		public Object getValueAt(int row, int col) {
			if (history == null)
				return null;
			MessageInfo mi = history.get(history.size() - 1 - row);
			if (col == 0)
				return getCol_0(mi);
			if (col == 1)
				return getCol_1(mi);
			if (col == 2)
				return getCol_2(mi);
			throw new RuntimeException("Invalid column '" + col + "'");
		}
		private Object getCol_0(MessageInfo mi) {
			if (mi.isIncoming()) {
				if (mi.isResponse())
					return INCOMING_RESP_ICON;
				return INCOMING_ICON;
			}
			if (mi.isResponse())
				return OUTGOING_RESP_ICON;
			return OUTGOING_ICON;
		}
		private Object getCol_1(MessageInfo mi) {
			return GuiUtil.format(mi.getCreatedTime());
		}
		private String getCol_2(MessageInfo mi) {
			return mi.getArchivePath();
		}
	}
	public class MessageTableCellRendere extends DefaultTableCellRenderer {
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			if (value instanceof Icon)
				setIcon((Icon) value);
			else
				setIcon(null);
			setText(null);
			return this;
		}
	}
}
