/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui.testrunner;

import java.util.LinkedList;

import org.mactor.framework.TestContext;
import org.mactor.framework.TestEvent;
import org.mactor.framework.TestSummary_old;

public class TestProgressInfo {
	private TestContext contex;
	private LinkedList<TestEvent> log = new LinkedList<TestEvent>();
	private TestSummary_old testSummary = null;
	public TestProgressInfo(TestContext contex) {
		super();
		this.contex = contex;
	}
	public boolean addEvent(TestEvent event) {
		log.add(event);
		if (event.isTestCompleteEvent()) {
			testSummary = TestSummary_old.create(this.contex, log);
			this.log = null;
			this.contex = null;
			return true;
		}
		return false;
	}
	public boolean hasTestSummary() {
		return testSummary != null;
	}
	public LinkedList<TestEvent> getLog() {
		return log;
	}
	public TestSummary_old getTestSummary() {
		return testSummary;
	}
	public TestContext getContex() {
		return contex;
	}
}