/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.LinkedList;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.Timer;

import org.dom4j.Element;
import org.mactor.brokers.MessageBrokerManager;
import org.mactor.framework.MactorException;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.ui.gui.project.ProjectControlListener;
import org.mactor.ui.gui.project.ProjectExplorerPanel;
import org.mactor.ui.gui.project.ProjectNodeType;
import org.mactor.ui.gui.project.ProjectTreeNode;
import org.mactor.ui.gui.project.editors.NodeEditor;
import org.mactor.ui.gui.project.editors.NodeEditorConfig;
import org.mactor.ui.gui.project.editors.NodeEditorConfigManager;
import org.mactor.ui.gui.testrunner.ChannelRuntimePanel;
import org.mactor.ui.gui.testrunner.MockBatteryPanel;
import org.mactor.ui.gui.testrunner.SingelTestPanel;
import org.mactor.ui.gui.testrunner.TestRunPanel;

public class MActorGui {
	JFrame f;
	TipPanel tipPanel = new TipPanel();
	NodeEditor editor;
	JSplitPane projectPane;
	JEditorPane introPane;
	JPanel mainPane = new JPanel(new CardLayout());
	JTabbedPane tabbedPane = new JTabbedPane();
	JPanel editorContainer = new JPanel(new BorderLayout());
	JPanel editorPanel = new JPanel(new BorderLayout());
	TabPanel editorTab = new TabPanel(editorPanel, false);
	EventLogPanel eventLog = new EventLogPanel();
	JButton dummyButton = new JButton("");
	ProjectExplorerPanel pc;
	JButton reloadButton = new JButton(new AsyncAction("Reload the Project to Activate the Message Broker Modification", false, new AsyncAction.AsyncRunnable() {
		public void run() throws MactorException {
			pc.getProjectController().reloadProject();
		};
	}));
	Timer reloadTimer = new Timer(700, new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if (reloadButton.getBackground().equals(Color.RED))
				reloadButton.setBackground(dummyButton.getBackground());
			else
				reloadButton.setBackground(Color.RED);
		}
	});
	private void showEditorForNode(ProjectTreeNode newNode, ProjectTreeNode oldNode) {
		if (editor != null) {
			editor.applyChanges();
		}
		if (tabbedPane.getTabCount() > 0)
			tabbedPane.setSelectedIndex(0);
		try {
			if (newNode != null && oldNode != newNode) {
				editorTab.setHeader(getPath(newNode));
				NodeEditorConfig editorConfig = NodeEditorConfigManager.getInstance().getNodeEditorConfig(newNode.getNodeType());
				if (oldNode != null && editor != null && editor.isDirty())
					oldNode.save();
				editorContainer.removeAll();
				if (editorConfig != null) {
					tipPanel.onTip(1, editorConfig.getTip());
					editor = editorConfig.createEditor();
					editor.setTipListener(tipPanel);
					editor.setData(newNode);
					editorContainer.add((Component) editor, BorderLayout.WEST);
				} else {
					tipPanel.onTip(1, null);
					editor = null;
				}
			}
			editorTab.revalidate();
			editorTab.repaint();
		} catch (MactorException me) {
			GuiUtil.showGuiError(f, me);
		}
	}
	private String getPath(ProjectTreeNode node) {
		LinkedList<String> names = new LinkedList<String>();
		while (node != null && node.getParentNode() != null) {
			names.addFirst(node.getCaption());
			node = node.getParentNode();
		}
		StringBuffer sb = new StringBuffer();
		for (String n : names) {
			if (sb.length() > 0)
				sb.append(" > ");
			sb.append(n);
		}
		return sb.toString();
	}
	ProjectControlListener projectControlListener = new ProjectControlListener() {
		public void onProjectLoaded() {
			CardLayout cl = (CardLayout) (mainPane.getLayout());
			cl.show(mainPane, "PROJECT");
			tabbedPane.removeAll();
			tabbedPane.addTab("Edit", new JScrollPane(editorTab));
			f.setTitle("MActor (" + VersionUtil.getVersion() + ") - " + ProjectContext.getGlobalInstance().getProjectName());
			tabbedPane.revalidate();
			tabbedPane.repaint();
			try {
				if (MessageBrokerManager.isActive())
					MessageBrokerManager.getInstance().terminate();
			} catch (MactorException me) {
				me.printStackTrace();
			}
			reloadButton.setVisible(false);
			reloadTimer.stop();
		};
		public void onProjectTreeSelectionChanged(ProjectTreeNode selectedNode, ProjectTreeNode previousSelectedNode) {
			showEditorForNode(selectedNode, previousSelectedNode);
		};
		public void onRequestGuiAction(ProjectTreeNode node, String action) {
			if ("run".equals(action) && node != null)
				openInNewTab(node);
			if ("open".equals(action) && node != null)
				openInNewTab(node);
			return;
		}
		public void onProjectDirty() {
			if (MessageBrokerManager.isActive()) {
				reloadButton.setVisible(true);
				reloadTimer.start();
			}
		}
	};
	public void openInNewTab(ProjectTreeNode node) {
		try {
			if (node != null) {
				if (ProjectNodeType.MBC_CHANNEL.equals(node.getNodeType())) {
					TabPanel tc = new TabPanel(new ChannelRuntimePanel(node.getName(), Boolean.parseBoolean(((Element) node.getModelObject()).attributeValue("requires_response"))), true);
					tc.setHeader(getPath(node));
					tabbedPane.addTab("Channel - " + node.getCaption(), tc);
					tabbedPane.setSelectedIndex(tabbedPane.getTabCount() - 1);
				} else if (ProjectNodeType.T_TEST.equals(node.getNodeType())) {
					TabPanel tc = new TabPanel(new SingelTestPanel(node), true);
					tc.setHeader(getPath(node));
					tabbedPane.addTab("Test - " + node.getCaption(), tc);
					tabbedPane.setSelectedIndex(tabbedPane.getTabCount() - 1);
				} else if (ProjectNodeType.TM_MOCK_BATTERY.equals(node.getNodeType())) {
					TabPanel tc = new TabPanel(new MockBatteryPanel(node), true);
					tc.setHeader(getPath(node));
					tabbedPane.addTab("Mock Battery - " + node.getCaption(), tc);
					tabbedPane.setSelectedIndex(tabbedPane.getTabCount() - 1);
				} else if (ProjectNodeType.TR_TEST_RUN.equals(node.getNodeType())) {
					TabPanel tc = new TabPanel(new TestRunPanel(node), true);
					tc.setHeader(getPath(node));
					tabbedPane.addTab("Test Run - " + node.getCaption(), tc);
					tabbedPane.setSelectedIndex(tabbedPane.getTabCount() - 1);
				}
			}
		} catch (MactorException me) {
			GuiUtil.showGuiError(f, me);
		}
	}
	private class TabPanel extends JPanel {
		JLabel headerLabel = new JLabel("");
		JButton closeButton = new JButton(new AbstractAction("X") {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.remove(tabbedPane.indexOfComponent(TabPanel.this));
				if (containedComponent instanceof Stoppable)
					((Stoppable) containedComponent).stop();
			}
		});
		Component containedComponent;
		public TabPanel(Component containedComponent, boolean closeable) {
			super(new BorderLayout());
			this.containedComponent = containedComponent;
			headerLabel.setBackground(getBackground().darker().darker().darker());
			headerLabel.setForeground(getBackground().brighter().brighter());
			headerLabel.setOpaque(true);
			headerLabel.setFont(headerLabel.getFont().deriveFont(Font.BOLD, 12));
			headerLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			JPanel headerPanel = new JPanel(new BorderLayout());
			setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			if (closeable)
				headerPanel.add(closeButton, BorderLayout.EAST);
			headerPanel.add(headerLabel, BorderLayout.CENTER);
			add(headerPanel, BorderLayout.NORTH);
			add(containedComponent, BorderLayout.CENTER);
		}
		public void setHeader(String header) {
			headerLabel.setText(header);
			headerLabel.setVisible(header != null && header.trim().length() > 0);
		}
	}
	MActorGui(File projectDir) throws Exception {
		reloadButton.setVisible(false);
		f = new JFrame("MActor (" + VersionUtil.getVersion() + ")");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JMenuBar bar = new JMenuBar();
		pc = new ProjectExplorerPanel(projectControlListener);
		bar.add(pc.getMenuBuilder().buildMenu("Project"));
		bar.add(pc.getMenuBuilder().buildMenu("Help"));
		bar.add(reloadButton);
		f.setJMenuBar(bar);
		editorPanel.add(tipPanel, BorderLayout.CENTER);
		editorPanel.add(editorContainer, BorderLayout.NORTH);
		projectPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, pc, tabbedPane);
		projectPane.setDividerLocation(250);
		introPane = new JEditorPane(Thread.currentThread().getContextClassLoader().getResource("frontpage.html"));
		introPane.addHyperlinkListener(BrowserUtil.createLinkListener());
		introPane.setEditable(false);
		mainPane.add(new JScrollPane(introPane), "INTRO");
		mainPane.add(projectPane, "PROJECT");
		JSplitPane allPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, mainPane, eventLog);
		allPane.setDividerLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getHeight() - 250);
		f.getContentPane().add(allPane, BorderLayout.CENTER);
		if (projectDir != null)
			pc.getProjectController().openProject(projectDir);
		f.setSize(1024, 800);
		f.setExtendedState(Frame.MAXIMIZED_BOTH);
		f.setVisible(true);
	}
	public static void main(String[] args) throws Exception {
		File projectDir = null;
		if (args != null && args.length > 0) {
			projectDir = new File(args[0]);
			if (!projectDir.exists()) {
				JOptionPane.showMessageDialog(null, "Project directory '" + projectDir.getAbsolutePath() + "' does not exist", "Project not found", JOptionPane.ERROR_MESSAGE);
				System.exit(1);
			} else if (projectDir.isFile()) {
				projectDir = projectDir.getParentFile();
			}
		}
		Splash s = new Splash();
		new MActorGui(projectDir);
		s.dispose();
	}
}
