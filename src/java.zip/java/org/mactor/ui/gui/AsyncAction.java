/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.gui;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import org.mactor.framework.MactorException;

public class AsyncAction extends AbstractAction {
	AsyncRunnable r;
	Component source;
	boolean confirm;
	public AsyncAction(String name, boolean confirm, AsyncRunnable r) {
		super(name);
		this.r = r;
		this.confirm = confirm;
	}
	public void actionPerformed(ActionEvent e) {
		if (confirm) {
			if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(null, "Are you sure you want to perfom '" + getValue(AbstractAction.NAME) + "' ?"))
				return;
		}
		setEnabled(false);
		if (e.getSource() instanceof Component && ((Component) e.getSource()).getParent() != null)
			source = ((Component) e.getSource()).getParent();
		if (source != null)
			source.setCursor(new Cursor(Cursor.WAIT_CURSOR));
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					try {
						r.run();
					} catch (MactorException me) {
						GuiUtil.showGuiError(source, me);
					}
				} finally {
					setEnabled(true);
					if (source != null)
						source.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				}
			}
		});
	}
	public static interface AsyncRunnable {
		void run() throws MactorException;
	}
}
