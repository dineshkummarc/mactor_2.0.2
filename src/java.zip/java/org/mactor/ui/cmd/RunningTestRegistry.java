/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.cmd;

import java.util.Iterator;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.dom4j.Element;
import org.mactor.brokers.Message;
import org.mactor.brokers.http.HttpClient;
import org.mactor.brokers.http.HttpRequest;
import org.mactor.brokers.http.HttpRequestListener;
import org.mactor.brokers.http.HttpResponse;
import org.mactor.brokers.http.HttpServerManager;
import org.mactor.framework.MactorException;

public class RunningTestRegistry {
	protected static Logger log = Logger.getLogger(RunningTestRegistry.class);
	private static final int SERVER_PORT = 9876;
	private static final int PORT_RANGE_LOW = 9877;
	private static final int PORT_RANGE_HIGH = 9977;
	private static final String BROWSER_LISTENER_PATH = "/m";
	private static final String SERVER_PATH_PEER = "/MactorRunningTestsRegistry";
	private static final String INSTANCE_PATH = "/MactorRunningTest";
	private static final String SERVER_URL = "http://localhost:" + SERVER_PORT + SERVER_PATH_PEER;
	TreeMap<Integer, String> runningTests = new TreeMap<Integer, String>();
	int port;
	boolean connected = false;
	private String instanceId;
	private PeerRequestHandler peerHandler = new PeerRequestHandler();
	private BrowserIndexRequestHandler browserhandler = new BrowserIndexRequestHandler();
	public RunningTestRegistry(String instanceId) {
		this.instanceId = instanceId;
		try {
			if (!establishLocalServer()) {
				log.warn("Failed to establish registry server client for instance " + instanceId);
				return;
			}
			for (int i = 0; i < 10 && !connected; i++) {
				if (!connectWithRegistryServer()) {
					if (!startRegistryServer()) {
						continue;
					}
					Thread.sleep(1000);
				} else {
					connected = true;
				}
			}
		} catch (InterruptedException ie) {
		}
	}
	private boolean connectWithRegistryServer() {
		try {
			Message result = HttpClient.sendMessage(SERVER_URL, "POST", Message.createMessage("<register><port>" + port + "</port><id>" + instanceId + "</id></register>"), true, null, null);
			System.out.println("received:" + result.getContent());
			return result != null && result.getContentDocument().getRootElement().getName().equals("ok");
		} catch (MactorException me) {
			// Message resutl =
		}
		return false;
	}
	private boolean startRegistryServer() {
		try {
			HttpServerManager.getHttpServer(SERVER_PORT).addRequestListener(SERVER_PATH_PEER, peerHandler);
			HttpServerManager.getHttpServer(SERVER_PORT).addRequestListener(BROWSER_LISTENER_PATH, browserhandler);
			return true;
		} catch (MactorException me) {
		}
		return true;
	}
	private boolean establishLocalServer() {
		for (int i = PORT_RANGE_LOW; i < PORT_RANGE_HIGH; i++) {
			try {
				HttpServerManager.getHttpServer(i).addRequestListener(INSTANCE_PATH, peerHandler);
				this.port = i;
				return true;
			} catch (MactorException me) {
			}
		}
		return false;
	}
	private class BrowserIndexRequestHandler implements HttpRequestListener {
		public HttpResponse onRequest(HttpRequest request) throws Exception {
			HttpResponse res = new HttpResponse();
			StringBuffer sb = new StringBuffer("<html><head><title>MActor Running Tests Registry</title></head><body>");
			sb.append("<table>");
			for (Entry<Integer, String> e : runningTests.entrySet()) {
				sb.append("<tr><td>").append("<a href=\"http://localhost:" + SERVER_PORT + BROWSER_LISTENER_PATH + "/" + e.getKey() + "\">" + e.getValue() + "</a>");
				sb.append("</td></tr>");
			}
			sb.append("</table>");
			sb.append("</body></html>");
			res.setData(sb.toString());
			return res;
		}
	}
	private class BrowserInstanceRequestHandler implements HttpRequestListener {
		int clientPort;
		String clientId;
		public BrowserInstanceRequestHandler(int clientPort, String clientId) {
			this.clientPort = clientPort;
			this.clientId = clientId;
		}
		public HttpResponse onRequest(HttpRequest request) throws Exception {
			HttpResponse res = new HttpResponse();
			StringBuffer sb = new StringBuffer("<html><head><title>MActor Running Tests Registry (" + clientId + ")</title></head><body>");
			sb.append("</body></html>");
			try {
				Message result = HttpClient.sendMessage("http://localhost:" + clientPort + INSTANCE_PATH, "POST", Message.createMessage("<query/>"), true, null, null);
				Iterator it = result.getContentDocument().getRootElement().elementIterator("test");
				if (!it.hasNext()) {
				} else {
					sb.append("<table>");
					while (it.hasNext()) {
						Element testEl = (Element) it.next();
						sb.append("<tr><td>").append(testEl.element("name").getTextTrim());
						sb.append("</td><td>").append(testEl.element("node").getTextTrim());
						sb.append("</td><td>").append(testEl.element("msg").getTextTrim());
						sb.append("</td></tr>");
					}
					sb.append("</table>");
				}
			} catch (MactorException me) {
				sb.append("Unable to get any information from instance '" + clientId + "'");
				runningTests.remove(new Integer(clientPort));
				HttpServerManager.getHttpServer(SERVER_PORT).removeRequestListener(BROWSER_LISTENER_PATH + "/" + clientPort);
			}
			res.setData(sb.toString());
			return res;
		}
	}
	private String getInstanceStatus() {
		return "<status><test><name>test1</name><node>action1</node><msg></msg></test></status>";
	}
	private class PeerRequestHandler implements HttpRequestListener {
		public HttpResponse onRequest(HttpRequest request) throws Exception {
			String responseData = null;
			HttpResponse res = new HttpResponse();
			try {
				Message m = Message.createMessage(request.getData());
				Element root = m.getContentDocument().getRootElement();
				if ("register".equals(root.getName())) {
					Integer clientPort = new Integer(root.element("port").getTextTrim());
					String clientId = root.element("id").getTextTrim();
					if (!runningTests.containsKey(clientPort)) {
						log.info("Adding intance " + clientPort + "-" + instanceId + " to running registry ");
						runningTests.put(clientPort, clientId);
					}
					try {
						HttpServerManager.getHttpServer(SERVER_PORT).addRequestListener(BROWSER_LISTENER_PATH + "/" + clientPort, new BrowserInstanceRequestHandler(clientPort, clientId));
					} catch (MactorException me) {
					}
					res.setData("<ok/>");
				} else if ("alive".equals(root.getName())) {
					res.setData("<ok/>");
				} else if ("query".equals(root.getName())) {
					res.setData(getInstanceStatus());
				} else {
					res.setData("<error>invalid request</error>");
				}
			} catch (Exception e) {
				log.info(instanceId + " received invalid http request. Error:" + e.getMessage() + "t. Request:" + request.getData());
				res.setData("<error/>");
			}
			return res;
		}
	}
	public static void main(String[] args) throws Exception {
		new RunningTestRegistry("1");
	}
}
