/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.cmd;

import org.apache.log4j.Logger;
import org.mactor.framework.TestContext;
import org.mactor.framework.TestEvent;
import org.mactor.framework.TestFeedbackListener;
import org.mactor.framework.TestEvent.EventType;

public class SimpleLogFeedbackHandler implements TestFeedbackListener {
	protected static Logger log = Logger.getLogger(SimpleLogFeedbackHandler.class);
	private String getLogPrefix(TestEvent event) {
		return event.getTestRunInstanceId() + ";" + event.getTestInstanceId() + ";" + event.getTestSpec().getName() + ";";
	}
	public void onNodeEvent(TestEvent event, TestContext context) {
		if (event.getEventType().equals(EventType.Start)) {
			log.info(getLogPrefix(event) + "Node execution started");
		} else {
			if (event.isTestCompleteEvent()) {
				if (event.isSuccessful()) {
					log.info(getLogPrefix(event) + "Test completed with SUCCESS");
				} else {
					if (event.getCause() != null)
						log.info(getLogPrefix(event) + "Test completed with FAILURE. Details:" + event.getCause().getMessage());
					else
						log.info(getLogPrefix(event) + "Test completed with FAILURE");
				}
			} else if (!event.isSuccessful()) {
				if (event.getCause() != null)
					log.info(getLogPrefix(event) + event.getNode().getName() + ";Execution of node failed with:" + event.getCause().getMessage());
				else
					log.info(getLogPrefix(event) + event.getNode().getName() + ";Execution of node failed");
			}
		}
	}
	public void onTestRunCompleted(String testRunInstanceId, int succededCount, int failedCount) {
		log.info(testRunInstanceId + ";Test Run comleted with " + succededCount + " SUCCESSFUL tests and " + failedCount + " FAILED tests");
	}
}