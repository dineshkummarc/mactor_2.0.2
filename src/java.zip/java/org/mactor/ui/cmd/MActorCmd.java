/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui.cmd;

import java.io.File;

import org.dom4j.Document;
import org.mactor.framework.MactorException;
import org.mactor.framework.MockRunner;
import org.mactor.framework.TestRunner;
import org.mactor.framework.data.DataProviderFactory;
import org.mactor.framework.data.DataTable;
import org.mactor.framework.spec.MockBatterySpec;
import org.mactor.framework.spec.ProjectContext;
import org.mactor.framework.spec.TestRunSpec;
import org.mactor.framework.spec.TestSpec;

public class MActorCmd {
	public static void main(String[] args) {
		if (args.length != 1) {
			printUsage();
			System.exit(1);
		}
		File f = new File(args[0]);
		if (!f.exists()) {
			printUsage();
			System.exit(1);
		}
		String name = f.getName();
		try {
			ProjectContext.getGlobalInstance().setProjectDir(f.getParentFile());
			Document doc = ProjectContext.getGlobalInstance().readFromFile(name, false);
			if (doc.getRootElement().getName().equals("test")) {
				runTest(doc, name);
			} else if (doc.getRootElement().getName().equals("test_run")) {
				runTestRun(doc, name);
			} else if (doc.getRootElement().getName().equals("mock_battery")) {
				runMockBattery(doc, name);
			} else {
				System.out.println("'" + name + "' in project '" + ProjectContext.getGlobalInstance().getProjectName() + "' is not an executable test");
				printUsage();
				System.exit(1);
			}
		} catch (MactorException me) {
			System.out.println("Execution of '" + name + "' in project '" + ProjectContext.getGlobalInstance().getProjectName() + "' failed with reason:" + me.getMessage());
			printUsage();
			System.exit(1);
		}
	}
	private static void runTest(Document doc, String name) throws MactorException {
		TestSpec spec = TestSpec.loadFromDocument(doc, name);
		DataTable dt = new DataTable();
		dt.addColumn("dummy_");
		dt.addRow(new String[] { "" });
		TestRunner tr = new TestRunner(1, spec, dt, new SimpleLogFeedbackHandler());
		tr.start();
		if (tr.waitForCompletion() == 0)
			System.exit(0);
		else
			System.exit(1);
	}
	private static void runTestRun(Document doc, String name) throws MactorException {
		TestRunSpec spec = TestRunSpec.loadFromDocument(doc, name);
		TestRunner tr = new TestRunner(spec.getThreadCount(), TestSpec.loadFromFile(spec.getTest()), DataProviderFactory.getDataProvider(spec.getDataSource()).loadData(),
				new SimpleLogFeedbackHandler());
		tr.start();
		if (tr.waitForCompletion() == 0)
			System.exit(0);
		else
			System.exit(1);
	}
	private static void runMockBattery(Document doc, String name) throws MactorException {
		MockBatterySpec spec = MockBatterySpec.loadFromDocument(doc, name);
		MockRunner mr = new MockRunner(spec.getThreadCount(), spec.getTestSpecs(), new SimpleLogFeedbackHandler());
		mr.start();
		mr.waitForCompletion();
	}
	private static void printUsage() {
		System.out.println("Usage: runtest <path to the test file to execute (the file must be a test a test_run or mock_battery)>");
	}
}
