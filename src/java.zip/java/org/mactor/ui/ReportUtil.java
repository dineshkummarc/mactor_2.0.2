/******************************************************************************
 * Copyright (C) MActor Developers. All rights reserved.                        *
 * ---------------------------------------------------------------------------*
 * This file is part of MActor.                                               *
 *                                                                            *
 * MActor is free software; you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation; either version 2 of the License, or          *
 * (at your option) any later version.                                        *
 *                                                                            *
 * MActor is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with MActor; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA *
 ******************************************************************************/
package org.mactor.ui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map.Entry;

import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.mactor.framework.MactorException;
import org.mactor.framework.TestSuiteSummary_old;
import org.mactor.framework.TestSummary_old;
import org.mactor.framework.TestSummary_old.MessageInfo;

public class ReportUtil {
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	public static void writeReportToFile(File file, TestSuiteSummary_old summary, List<TestSummary_old> result) throws MactorException {
		Document doc = buildReport(summary, result);
		write(file, doc);
	}
	private static void write(File file, Document doc) throws MactorException {
		try {
			OutputFormat format = OutputFormat.createPrettyPrint();
			FileOutputStream fos = new FileOutputStream(file);
			XMLWriter writer = new XMLWriter(fos, format);
			writer.write(doc);
			writer.flush();
			fos.close();
		} catch (IOException ioe) {
			throw new MactorException("Failed to write the  file '" + file.getAbsolutePath() + "'. Error:" + ioe.getMessage(), ioe);
		}
	}
	private static Document buildReport(TestSuiteSummary_old summary, List<TestSummary_old> result) {
		Document doc = DocumentFactory.getInstance().createDocument();
		Element rootEl = doc.addElement("report");
		Element summaryEl = rootEl.addElement("summary");
		addEl(summaryEl, "start_time", summary.getTestStart());
		addEl(summaryEl, "complete_time", summary.getTestStart());
		addEl(summaryEl, "success_count", summary.getSuccessCount());
		addEl(summaryEl, "failed_count", summary.getFailedCount());
		addEl(summaryEl, "avg_success_time_ms", summary.getAverageSuccessCompleteTimeMs());
		addEl(summaryEl, "avg_failed_time_ms", summary.getAverageFailedCompleteTimeMs());
		addEl(summaryEl, "message_sent_count", summary.getMessageSentCount());
		addEl(summaryEl, "message_received_count", summary.getMessageReceivedCount());
		Element testsEl = rootEl.addElement("tests");
		for (TestSummary_old test : result) {
			Element tEl = testsEl.addElement("test");
			addEl(tEl, "start_time", test.getTestStartTime());
			addEl(tEl, "complete_time", test.getTestCompleteTime());
			addEl(tEl, "succesful", test.isSuccess());
			if (!test.isSuccess())
				addEl(tEl, "failure_message", test.getFailedMessage());
			Element valsEl = tEl.addElement("context_values");
			for (Entry<String, String> val : test.getContextValues().entrySet()) {
				Element vEl = valsEl.addElement("context_value");
				vEl.addAttribute("name", val.getKey());
				vEl.setText(val.getValue());
			}
			Element messagesEl = tEl.addElement("messages");
			for (MessageInfo mi : test.getMessageHistory()) {
				Element mEl = messagesEl.addElement("message");
				addEl(mEl, "time", mi.getCreatedTime());
				addEl(mEl, "incoming", mi.isIncoming() + "");
				addEl(mEl, "response", mi.isResponse() + "");
				addEl(mEl, "archive_path", mi.getArchivePath());
				if (mi.getChannel() != null)
					addEl(mEl, "channel", mi.getChannel());
			}
		}
		return doc;
	}
	private static void addEl(Element el, String name, Object value) {
		String formatted = null;
		if (value == null)
			formatted = "";
		else if (value instanceof Calendar)
			formatted = sdf.format(((Calendar) value).getTime());
		else
			formatted = value.toString();
		Element newEl = el.addElement(name);
		newEl.setText(formatted);
	}
}